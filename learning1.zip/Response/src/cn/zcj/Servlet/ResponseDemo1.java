package cn.zcj.Servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/responsedemo1")
public class ResponseDemo1 extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    //访问demo1资源会自动跳转到demo2资源
        System.out.println("demo1被访问了");
        //1.设置状态码为302
        /*response.setStatus(302);
        //2.设置相应头Location
        response.setHeader("location","/response/responsedemo2");*/

        //response提供方法
//        response.sendRedirect("/response/responsedemo2");
        response.sendRedirect("http://www.baidu.com");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request,response);
    }
}
