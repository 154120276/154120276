package cn.zcj.TCP.FileUpload02;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;


/**
 * 文件上传案例的服务器端:读取客户端上传的文件，保存刀服务器的硬盘，给客户端回写上传成功
 *  明确
 *  数据源：客户端上传的文件
 *  目的地：服务器的硬盘放哪：
 *  实现步骤：
 *      1.创建服务器ServerSocket对象和系统要指定的端口号
 *      2.使用ServerSocket中的accept方法获取刀请求的客户端对象Socket
 *      3.使用Socker对象中的方法getInputStream()获取网络字节输入流InputStream对象
 *      4.判断是否又upload这个文件夹，不存在就创建
 *      5.创建一个本地字节输出流FileOutputStream对象，构造方法中明确输出目的地
 *      6.使用网络字节输出端Iutputstream对象的read方法给服务器发送数据
 *      7.使用地字节输出流FileOutputStream对象的write方法保存文件
 *      8.使用Socker对象中的方法getOutputStream()获取网络字节输入流OutputStream对象
 *      9.使用使用网络字节输入端OnputStream对象的write读取服务器回写的数据
 *      10.释放所有资源
 */
public class TCPServer {
    public static void main(String[] args) throws IOException {
        ServerSocket server=new ServerSocket(8888);
        /*
            让服务器一直处于监听状态(死循环accept方法)
            有一个客户端上传文件：就保存一个文件
         */
        while(true){
            Socket socket = server.accept();
            /*
                使用多线程技术，来提高程序的效率
                有一个客户端上传文件，就开启一个线程完成文件的上传
             */
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        InputStream is = socket.getInputStream();
                        File file = new File("D:\\upload");
                        if (!file.exists()) {
                            file.mkdirs();
                        }
                /*
                    自定义一个文件的命名规则：防止同名文件被覆盖
                    规则：域名+毫秒值+随机数
                */
                        String filename = "zcj" + System.currentTimeMillis() + new Random().nextInt(999999) + ".jpg";
                        FileOutputStream fos = new FileOutputStream(file + "\\" + filename);
                        byte[] bytes = new byte[2048];
                        int len = 0;
                        while ((len = is.read(bytes)) != -1) {
                            fos.write(bytes, 0, len);
                        }
                        socket.getOutputStream().write("上传成功".getBytes());
                        fos.close();

                    } catch (IOException e) {
                        e.printStackTrace();
                    }finally {
                        try {
                            socket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();

        }
        //服务器就不用关闭了
        //server.close();
    }
}
