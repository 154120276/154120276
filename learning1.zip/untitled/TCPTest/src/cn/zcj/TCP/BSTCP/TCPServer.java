package cn.zcj.TCP.BSTCP;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

/*
    创建BS版本的TCP服务器
 */
public class TCPServer {
    public static void main(String[] args) throws IOException {
        //创建服务器
        ServerSocket server=new ServerSocket(8080);

        while(true){
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Socket socket=server.accept();
                        InputStream is=socket.getInputStream();
                     /* byte[] bytes=new byte[2048];
                        int len=0;
                    while((len=is.read(bytes))!=-1){
                    System.out.println(new String(bytes,0,len));
                    }*/
                        //把is转换为字符缓冲输入流
                        BufferedReader br=new BufferedReader(new InputStreamReader(is));
                        //把客户端请求信息的第一行读取出来
                        String line=br.readLine();
                        //进行切割，只要中间的路径部分
                        String[] arr= line.split(" ");
                        //把路径前面的\去掉，进行截取
                        String htmlpath= arr[1].substring(1);

                        //创建一个本地字节输入流，构造方法中绑定要独缺的HTML路径
                        FileInputStream fis=new FileInputStream(htmlpath);
                        //使用socket获取网络输出对象
                        OutputStream os=socket.getOutputStream();
                        //写入HTTP协议的响应头，固定三行代码（以后学HTML会知道为什么）
                        os.write("HTTP/1.1 200 OK\r\n".getBytes());
                        os.write("Content‐Type:text/html\r\n".getBytes());
                        // 必须要写入空行,否则浏览器不解析         
                        os.write("\r\n".getBytes());

                        //一读一写复制文件，把服务器读取的HTML文件回写到客户端
                        int len=0;
                        byte[] bytes=new byte[1024];
                        while((len=fis.read(bytes))!=-1){
                            os.write(bytes,0,len);
                        }
                        //释放资源

                        fis.close();
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();

        }


    }
}
