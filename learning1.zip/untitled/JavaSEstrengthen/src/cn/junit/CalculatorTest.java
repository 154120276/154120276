package cn.junit;

public class CalculatorTest {
    public static void main(String[] args) {
        //创建对象
        Calculator c=new Calculator();
        //调用方法
        System.out.println(c.add(1,2));
        System.out.println(c.sub(1,1));

    }
}
