package cn.Test;

import cn.junit.Calculator;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CalculatorTest {
    /**
     * 初始化方法
     * 用于资源的申请，所有测试方法在执行之前都会先执行该方法
     */
   @Before
    public void init(){
       System.out.println("init...");
    }

    /**
     * 释放资源的方法
     * 在所有测试方法执行玩后，都会自动执行该方法
     */
   @After
   public void close(){
       System.out.println("close...");
   }


    /*
        测试add方法
     */
    @Test
    public void testadd(){//红色报错
            //System.out.println("我被执行了");
        Calculator c=new Calculator();
        System.out.println(c.add(1,5));
        Assert.assertEquals(2,c.add(1,2));
        //3.断言  我判断这个结果是2,但实际是3所以会报错
    }
    @Test
    public void testsub(){
        Calculator c=new Calculator();
        System.out.println(c.sub(1,5));
        Assert.assertEquals(-4,c.sub(1,5));
    }
}
