package cn.annotation;
/*
    预定义的注解
    @Override:重写方法
    @Deprecated：该注解标注的内容，表示已过时
    @SuppessWarning ：压制警告


 */
@SuppressWarnings("all")//压制警告,一般传递参数all
public class AnnotationDemo02 {

    @Override
    public String toString() {
        return super.toString();
    }
    //标注show1已过时，推荐使用show2，但不可删除，删除就无法兼容低版本
    @Deprecated
    public void show1(){

    }
    @MyAnno(value =12,per=Person.P1)//如果value是唯一属性，就可以不用写value=
    public void show2(){
    }

}
