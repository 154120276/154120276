package cn.annotation;

public @interface MyAnno {
    //String show();
    int value();
    //default 18;//如果不赋值默认18
    //基本数据类型
    ;//枚举

    Person per();
    //注解类型也可以就不演示了
    //以上类型的数组都可以，也不演示了


}
