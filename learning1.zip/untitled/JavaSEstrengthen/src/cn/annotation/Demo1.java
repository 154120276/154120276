package cn.annotation;

public class Demo1 {
    public void show(){
        System.out.println("Demo1show");
    }
}
