package cn.annotation;

public enum Person {
    P1,P2;//枚举类
}
