package cn.annotation;
/*
    注解javadoc的演示

    @since 1.5
 */
public class AnnotationDemo01 {
    /**
     * 计算两数的合
     * @param a 整数
     * @param b 整数
     * @return 两数的合
     */
    public int add(int a,int b){
        return a+b;
    }
}
