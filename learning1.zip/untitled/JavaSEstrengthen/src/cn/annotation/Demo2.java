package cn.annotation;

public class Demo2 {
    public void show(){
        System.out.println("Demo2show");
    }
}
