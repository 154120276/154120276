package cn.Reflect;

import cn.domain.Person;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

public class ReflectDemo04 {
    /*
    Class类对象的一些功能
     */
    public static void main(String[] args) throws Exception {
        //1.获取Person的class对象
        Class<Person> cls = Person.class;
        /*
        获取成员方法，同成员变量，带私有的同样要暴力反射
         */
        Method eat_Method = cls.getMethod("eat");
        Person p=new Person();
        //执行方法
        eat_Method.invoke(p);
        Method eat_Method2= cls.getMethod("eat",String.class);

        //执行方法
        eat_Method2.invoke(p,"饺子");
        System.out.println("-----------------------------");
        //获取所有public修饰的方法
        Method[] methods = cls.getMethods();
        for (Method method : methods) {
            //System.out.println(method);
            System.out.println(method.getName());
            //method.setAccessible(true);在反射面前没有什么是隐私的
        }
        //获取类名
        String clsname = cls.getName();
        System.out.println(clsname);
    }
}
