package cn.Reflect;

import cn.domain.Person;

import java.lang.reflect.Field;

public class ReflectDemo02 {
    /*
    Class类对象的一些功能
     */
    public static void main(String[] args) throws Exception {
        //1.获取Person的class对象
        Class<Person> cls = Person.class;
        /*
        获取成员变量
         */
        //1.获取所有以Public修饰的成员变量
        Field[] fields = cls.getFields();
        for (Field field : fields) {
            System.out.println(field);
        }
        //2.获取指定的Public修饰的成员变量
        System.out.println("-----------------");
        Field a = cls.getField("a");
        //获取成员变量a的值
        Person p=new Person();
        Object o = a.get(p);
        System.out.println(o);//默认是null，因为是字符串类型
        //设置A的值
        a.set(p,"张三");
        System.out.println(p);
        System.out.println("=====================");
        //3.获取Declared成员变量,获取所有，不考虑修饰符
        Field[] declaredFields = cls.getDeclaredFields();
        for (Field declaredField : declaredFields) {
            System.out.println(declaredField);
        }
        //4.获取指定成员变量,不考虑修饰符
        Field d = cls.getDeclaredField("d");
        //忽略访问权限修饰符的安全检查
        d.setAccessible(true);//暴力反射
        Object o1 = d.get(p);
        System.out.println(o1);
    }
}
