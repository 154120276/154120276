package cn.Reflect;

import cn.domain.Person;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

public class ReflectDemo03 {
    /*
    Class类对象的一些功能
     */
    public static void main(String[] args) throws Exception {
        //1.获取Person的class对象
        Class<Person> cls = Person.class;
        /*
        获取构造方法
         */
        //跟成员变量相似，所以只演示一个
        Constructor<Person> constructor = cls.getConstructor(String.class, int.class);
        System.out.println(constructor);
        //创建对象
        Object person = constructor.newInstance("张三", 23);
        System.out.println(person);
        //空参
        Constructor<Person> constructor1 = cls.getConstructor();
        System.out.println(constructor1);
        //创建对象
        Object person1 = constructor1.newInstance();
        System.out.println(person1);
        //简化
        Object person2 = cls.newInstance();
        System.out.println(person2);

    }
}
