package Commoninterface;

import java.util.function.Function;

/*
    Function接口中的默认方法andThen，用来进行组合操作

    需求
        :吧String的123转换为Intege类型，把结果加10
        再把增加之后的数据转换为String类型
 */
public class FunctionDemo02 {
    //方法
    public static void chagne(String s, Function<String,Integer> fun1,Function<Integer,String> fun2) {
        String str=fun1.andThen(fun2).apply(s);
        System.out.println(str);
    }

    public static void main(String[] args) {
        //定义一个字符串类型的整形
        String s="123";
        //调用方法
        chagne(s,(str)->{
            return Integer.parseInt(s)+10;
        },(i)->{
            return i+"";
        });
    }
}
