package Commoninterface;

import java.util.function.Consumer;

/**
 * 练习，格式化打印“姓名：xx,性别：xx：”
 * 要求将打印姓名的动作作为第一个Consumer的Lambda实例
 * 性别作为第二个
 * 再用andthen连接起来
 */
public class ConsumerDemo03 {
    //方法
    public static void printInfo(String[] arr, Consumer<String> con1,Consumer<String> con2){
        //遍历字符串数组
        for (String message: arr) {
            con1.andThen(con2).accept(message);
        }

    }

    public static void main(String[] args) {
        String[] arr={"迪丽热巴,男","古丽扎娜,女","马尔扎哈,男"};
        printInfo(arr,(message)->{
            String name=message.split(",")[0];
            System.out.print("姓名："+name+"\t");
        },(message)->{
            String sex=message.split(",")[1];
            System.out.println("性别:"+sex);
        });
    }
}
