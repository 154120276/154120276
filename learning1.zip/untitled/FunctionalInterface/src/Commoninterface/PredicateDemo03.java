package Commoninterface;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 * 练习，判断是否为女性且名字为四个字
 *
 */
public class PredicateDemo03 {
    //方法
    public static ArrayList<String> filter(String[] name, Predicate<String> pre1, Predicate<String> pre2){
        ArrayList<String> list=new ArrayList<>();
        for (String s:name) {
           boolean flag=pre1.and(pre2).test(s);
           if (flag) list.add(s);
        }
        return list;
    }

    public static void main(String[] args) {
        String[] arr={"迪丽热巴,女","古丽扎娜,女","马尔扎哈,男"};

        ArrayList<String> list=new ArrayList<>();
        list=filter(arr,(message)->{
            return message.contains("女");
        },(message)->{
            return message.split(",")[0].length()>=4;
        });
        System.out.println(list);
    }
}
