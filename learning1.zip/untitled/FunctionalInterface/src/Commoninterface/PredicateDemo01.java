package Commoninterface;

import java.util.function.Predicate;

/*
    Predicate 接口
    作用：对某种数据类型的数据进行判断，结果返回也给boolean类型的值

    Predicate接口中包含一个抽象方法
        boolean test(T t):用来对指定数据类型的数据进行判断的方法
            结果：符合条件返回True
                不符合返回false
 */
public class PredicateDemo01 {
    /*
        定义一个方法
        参数传递一个String类型字符串
        传递一个Predicate接口，泛型用String
        使用Predicate中的方法test对其判断，并把判断的接口返回
     */
    public static boolean checkString(String s, Predicate<String> pre){
        return pre.test(s);
    }

    public static void main(String[] args) {
        //定义字符串
        String s="NMSL,NMLGB";
        boolean flag=checkString(s,(str)->{
            //对参数传递的字符串进行判断，判断字符串的长度是否大于5
            return str.length()>5;
        });
        System.out.println(flag);

    }
}
