package Commoninterface;

import java.util.function.Predicate;

/*
    逻辑表达式:可以连接多个判断条件
    &&
    ||
    !
    需求:判断一个字符串，有两个条件
    1.长度大于5
    2.是否包含某个字母
    两个条件必须同时满足：&&
 */
public class PredicateDemo02 {
    /*
        方法，传递两个接口
     */
    public static boolean checkString(String name, Predicate<String> pre1, Predicate<String> pre2){
       //return pre1.test(name) && pre2.test(name);
        //return pre1.and(pre2).test(name);
        //return pre1.or(pre2).test(name);
       // return pre1.negate().test(name);
        //return pre1.negate().and(pre2).test(name);
       // return pre1.negate().or(pre2).test(name);
        return !(pre1.test(name)||pre2.test(name));
    }

    public static void main(String[] args) {
        String s="NMSLNMGB";

        boolean flag=checkString(s,(name)->{
            return name.length()>5;
        },(name)->{
            return name.contains(",");
        });
        System.out.println(flag);
    }
}
