package Commoninterface;

import java.util.function.Function;

/*
    Fuction<T,R>接口用来根据一个类型的数据得到另一个类型的数据
        前者称为前置条件，后者称为后置条件
        Function接口中最主要的抽象方法为R apply（T t），根据类型T的参数来获得R的结构
        使用场景例如将String转化为Integer
 */
public class FuncitonDemo01 {
    /*
        定义一个方法
        方法参数传递一个字符串类型的整数
        传一个接口，泛型<String,Integer>
     */
    public static void change(String s, Function<String,Integer> function){
        //Integer i=function.apply(s);
        int i=function.apply(s);
        //自动拆箱（拆包装类）
        System.out.println(i);
    }

    public static void main(String[] args) {
        //定义一个字符串类型的整数
        String s="1234";
        //调用change方法，用Lambda表达式
        change(s,(str)->{
           return Integer.parseInt(str);
        });
    }
}
