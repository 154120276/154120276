package Commoninterface;
/*
    练习:求数组元素最大值
    用Supplier接口作为方法参数类型，通关Lambda表达式求出int数组里的最大值
    提示：接口的泛型使用包装类
 */

import java.util.Arrays;
import java.util.function.Supplier;

public class SupplierDemo02 {
    //定义一个方法
    public static int getMax(int[] i,Supplier<Integer> sup){
        return sup.get();
    }

    public static void main(String[] args) {
        int[] i={5,8,6,22,11,14,1,4,3,7};
        int Max=getMax(i,()->{
            Arrays.sort(i);
            return i[i.length-1];
        });
        System.out.println(Max);
    }
}
