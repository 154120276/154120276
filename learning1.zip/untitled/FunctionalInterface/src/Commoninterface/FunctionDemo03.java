package Commoninterface;
/*
    Function练习
    把name分割并转换为int类型再加100
 */
import java.util.function.Function;

public class FunctionDemo03 {
    public static int getage(String name, Function<String,Integer> fun){
            return fun.apply(name);
    }

    public static void main(String[] args) {
        String name="迪丽热巴,20";
       int i= getage(name,(s)->{
           String str=s.split(",")[1];
           return (int)Integer.parseInt(str)+100;
        });
        System.out.println(i);
    }
}
