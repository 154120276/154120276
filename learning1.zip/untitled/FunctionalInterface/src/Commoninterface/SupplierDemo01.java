package Commoninterface;

import java.util.function.Supplier;

/*
    常用的函数式接口
    java.util.function.Supplier<T>接口包含一个无参的方法，T get（）.y
    用来获取一个泛型参数指定类型的对象数据
    该接口被称为生产型接口，指定接口的泛型是什么类型，那么get就会生产什么类型的数据

 */
public class SupplierDemo01 {
    //定义一个方法，方法的参数传递Supplier接口，泛型指定String，get方法会返回一个String
    public static String getString(Supplier<String> sup){
        return sup.get();
    }

    public static void main(String[] args) {
        //调用getString方法，方法的参数Supplier是一个函数式接口，所以可以传递Lambda表达式
       String s= getString(()->{
            //生产一个字符串并返回
            return "透死里的猴子";
        });
        System.out.println(s);
        //再简化
        String s2= getString(()-> "透死里的猴子");
    }
}
