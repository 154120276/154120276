package cn.zcj.Demo01;

public class MyFuctionalinterfaceImp implements MyFunctionalInterface{
    @Override
    public void method() {

    }
}
