package Lambda;
/*
   使用Lambda优化日志案例
   Lambda的特点：延迟加载
   Lambda使用前提：必须存在函数式接口
 */
public class Demo02Lambda {
    //定义一个显示日志的方法，方法的参数传递日志的等级和MessageBuilder接口
    public static void showLog(int level,MessageBuilder mb){
        //对日志的等级进行判断,如果是一就调用接口中的方法
        if(level==1){
            System.out.println(mb.buildermessage());
        }
    }

    public static void main(String[] args) {
        //定义三个日志信息
        String msg1="Hellow";
        String msg2="World";
        String msg3="Java";

        //调用showlog,参数MessageBuilder是一个函数式接口所以可以传递Lambda表达式

        showLog(1,()->{
            return msg1+msg2+msg3;
        });
        /*
            使用lambda表达式作为参数传递，仅仅是吧参数传递到showlog方法中
            只有满足条件，日志的等级是一级才会调用接口Messagebuilder中的方法
            才会打印字符串的拼接
            如果条件不满足，日志的等级不是1
            接口中的方法就不会执行
            所以拼接字符串的代码就不会执行
            就不会性能浪费
         */
    }
}
