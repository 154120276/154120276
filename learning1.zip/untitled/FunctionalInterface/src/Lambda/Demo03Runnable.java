package Lambda;
/*
      练习
      此方法和直接用Thread类构造方法参数为Runnable没有本质区别
 */
public class Demo03Runnable {
    public static void startThread(Runnable task){
        new Thread(task).start();
    }

    public static void main(String[] args) {
        startThread(new Runnable() {
            @Override
            public void run() {

                System.out.println(Thread.currentThread().getName()+"-->"+"启动了");
            }
        });
        //Lambda优化此调用函数式接口的方法
        startThread(()->{
            System.out.println(Thread.currentThread().getName()+"也启动了");
        });
        //再优化
        startThread(()-> System.out.println(Thread.currentThread().getName()+"也启动了"));
    }
}
