package Lambda;
/*
    日志案例
    发现以下代码存在性能浪费的问题
    调用showlog方法传递的第二个参数是拼接后的字符串
    先把字符串拼接好，再调用showlog方法
    showlog方法中如果传递的不是1级
    那么就不会输出拼接后的字符串
    所以就浪费了字符串拼接
 */
public class Demo01Logger {
    //定义一个根据日志的级别显示日志信息的方法
    public static void showLog(int level,String message){
        //对日志的等级进行判断,如果是一就输出日志信息
        if(level==1){
            System.out.println(message);
        }
    }

    public static void main(String[] args) {
        //定义三个日志信息
        String msg1="Hellow";
        String msg2="World";
        String msg3="Java";

        //调用showlog
        showLog(1,msg1+msg2+msg3);
        showLog(2,msg1+msg2+msg3);

    }
}

