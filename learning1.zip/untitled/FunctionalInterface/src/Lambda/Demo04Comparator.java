package Lambda;

import java.util.Arrays;
import java.util.Comparator;

/*
    如果一个方法的返回值是一个函数式接口，那么就可以直接返回一个Lambda表达式
    当需要通过一个方法来获取一个java.util.Comparator接口类型的对象作为排序器时，就可以调该方法获取

 */
public class Demo04Comparator
{
   /* //定义一个方法，返回值类型为函数式接口Comparator
    public static Comparator<String> getComparator(){
        //方法的返回值是一个接口，那么我们可以返回这个接口的匿名内部类
        return new Comparator<String>() {
            @Override
            public int compare(String s, String t1) {
               //按字符串降序排序
                return t1.length()-s.length();
            }
        }
    }*/
   /*public static Comparator<String> getComparator(){
       return (String o1, String o2)->{
           return o2.length()-o1.length();
       };
   }*/
    //再优化
    public static Comparator<String> getComparator(){
        return ( o1,  o2)->o2.length()-o1.length();
    }

    public static void main(String[] args) {
        String[] arr={"aaa","b","cccccccccccccc","dddddd"};
        //利用工具类输出排序前的数组
        System.out.println(Arrays.toString(arr));
        //调用sort方法排序
        Arrays.sort(arr,getComparator());
        System.out.println("===================================");
        //输出排序后的数组
        System.out.println(Arrays.toString(arr));
    }
}
