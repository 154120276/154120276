package zcj.Jsoup;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
/*
    Element对象
 */

public class JsoupDemo03 {
    public static void main(String[] args) throws IOException {
        //1.获取Document对象，根据xml文档获取
        //2.1获取student.xml的path
        String path = JsoupDemo03.class.getClassLoader().getResource("student.xml").getPath();
        //2.2解析xml文档加载文档进内存，获取dom树-->
        Document document = Jsoup.parse(new File(path), "utf-8");
        //获取Document对象获取name标签，获取所有的name标签
        Elements elements = document.getElementsByTag("name");
        //通过Element对象获取子标签对象
        Element element_student = document.getElementsByTag("student").get(0);
        Elements ele_name = element_student.getElementsByTag("name");
        System.out.println(ele_name.size());
        //获取student对象的属性值
        String number = element_student.attr("number");
        System.out.println(number);
        String text = ele_name.text();
        String html = ele_name.html();
        System.out.println(text);
        System.out.println(html);
    }
}
