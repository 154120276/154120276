package zcj.Jsoup;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.net.URL;
/*
 Jsoup对象功能
 */

public class JsoupDemo2 {
    public static void main(String[] args) throws IOException {
        //1.获取Document对象，根据xml文档获取
        //2.1获取student.xml的path
        String path = JsoupDemo2.class.getClassLoader().getResource("student.xml").getPath();
        //2.2解析xml文档加载文档进内存，获取dom树-->
       /* Document document = Jsoup.parse(new File(path), "utf-8");*/
       //第二种，直接给XML的代码
        /* String str="<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n" +
                "\t<student>\n" +
                " \t<student number=\"heima_0001\">\n" +
                " \t\t<name>tom</name>\n" +
                " \t\t<age>18</age>\n" +
                " \t\t<sex>male</sex>\n" +
                " \t</student>\n" +
                "\n" +
                "\t<student number=\"heima_0002\">\n" +
                "\t\t<name>jack</name>\n" +
                "\t\t<age>19</age>\n" +
                "\t\t<sex>female</sex>\n" +
                "\t</student>\n" +
                "\n" +
                "\n" +
                "\t\t</student>";
        Document document = Jsoup.parse(str);*/

        //3.通过网络路径来获取指定的Html或者xml的文档对象，parse(URL url,int timeoutMillis)
        URL url=new URL("https://baike.baidu.com/item/%E5%8F%AF%E6%89%A9%E5%B1%95%E6%A0%87%E8%AE%B0%E8%AF%AD%E8%A8%80/2885849?fromtitle=xml&fromid=86251&fr=aladdin");
        Document document = Jsoup.parse(url, 10000);
        System.out.println(document);
    }
}
