package cn.zcj.SpringJDBC;

import cn.zcj.util.JDBCDruidUtils;
import org.junit.Test;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/*

 */
public class JDBCDemo03 {
    private JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils.getDataSource());
    //注意：这个方法查询的结果集只能是1
    @Test
    public void test1(){

        String sql="select * from emp where id=? ";
        Map<String, Object> map = template.queryForMap(sql, 1001);
        System.out.println(map);
        //{id=1001, ename=孙悟空, job_id=4, mgr=1004, joindate=2000-12-17, salary=10000.00, bonus=null, dept_id=20}
    }
    //查询所有数据，并将其封装成list集合
    @Test
    public void test2(){
        String sql="select * from emp ";
        List<Map<String, Object>> list = template.queryForList(sql);
        for (Map<String, Object> map : list) {
            System.out.println(map);
        }
    }
    //查询所有数据，并将其封装成emp对象的list集合
    @Test
    public void test3(){
        String sql="select * from emp ";
        List<emp> list = template.query(sql, new RowMapper<emp>() {
            @Override
            public emp mapRow(ResultSet rs, int i) throws SQLException {
                emp emp = new emp();
                int id = rs.getInt("id");
                String ename = rs.getString("ename");
                int job_id = rs.getInt("job_id");
                int mgr = rs.getInt("mgr");
                Date joindate = rs.getDate("joindate");
                double salary = rs.getDouble("salary");
                double bonus = rs.getDouble("bonus");
                int dept_id = rs.getInt("dept_id");
                emp.setId(id);
                emp.setEname(ename);
                emp.setJob_id(job_id);
                emp.setMgr(mgr);
                emp.setJoindate(joindate);
                emp.setSalary(salary);
                emp.setBonus(bonus);
                emp.setDept_id(dept_id);
                return emp;
            }
        });
        for (emp emp : list) {
            System.out.println(emp);
        }
    }
    //查询所有数据，并将其封装成emp对象的list集合,简化
    @Test
    public void test4(){
        String sql="select * from emp ";
        List<emp> list = template.query(sql,new BeanPropertyRowMapper<emp>(emp.class));

        for (emp emp : list) {
            System.out.println(emp);
        }
    }
    //查询总记录数据,queryForObject基本用来执行聚合函数的
    @Test
    public void test5(){
        String name="emp";
        String sql="select count(id) from "+name;
        Long long1 = template.queryForObject(sql, Long.class);
        System.out.println(long1);
    }
}
