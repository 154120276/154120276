package cn.zcj.SpringJDBC;

import cn.zcj.util.JDBCDruidUtils;
import org.junit.Test;
import org.springframework.jdbc.core.JdbcTemplate;
/*
    执行DML语句
 */
public class JDBCTemplateDemo02 {
    private JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils.getDataSource());
    @Test
    public void test1(){

        String sql="update emp set salary= ? where id= ? ";
        int count=template.update(sql,10000,1001);
        System.out.println(count);
    }
    @Test
    public void test2(){
        JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils.getDataSource());
        String sql="insert into emp(id,ename,dept_id) values(?,?,?) ";
        int count=template.update(sql,1015,"郭靖",10);
        System.out.println(count);
    }
    @Test
    public void test3(){
        JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils.getDataSource());
        String sql="delete from emp where id=?";
        int count=template.update(sql,1015);
        System.out.println(count);
    }

}
