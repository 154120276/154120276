package cn.zcj.jdbc;

import cn.zcj.SpringJDBC.emp;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/*  练习
   定义一个方法：查询emp表并把他封装成对象
    */
public class JDBCdemo06 {
   public List<emp> findall(){
       Connection conn = null;
       Statement statement = null;
       ResultSet rs = null;
       List<emp> list=new ArrayList<emp>();
       //1.注册驱动（可不写）
       try {
           //Class.forName("com.mysql.jdbc.Driver");//mysql 5之后可以省略
           // 2.定义sql
           /* String sql = "select * from account";*/
           String sql = "select * from emp";
           //3.获取Connection对象
           conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db2", "root", "zcjdsql");
           //4.获取执行对象statement
           statement = conn.createStatement();
           //5.执行
           rs = statement.executeQuery(sql);
           //6.遍历结果集，封装对象，装载集合
           emp emp=null;
           while(rs.next()){
               //获取数据
               int id = rs.getInt("id");
               String ename = rs.getString("ename");
               int job_id = rs.getInt("job_id");
               int mgr = rs.getInt("mgr");
               Date joindate = rs.getDate("joindate");
               double salary = rs.getDouble("salary");
               double bonus = rs.getDouble("bonus");
               int dept_id = rs.getInt("dept_id");
               emp=new emp();
               emp.setId(id);emp.setEname(ename);emp.setJob_id(job_id);
               emp.setMgr(mgr);emp.setJoindate(joindate);emp.setSalary(salary);
               emp.setBonus(bonus);emp.setDept_id(dept_id);

               list.add(emp);
           }


       } catch (Exception e) {
           e.printStackTrace();
       } finally {
           //7.释放资源
           //statement.close();直接这样写是有问题的，有可能会有空指针异常
           if (rs != null) {
               try {
                   rs.close();
               } catch (SQLException throwables) {
                   throwables.printStackTrace();
               }
           }
           if (statement != null) {
               try {
                   statement.close();
               } catch (SQLException throwables) {
                   throwables.printStackTrace();
               }
           }
           if (conn != null) {
               try {
                   conn.close();
               } catch (SQLException throwables) {
                   throwables.printStackTrace();
               }

           }

       }
       return list;
   }


    public static void main(String[] args) {
       List<emp> list=new JDBCdemo06().findall();
       for (emp emp : list) {
           System.out.println(emp);
        }
        System.out.println(list.size());
    }
}
