package cn.zcj.jdbc;

import java.sql.*;

/*
   Resultset 结果集运用
    */
public class JDBCdemo05 {
    //1.注册驱动（可不写）
    public static void main(String[] args) {
        Connection conn = null;
        Statement statement = null;
        ResultSet rs = null;
        //1.注册驱动（可不写）
        try {
            //Class.forName("com.mysql.jdbc.Driver");//mysql 5之后可以省略
            // 2.定义sql
           /* String sql = "select * from account";*/
            String sql = "select * from dept";
            //3.获取Connection对象
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db2", "root", "zcjdsql");
            //4.获取执行对象statement
            statement = conn.createStatement();
            //5.执行
            rs = statement.executeQuery(sql);
            //6.处理结果
            //6.1.让光标向下移动一行

            //6.2.获取数据
            /*while ( rs.next()!=false) {
                int id = rs.getInt(1);
                String name = rs.getString("name");
                double balance = rs.getDouble(3);
                System.out.println("id:" + id + "----" + "姓名:" + name + "------" + "余额:" + balance);
            }*/
            while ( rs.next()!=false) {
                int id = rs.getInt(1);
                String name = rs.getString("dname");
                String loc= rs.getString(3);
                System.out.println("id:" + id + "----" + "部门:" + name + "------" + "地址:" + loc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //7.释放资源
            //statement.close();直接这样写是有问题的，有可能会有空指针异常
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
                if (statement != null) {
                    try {
                        statement.close();
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }
                }
                if (conn != null) {
                    try {
                        conn.close();
                    } catch (SQLException throwables) {
                        throwables.printStackTrace();
                    }

                }

        }
    }
}
