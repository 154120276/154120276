package cn.zcj.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*
    account表 删除一条记录
 */
public class JDBCdemo04 {
    //1.注册驱动（可不写）
    public static void main(String[] args) {
        Connection conn=null;
        Statement statement=null;
        //1.注册驱动（可不写）
        try {
            //Class.forName("com.mysql.jdbc.Driver");//mysql 5之后可以省略
            // 2.定义sql
            String sql="delete from account where id=3";
            //3.获取Connection对象
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/db2", "root", "zcjdsql");
            //4.获取执行对象statement
            statement = conn.createStatement();
            //5.执行
            int count=statement.executeUpdate(sql);
            if(count>0){
                System.out.println("删除成功！");
            }else{
                System.out.println("删除失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            //6.释放资源
            //statement.close();直接这样写是有问题的，有可能会有空指针异常
            if (statement!=null) {
                try {
                    statement.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
            if (conn!=null) {
                try {
                    conn.close();
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                }
            }
        }
    }

}
