package cn.zcj.jdbc;

import cn.zcj.SpringJDBC.emp;
import cn.zcj.util.JDBCUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/*  练习
   定义一个方法：查询emp表并把他封装成对象
    */
public class JDBCdemo07 {
   public List<emp> findAll(){
       Connection conn = null;
       Statement statement = null;
       ResultSet rs = null;
       List<emp> list=new ArrayList<emp>();

       try {
           conn = JDBCUtils.getConnection();
           // 2.定义sql
           /* String sql = "select * from account";*/
           String sql = "select * from emp";

           //4.获取执行对象statement
           statement = conn.createStatement();
           //5.执行
           rs = statement.executeQuery(sql);
           //6.遍历结果集，封装对象，装载集合
           emp emp=null;
           while(rs.next()){
               //获取数据
               int id = rs.getInt("id");
               String ename = rs.getString("ename");
               int job_id = rs.getInt("job_id");
               int mgr = rs.getInt("mgr");
               Date joindate = rs.getDate("joindate");
               double salary = rs.getDouble("salary");
               double bonus = rs.getDouble("bonus");
               int dept_id = rs.getInt("dept_id");
               emp=new emp();
               emp.setId(id);emp.setEname(ename);emp.setJob_id(job_id);
               emp.setMgr(mgr);emp.setJoindate(joindate);emp.setSalary(salary);
               emp.setBonus(bonus);emp.setDept_id(dept_id);

               list.add(emp);
           }


       } catch (Exception e) {
           e.printStackTrace();
       } finally {
           //7.释放资源
           //statement.close();直接这样写是有问题的，有可能会有空指针异常
           JDBCUtils.close(rs,statement,conn);
       }
       return list;
   }


    public static void main(String[] args) {
       List<emp> list=new JDBCdemo07().findAll();
       for (emp emp : list) {
           System.out.println(emp);
        }
        System.out.println(list.size());
    }
}
