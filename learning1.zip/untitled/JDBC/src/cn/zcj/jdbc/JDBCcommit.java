package cn.zcj.jdbc;

import cn.zcj.util.JDBCUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCcommit {
    public static void main(String[] args) {
        //获取连接
        Connection conn=null;
        PreparedStatement pstmt1=null;
        PreparedStatement pstmt2=null;

        try {
            conn= JDBCUtils.getConnection();
            //开启事务
            conn.setAutoCommit(false);
            //2.定义sql
            //2.1张三-500
            String sql1="update account set balance=balance- ? where id= ?";
            //2.2李四+500
            String sql2="update account set balance=balance+ ? where id= ?";
            //3.获取执行sql对象
            pstmt1 = conn.prepareStatement(sql1);
            pstmt2 = conn.prepareStatement(sql2);
            //4.设置参数
            pstmt1.setInt(1,500);
            pstmt1.setInt(2,1);
            pstmt2.setInt(1,500);
            pstmt2.setInt(2,2);
            //执行sql
           pstmt1.executeUpdate();
           pstmt2.executeUpdate();
           //提交事务
           conn.commit();

        } catch (Exception e) {
            //事务的回滚
            try {
                if (conn!=null) {
                    conn.rollback();
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            e.printStackTrace();
        }finally {
            JDBCUtils.close(pstmt1,conn);
            JDBCUtils.close(pstmt2,null);
        }
    }
}
