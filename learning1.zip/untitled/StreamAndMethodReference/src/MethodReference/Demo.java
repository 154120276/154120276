package MethodReference;
/*
    类的构造器引用
 */
public class Demo {
    //定义一个方法，参数传递姓名和PersonBuilder接口
    public static void printName(String name,PersonBuilder p){
        System.out.println(p.BuilderPerson(name).getName());
    }

    public static void main(String[] args) {
        //调用printName方法，方法的参数是函数式接口
        printName("张三",(name)->{
            return new person(name);
        });
        //方法引用,构造方法得已知
        printName("迪丽热巴",person::new);
    }
}
