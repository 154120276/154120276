package MethodReference;
/*
    通过类名引用静态成员方法
    类已经存在，静态方法也存在
    就可以通过类名直接引用静态成员方法

 */
public class StaticMethodReference {
    //定义一个接口方法参数传递要计算的整数和函数式接口
    public static int Method(int number,Calcabel  c){
       return c.calsAbs(number);
    }

    public static void main(String[] args) {
        //调用Method方法，传递整数和Lambda表达式
       int o= Method(-10,i->{
            return Math.abs(i);
        });
        System.out.println(o);

        /*
        使用方法引用优化lambda表达式
         */
       int o2= Method(-452,Math::abs);
        System.out.println(o2);
    }
}
