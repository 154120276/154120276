package MethodReference;
@FunctionalInterface
public interface Greatbale {
    //见面的方法
    void great();
}
