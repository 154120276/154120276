package MethodReference;
//定义父类
public class Human {
    //定义方法sayHello
    public void sayHello(){
        System.out.println("Hello,我是Human");
    }

}
