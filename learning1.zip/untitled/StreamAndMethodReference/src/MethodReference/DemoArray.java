package MethodReference;

import java.util.Arrays;

/*
    数组的构造器引用
 */
public class DemoArray {
    /*
    定义一个方法
    方法的参数传递创建数组的长度和函数式接口
    方法内部根据长度使用接口中的方法
     */

    public static int[] creatArray(int length,ArrayBuilder arrayBuilder){
        return arrayBuilder.buliderArray(length);
    }

    public static void main(String[] args) {
        //方法引用
       int[] arr= creatArray(10,int[]::new);
        System.out.println(arr.length);
        System.out.println(Arrays.toString(arr));
    }
}
