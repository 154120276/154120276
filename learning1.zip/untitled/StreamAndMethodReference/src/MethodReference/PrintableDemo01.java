package MethodReference;

public class PrintableDemo01 {
    //定义一个方法，参数传递Printable接口对字符串打印
    public static void PrintString(Printable p){
        p.print("HelloWorld");
    }

    public static void main(String[] args) {
        //调用PrintString方法，传递lambda表达式
        PrintString((s)->{
            System.out.println(s);
        });
        /*
            分析：
            Lambda表达式的目的，打印参数传递的字符串
            把参数S，传递给了System.out对象，调用他的方法Println对字符串进行输出
            注意：
                1.System.out对象是已经存在的
                2.println方法也是已经存在的
                所以我们可以用方法引用来优化Lambda表达式
                可以用System.out方法直接引用Println方法
         */
        PrintString(System.out::println);
    }
}
