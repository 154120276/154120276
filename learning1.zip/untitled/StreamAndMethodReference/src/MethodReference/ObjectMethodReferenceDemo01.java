package MethodReference;
/*
    通过对象名引用成员方法
    使用前提是对象名是已经存在的，成员方法也是已经存在的
    就可以使用对象名来引用成员方法
 */
public class ObjectMethodReferenceDemo01 {
    public static void PrintString(Printable p){
        p.print("Hello");
    }

    public static void main(String[] args) {
        //调用PrintString方法，参数是一个函数式接口，所以可以传递Lambda
        PrintString((s)->{
            //创建MethodRerObject对象
            MethodRerObject object=new MethodRerObject();
            //调用对象中的成员方法把字符串按照大写输出
            object.printUpperCase(s);
        });
        /*
            使用方法引用优化Lambda
            对象已经存在的
            成员方法也存在
            所以可以使用对象名引用成员方法
         */
        MethodRerObject obj=new MethodRerObject();
        PrintString(obj::printUpperCase);
    }
}
