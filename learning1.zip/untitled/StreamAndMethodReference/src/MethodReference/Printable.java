package MethodReference;
/*
    定义一个打印函数式接口
 */
@FunctionalInterface
public interface Printable {
    void print(String s);
}
