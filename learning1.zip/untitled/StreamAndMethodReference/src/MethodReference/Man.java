package MethodReference;
//定义子类
public class Man extends Human {
    //子类重写父类sayHello的方法

    @Override
    public void sayHello() {
        System.out.println("Hello，我是Man!");
    }
    //定义一个方法传递Greatable接口
    public void method(Greatbale g){
        g.great();
    }
    public void show(){
        //调用method方法，方法的参数是一个函数式接口，可传递Lambda
       /* method(()->{
            //创建父类Human对象
            Human h=new Human();
            h.sayHello();
        });*/
        //因为有子夫类关系，所以存在一个关键字super，所以我们可以直接使用super调用父类的成员方法
        /*method(()->{
            super.sayHello();
        });*/
        /*
            使用super引用类的成员方法
            super是已经存在的
            父类的方法sayHellow也是存在的
            所以我们可以用super引用父类的成员方法
         */
        method(super::sayHello);
        /*
            使用this引用类的成员方法
            this是已经存在的
            自己的方法sayHellow也是存在的
            所以我们可以用this来引用本类的成员方法
         */
        method(this::sayHello);
    }



    public static void main(String[] args) {
        new Man().show();
    }
}
