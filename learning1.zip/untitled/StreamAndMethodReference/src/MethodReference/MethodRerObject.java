package MethodReference;

public class MethodRerObject {
    //定义一个成员方法，传递字符串，把字符串按照大写输出
    public  void printUpperCase(String s){
        System.out.println(s.toUpperCase());
    }
}
