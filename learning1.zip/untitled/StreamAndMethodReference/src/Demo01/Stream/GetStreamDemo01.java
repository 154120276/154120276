package Demo01.Stream;

import java.util.*;
import java.util.stream.Stream;

/*
    Stream接口是Java 8新加入的最常用的流接口（并不是函数式接口
    获取一个流的常用方法有两种
        所有的Collection集合都可以通过默认方法Stream获取
        dafalut Stream<T> stream();
        Stream接口静态方法of可以获取对应的流
        static<T> Stream<T> of(T...values)
        参数是一个可变参数，那么我们可以传递一个数组

 */
public class GetStreamDemo01 {
    //把集合转换为Stream流
    public static void main(String[] args) {
        List<String> list=new ArrayList<>();
        Stream<String> stream1 = list.stream();

        Set<String> set=new HashSet<>();
        Stream<String> stream2 = set.stream();

        Map<String,String> map=new HashMap<>();
        //先获取键，存储到一个Set集合中
        Set<String> keyset=map.keySet();
        Stream<String> stream3 = keyset.stream();
        //获取值，存储到一个Collection集合中
        Collection<String> values=map.values();
        Stream<String> stream4 = values.stream();

        //获取键值对（键与值得映射关系 EntrySet）
        Set<Map.Entry<String, String>> entries=map.entrySet();
        Stream<Map.Entry<String, String>> stream5 = entries.stream();

        //也可以把数组转换为Stream流
        Stream<Integer> stream6 = Stream.of(1, 2, 3, 4, 5);

        //可变参数可传数组
        Integer[] arr={1,2,3,4,5};
        Stream<Integer> stream7= Stream.of(arr);
        String[] arr2={"a","b","c"};
        Stream<String> stream8 = Stream.of(arr2);
    }


}
