package Demo01.Stream;

import java.util.ArrayList;
import java.util.List;

/*
    使用Stream流的方式，遍历集合，对集合中的数据进行过滤
    1.8JDK之后才有的
    关注的是做什么，而不是怎么做
 */
public class Demo01Stream {
    public static void main(String[] args) {
        List<String> list=new ArrayList<>();
        list.add("张无忌");  list.add("周芷柔");  list.add("赵敏");
        list.add("张强");  list.add("张三丰");
        //对List集合中的元素进行过滤，只要以张开头的元素，存到一个新数组
        //对List集合中的元素进行过滤，只要以长度为3的，存到一个新数组
        //究极简化
        list.stream().
                filter(name-> name.startsWith("张"))
                .filter(name->name.length()==3)
                .forEach(name-> System.out.println(name));
       /* list.stream().
                filter((name)->{
                        return name.startsWith("张");
                })
                .filter((name)->{
                    return name.length()==3;
                }).forEach(name-> {
                    System.out.println(name);
        });*/

    }

}
