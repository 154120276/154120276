package Demo01.Stream;

import java.util.stream.Stream;

/*
        Stream流中的常用方法concat用于把流组合到一起
        如果有两个流，希望合并为一个流，那么可用Stream接口的静态方法concat

     */
public class StreamConcat {
        public static void main(String[] args) {
            //获取两个流
            String[] arr={"美羊羊","喜羊羊","懒羊羊","灰太狼","红太狼"};
            Stream<String> stream = Stream.of(arr);
            Stream<String> stream1 = Stream.of("法外狂徒张三", "李四", "王五", "赵六", "田七");
            Stream stream2=Stream.concat(stream,stream1);
            stream2.forEach(name-> System.out.print(name+"  "));
        }
}
