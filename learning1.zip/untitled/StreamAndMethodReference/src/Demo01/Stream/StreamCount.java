package Demo01.Stream;

import java.util.ArrayList;
import java.util.List;

/*
        Stream流中的常用方法count：用于统计Stream流中的元素个数
        返回的是long类型 long count();
        是一个终结方法，不能再调用其他Stream流中的方法了
 */
public class StreamCount {
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<>();
        list.add(1);list.add(2);list.add(55);list.add(88);
        list.add(13);list.add(12);list.add(66);list.add(77);
        long count=list.stream().count();
        System.out.println(count);
    }
}
