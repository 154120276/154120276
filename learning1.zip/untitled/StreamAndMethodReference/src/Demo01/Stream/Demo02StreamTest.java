package Demo01.Stream;

import java.util.ArrayList;
import java.util.stream.Stream;

/*
    Stream流练习题
 */
public class Demo02StreamTest {
    public static void main(String[] args) {
        //第一支队伍
        ArrayList<String> one=new ArrayList<>();
        one.add("迪丽热巴"); one.add("宋远桥"); one.add("苏星河"); one.add("石破天");
        one.add("石中玉"); one.add("老子"); one.add("庄子"); one.add("洪七公");
       //1.只要名字有三个字的成员姓名，存储到新的集合中
        Stream<String> onestream = one.stream().filter((name) -> {
            return name.length() == 3;
        }).limit(3);
        //2.再只要前三个人

        //第二支队伍
        ArrayList<String> two=new ArrayList<>();
        two.add("古丽扎娜");two.add("张无忌");two.add("赵丽颖");two.add("张三丰");
        two.add("尼古拉斯赵四");two.add("张天爱");two.add("张二狗");
        //1.只要姓张的
        //2.不要前面两个人
        ArrayList<Person> all=new ArrayList<>();
        Stream<String> twoStream = two.stream().filter(name -> name.startsWith("张")).skip(2);
        Stream.concat(onestream, twoStream).map(name->new Person(name)).forEach((person)->{
            all.add(person);
        });
        System.out.println(all);

        //创建一个Person对象集合,将两个队伍合并成一个队伍

    }
}
