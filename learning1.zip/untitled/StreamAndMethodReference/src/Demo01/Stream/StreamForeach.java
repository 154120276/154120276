package Demo01.Stream;

import java.util.stream.Stream;

/*
        Stream流中常用的方法forEach
        该方法接收一个Consumer接口函数，会将每一个该元素交给该函数进行处理
        Consumer接口是一个消费型的函数式接口，可传Lambda表达式消费数据
        简单记:
        forEach就是用来遍历流中的数据
        是一个终结方法，遍历之后就不能继续调用Stream流中的其他方法

     */
public class StreamForeach {
        public static void main(String[] args) {
            //获取流
            Stream<String> stream = Stream.of("法外狂徒张三", "李四", "王五", "赵六", "田七");
           stream.forEach((name)->{
               System.out.println(name);
               if (name=="法外狂徒张三") System.out.println("强奸了");
           });
        }
}
