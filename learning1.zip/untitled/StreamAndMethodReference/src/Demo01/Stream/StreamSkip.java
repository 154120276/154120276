package Demo01.Stream;

import java.util.stream.Stream;

/*
    Stream流中的常用方法skip：用于截取流中的元素
    方法可对流进行截取，跳过前几个
        参数是一个long类型，如果集合当前长度大于参数则进行跳过，否则得到一个长度为0的空流
        skip方法是一个延迟方法，只是对流中的元素进行截取，返回的是一个新的流，可继续用其他方法

 */
public class StreamSkip {
    public static void main(String[] args) {
        //获取流
        String[] arr={"美羊羊","喜羊羊","懒羊羊","灰太狼","红太狼"};
        Stream<String> stream = Stream.of(arr).skip(3);
        stream.forEach(name-> System.out.println(name));
    }
}
