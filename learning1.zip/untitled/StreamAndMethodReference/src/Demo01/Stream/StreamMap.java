package Demo01.Stream;

import java.util.stream.Stream;

/*
    如果需要将流中的元素映射到另一个流中，可使用map方法
    该接口需要一个Funciton函数式接口，可以将当前流T类型的数据转换为另一种类型的流

 */
public class StreamMap {
    public static void main(String[] args) {
        //获取流
        Stream<String> stream = Stream.of("1", "2", "3", "544", "888");
        //使用map方法把字符串类型的整数转换为Integer类型的整数
        Stream<Integer> stream1 = stream.map((String name) -> {
            return Integer.parseInt(name);
        });
        stream1.forEach(i-> System.out.println(i+10));
    }
}
