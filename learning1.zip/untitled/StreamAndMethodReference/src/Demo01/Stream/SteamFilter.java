package Demo01.Stream;

import java.util.stream.Stream;

/*
        Stream流中的常用方法filter：用于对Stream流中的数据进行过滤
        filter方法的参数Predicate是一个函数式接口，对数据进行过滤

     */
public class SteamFilter {
        public static void main(String[] args) {
            //创建流
            Stream<String> stream = Stream.of("张三丰", "张翠山", "赵敏", "周芷若", "张无忌");
            //对Stream流中的元素进行过滤，只要姓张的人
            Stream<String> stream1 = stream.filter((name) -> {
                return name.startsWith("张");
            });
            stream1.forEach(name-> System.out.println(name));
            /*
                Stream流属于管道流，只能被消费（使用）一次
                第一个Stream流调用完毕方法，数据就会流转到下一个Stream上
                而第一个Stream流已经使用完毕就会关闭了
             */
            //stream1.forEach(name-> System.out.println(name));
            //stream.forEach(name-> System.out.println(name));
            //不能二次使用
        }
}
