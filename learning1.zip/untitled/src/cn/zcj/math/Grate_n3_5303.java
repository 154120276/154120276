package cn.zcj.math;

import java.util.Arrays;

public class Grate_n3_5303 {
    public static void main(String[] args) {
        Integer[] code= {80,96,77,59,66,48,75,52,69,79,98,86,89,45,61,99,92,85,81};
        Arrays.sort(code);//排序
        System.out.println("最好的成绩为:"+code[code.length-1]);//输出最好成绩
        double sum=0;//计算平均值的总成绩
        for (Integer i : code) {
            sum+=i;
        }
        double average=sum/code.length;//计算平均值,double跟int运算结果为double类型
        System.out.println("平均值为："+average);
        int  Fail = 0,Pass = 0,Secondary = 0,good = 0,excellent = 0;
        for (Integer i : code) {//foreach计算各档次人数
            if(i<60) Fail++;
            else if(i<70) Pass++;
            else if(i<80)	Secondary++;
            else if(i<90)	good++;
            else excellent++;
        }
        System.out.println("不及格人数:"+Fail);
        System.out.println("及格人数:"+Pass);
        System.out.println("中等人数:"+Secondary);
        System.out.println("良好人数:"+good);
        System.out.println("优秀人数:"+excellent);
    }
}