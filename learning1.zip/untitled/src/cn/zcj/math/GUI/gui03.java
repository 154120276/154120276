package cn.zcj.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class gui03 { private static final int WIDTH=500;
    private static final int HEIGHT=400;
    public static void main(String[] args) {
        JFrame jf = initJFrame();
        //设置窗体可见
        jf.setVisible(true);
        jf.setLayout(new GridLayout(3,1));
        JPanel jp1=new JPanel(new FlowLayout());
        JPanel jp2=new JPanel(new FlowLayout());
        JPanel jp3=new JPanel(new FlowLayout());
        //文本提示信息
        JLabel label1=new JLabel("请输入用户名",new ImageIcon("img/user.png"),JLabel.CENTER);
        JLabel label2=new JLabel("请输入密码",new ImageIcon("img/password.png"),JLabel.CENTER);
        //文本框
        JTextField jtf=new JTextField(20);
        JPasswordField jpf=new JPasswordField(20);
        //登录按钮
        JButton jb=new JButton("登录");
        //给登录按钮绑定事件,点击按钮执行方法里面的代码
        jb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("我登录了");
                String user = jtf.getText();
                String password = jpf.getText();
                System.out.println(user);
                System.out.println(password);
                JOptionPane.showMessageDialog(null,"登录成功");
                /*int i = JOptionPane.showConfirmDialog(null, "确定删除吗");
                System.out.println(i);*/
            }
        });
        jp1.add(label1);jp1.add(jtf);
        jp2.add(label2);jp2.add(jpf);
        jp3.add(jb);
        jf.add(jp1);jf.add(jp2);jf.add(jp3);
        //验证布局
        jf.validate();



    }
    //初始化登录窗口的方法
    public static JFrame initJFrame(){
        JFrame jf=new JFrame();
        //默认坐标是0.0，左上角是原点
        jf.setLocation(300,100);
        //给窗体加标题
        jf.setTitle("朱长江开发的即时聊天室客户端");
        //修改窗体图标gui03
        jf.setIconImage(new ImageIcon("img/Sign_in.gif").getImage());
        //设置关闭窗口退出虚拟机
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //获取屏幕尺寸并设置窗口大小
        Toolkit toolkit=Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        //显示在屏幕中间
        jf.setBounds((screenSize.width-WIDTH)/2,(screenSize.height-HEIGHT)/2,WIDTH,HEIGHT);
        return jf;
    }

}
