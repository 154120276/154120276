package cn.zcj.GUI;

import javax.swing.*;

public class gui01 {
    public static void main(String[] args) {
        JFrame jf=new JFrame();
        //默认坐标是0.0，左上角是原点
        jf.setLocation(300,100);
        //给窗体加标题
        jf.setTitle("朱长江开发的即时聊天室客户端");
        //设置窗体可见
        jf.setVisible(true);
        //修改窗体图标
        jf.setIconImage(new ImageIcon("img/Sign_in.gif").getImage());
        //设置关闭窗口退出虚拟机
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
       /* //默认坐标是0.0，左上角是原点
        jf.setLocation(300,100);
        //设置尺寸
        jf.setSize(900,700);*/
        //也可以通过一个方法设置
        jf.setBounds(300,100,900,700);
    }
}
