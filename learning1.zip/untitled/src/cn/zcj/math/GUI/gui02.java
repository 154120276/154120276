package cn.zcj.GUI;

import javax.swing.*;
import java.awt.*;

public class gui02 {
    private static final int WIDTH=500;
    private static final int HEIGHT=400;
    public static void main(String[] args) {
        JFrame jf = initJFrame();
        //设置窗体可见
        jf.setVisible(true);
        //设置布局格式
        //jf.setLayout(new BorderLayout(10,20));//边界布局和其间隙
        /*jf.setLayout(new FlowLayout(FlowLayout.CENTER,10,10));*///流式布局
        //jf.setLayout(new GridLayout());//网格布局
        //创建一个Jpanel
        JPanel jp1=new JPanel();
        JPanel jp2=new JPanel();
        //创建一个按钮
        JButton jb=new JButton("登录");
        jb.setSize(10,20);
        //把按钮添加 到Jframe里面
        //jf.add(jb,BorderLayout.SOUTH);边界布局

    }
    //初始化登录窗口的方法
    public static JFrame initJFrame(){
        JFrame jf=new JFrame();
        //默认坐标是0.0，左上角是原点
        jf.setLocation(300,100);
        //给窗体加标题
        jf.setTitle("朱长江开发的即时聊天室客户端");
        //修改窗体图标
        jf.setIconImage(new ImageIcon("img/Sign_in.gif").getImage());
        //设置关闭窗口退出虚拟机
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        //获取屏幕尺寸并设置窗口大小
        Toolkit toolkit=Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        //显示在屏幕中间
        jf.setBounds((screenSize.width-WIDTH)/2,(screenSize.height-HEIGHT)/2,WIDTH,HEIGHT);
        return jf;
    }
}
