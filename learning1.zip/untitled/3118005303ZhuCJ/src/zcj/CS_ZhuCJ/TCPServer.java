package zcj.CS_ZhuCJ;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
    TPC通信服务端：接受客户端的请求，读取客户端发送的数据，给客户端回写数据
    表示服务器的类
    java.net.ServerSocket 此类实现服务器套接字

    构造方法
        ServerSocket(int port);创建绑定特定的端口的服务器套接字

    服务器必须明确一件事情，必须的知道是哪个客户端请求的服务器
    所以可以使用accept方法获取请求的客户端对象Socket
    成员方法:
        Socket accept() 侦听并接受此套接字的连接

    服务器的实现步骤：
     1.创建服务器ServerSocket对象和系统要指定的端口号
     2.使用ServerSocket中的accept方法获取刀请求的客户端对象Socket
     3.使用Socker对象中的方法getInputStream()获取网络字节输入流InputStream对象
     4.使用网络字节输出端Iutputstream对象的read方法给服务器发送数据
     5.使用Socker对象中的方法getOutputStream()获取网络字节输入流OutputStream对象
     6.使用使用网络字节输入端OnputStream对象的write读取服务器回写的数据
     7.释放资源
 */
public class TCPServer {
    public static void main(String[] args) throws IOException {
        boolean flag=true;
        //1.创建服务器ServerSocket对象和系统要指定的端口号
        ServerSocket server=new ServerSocket(8888);
        while (flag) {
            //2.使用ServerSocket中的accept方法获取刀请求的客户端对象Socket
            Socket socket=server.accept();
            //开启线程完成操作
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        //3.使用Socker对象中的方法getInputStream()获取网络字节输入流InputStream对象
                        InputStream is=socket.getInputStream();
                        //4.使用网络字节输出端Iutputstream对象的read方法给客户端发送数据
                        byte[] bytes=new byte[2048];
                        int len=is.read(bytes);
                        String message=new String(bytes,0,len);
                        //5.使用Socker对象中的方法getOutputStream()获取网络字节输入流OutputStream对象
                        OutputStream os=socket.getOutputStream();
                        if(message.equals("time")||message.equals("Time")){
                            System.out.println("收到发送时间请求");
                            DateFormat df=new SimpleDateFormat("yyyy年MM月dd日 hh:mm:ss");//需要传入格式化的字符串内容（定义好的格式。也可自行做点改变）
                            String str=df.format(new Date());
                            //6.使用使用网络字节输入端OnputStream对象的write读取服务器回写的数据
                            os.write(str.getBytes());
                        }else if(message.equals("exit")||message.equals("Exit")){
                            System.out.println("收到退出请求");
                            //6.使用使用网络字节输入端OnputStream对象的write读取服务器回写的数据
                            os.write("Bye".getBytes());
                        }else{
                            os.write("输入格式错误,请输入Time或者time或者exit或者Exit".getBytes());
                        }

                    } catch (IOException e) {
                        e.printStackTrace();
                    }finally {
                        try {
                            //释放资源
                            if (socket!=null)
                            socket.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();

        }

    }
}
