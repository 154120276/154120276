package zcj.stu_ZhuCj;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Stu {
    public static void main(String[] args) throws IOException {
        List<Student> stulist=new ArrayList<>();
        //文件建立在D盘下
        File file=new File("stu.txt");
        boolean flag=true;
        while(flag) {
            Scanner scanner=new Scanner(System.in);
            System.out.println("请输入学生姓名:");
            String name=scanner.nextLine();
            System.out.println("请输入学生id:");
            int id=scanner.nextInt();
            System.out.println("请输入数学成绩");
            double Math=scanner.nextDouble();
            System.out.println("请输入语文成绩");
            double Chinese=scanner.nextDouble();
            System.out.println("请输入英语成绩");
            double English=scanner.nextDouble();
            Student student=new Student(id,name,Math,English,Chinese);
             student.sum=average(student);
            System.out.println(student);
            System.out.println("按1继续其他退出:");
            int i=scanner.nextInt();
            if (i==1){
                flag=true;
            }else {
                flag=false;
            }
            stulist.add(student);
        }
        OutputStream os=null;
        try {
            os=new BufferedOutputStream(new FileOutputStream(file,true));//true是在后面写不重新创建，false是直接把之前的文件覆盖
            //操作(写出)
            for (Student student : stulist) {
                byte[] bytes=student.toString().getBytes();//字符串---》字节数组，编码
                os.write(bytes,0,bytes.length);
                os.flush();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            try {
                if(null!=os)
                    os.close();
            } catch (IOException e) {
                // TODO 自动生成的 catch 块
                e.printStackTrace();
            }
        }
    }
    //计算平均值的方法
    public static double average(Student stu){
        return (stu.Chinese+stu.English+stu.Math)/3;
    }
}
