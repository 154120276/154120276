package zcj.stu_ZhuCj;

public class Student {
    int id;
    String name;
    double Math;
    double English;
    double Chinese;
    double sum;

    public Student(int id, String name, double math, double english, double chinese) {
        this.id = id;
        this.name = name;
        Math = math;
        English = english;
        Chinese = chinese;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMath() {
        return Math;
    }

    public void setMath(double math) {
        Math = math;
    }

    public double getEnglish() {
        return English;
    }

    public void setEnglish(double english) {
        English = english;
    }

    public double getChinese() {
        return Chinese;
    }

    public void setChinese(double chinese) {
        Chinese = chinese;
    }
    //重新toString方便输出

    @Override
    public String toString() {
        return "学生{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", Math=" + Math +
                ", English=" + English +
                ", Chinese=" + Chinese +
                "他的三门课平均分：" + sum +
                '}'+"\n";
    }
}
