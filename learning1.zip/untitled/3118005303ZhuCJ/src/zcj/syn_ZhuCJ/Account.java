package zcj.syn_ZhuCJ;
public class    Account {

    int money;//金额
    String name;//名称
    public Account(int money, String name) {
        super();
        this.money = money;
        this.name = name;
    }

}