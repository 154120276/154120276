package zcj.syn_ZhuCJ;

public class Bank {

    public static void main(String[] args) {
        //账户
        Account account=new Account(0, "银行账户");

        //没人取三次钱操作，每次都新建线程确保取钱的顺序不是固定的一个取完另一个取
        for (int i = 0; i <3 ; i++) {
            safeDrawing you=new safeDrawing(account,"张三",100);
            safeDrawing wife=new safeDrawing(account, "李四",100);
            you.start();
            wife.start();
        }


    }
}

//模拟取款
class safeDrawing extends Thread{
    Account account;//取钱的账户

    int Remittance;//汇款数目
    @Override

    public void run() {
        test01();
    }
    public safeDrawing(Account account, String name,int Remittance) {
       //调用父类方法写入名字
        super(name);
        this.account = account;
        this.Remittance=Remittance;

    }
    public  void test01(){
      // 如果在这里做三次取钱操作会使每次取钱的顺序都是一个人取完就另一个人取
        /*for (int i = 0; i <3 ; i++) {*/
            try {
                //sleep模仿网络延迟，使两个线程取钱的操作不是一个人连续取三次,达到模拟效果
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            //锁定account,不让同时两个线程进入，在第一个还没更新银行账户余额时第二个就进入账户取出数据，导致取出数据一致使最终数据不同
        synchronized(account) {
                account.money += Remittance;
                System.out.println(this.getName() + "存入" + Remittance + "元");
                System.out.println("银行现在有" + account.money + "元");
            }
        }

}
