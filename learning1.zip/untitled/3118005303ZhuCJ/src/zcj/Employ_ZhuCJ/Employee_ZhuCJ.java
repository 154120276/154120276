package zcj.Employ_ZhuCJ;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Scanner;
//Emplyee抽象类
abstract class EmployeeZhuCJ{
    public int id;
    public int payment;
    public int type;
    public  String name;
    public int birthYear;
    public int birthMonth;
    //不同实现类实现不同的工资计算方式
    public abstract int countpay();
    //输出工资和员工信息
    public void showsalary(){
        String typeStr="";
        switch (this.type) {
            case 0:
                typeStr=("领固定月薪的");
                break;
            case 1:
                typeStr=("按销售额提成");
                break;
            case 2:
                typeStr=("计时取酬的 ");
                break;
            case 3:
                typeStr=("带底薪并按销售额提成的");
                break;
        }
        boolean isBithday;
        this.countpay();
        isBithday=this.BirthMonth();
        //输出
        System.out.print("名字："+name+"\t工号："+id+"\t出生年月："+birthYear+"/"+birthMonth+"\t月收入："+payment);
        System.out.print("\t工资类型："+typeStr);
        if(isBithday){
            System.out.print("(这个月是该员工生日，奖励500元)");
        }
        System.out.println();
    }
    //构造函数，输入并获取所有信息
    public EmployeeZhuCJ(){
        this.payment=0;
        Scanner s=new Scanner(System.in);
        try{
            System.out.println("请依次输入姓名、工号、出生年、月(格式:paul 5303 2000 11)");
            String n=s.next();
            while(n.length()<=0){
                System.out.println("名称不能为空！");
                n=s.next();
            }
            this.name=n;

            int id=s.nextInt();
            while(id<0 && id>9999){
                System.out.println("工号格式不对！");
                id=s.nextInt();
            }
            this.id=id;

            int year=s.nextInt();
            while(year>new GregorianCalendar().get(Calendar.YEAR)){
                System.out.println("你不可能出生于未来！！");
                year=s.nextInt();
            }
            this.birthYear=year;

            int month=s.nextInt();
            while (month<1||month>12) {
                System.out.println("月份输入错误,只有12月，别瞎搞！");
                month=s.nextInt();
            }
            this.birthMonth=month;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("IO出错");
        }
    }
    //判断是否为生日的方法
    public boolean BirthMonth(){
        if(Employee_ZhuCJ.nowMonth==this.birthMonth) {
            this.payment += 500;
            return true;
        }
        return false;
    }
}
//实现类
//领固定月薪的
class SalariedEmployee_ZhuCJ extends EmployeeZhuCJ {
    public int salary;
    public SalariedEmployee_ZhuCJ(int t){
        super();
        this.type=t;
        Scanner s = new Scanner(System.in);
        try{
            System.out.print("该员工固定月薪为：");
            int a=s.nextInt();
            while (a<0) {
                System.out.println("月薪不能为负数，请重新输入!");
                a=s.nextInt();
            }
            this.salary=a;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int countpay() {
        return this.payment=salary;
    }
}
//计时取酬的
class HourlyEmployee_ZhuCJ extends EmployeeZhuCJ {
    public int workHour;
    public int salaryPerHour;
    public int salaryPerHourOverTime;
    public HourlyEmployee_ZhuCJ(int t){
        super();
        this.type=t;
        Scanner s = new Scanner(System.in);
        try{
            System.out.print("该员工时薪：");
            int a=s.nextInt();
            while (a<0) {
                System.out.println("员工时薪不能为负，请重新输入!");
                a=s.nextInt();
            }
            this.salaryPerHour=a;

            System.out.print("该员工加班时时薪：");
            a=s.nextInt();
            while (a<0) {
                System.out.println("不能为负，请重新输入!");
                a=s.nextInt();
            }
            this.salaryPerHourOverTime=a;

            System.out.print("该员工工作时长(hour)：");
            a=s.nextInt();
            while (a<0) {
                System.out.println("不能为负，请重新输入!");
                a=s.nextInt();
            }
            this.workHour=a;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public int countpay() {
        if(this.workHour>160) {
            this.payment += 160 * this.salaryPerHour + (this.workHour - 160) * this.salaryPerHourOverTime;
        }else {
            this.payment += this.workHour * this.salaryPerHour;
        }
        return this.payment;
    }

}
//按销售额提成的
class CommissionEmployee_ZhuCJ extends EmployeeZhuCJ{
    public int amountOFSale;
    public int awardPerSale;
    public CommissionEmployee_ZhuCJ(int t){
        super();
        this.type=t;
        Scanner s = new Scanner(System.in);
        try{
            System.out.print("该员工每件商品提成：");
            int a=s.nextInt();
            while (a<0) {
                System.out.println("输入错误，请重新输入!");
                a=s.nextInt();
            }
            this.awardPerSale=a;

            System.out.print("该员工销售商品数目：");
            a=s.nextInt();
            while (a<0) {
                System.out.println("输入错误，请重新输入!");
                a=s.nextInt();
            }
            this.amountOFSale=a;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public int countpay() {
        return this.payment=this.amountOFSale*this.awardPerSale;
    }
}
//带底薪并按销售额提成的
class BasePlusCommissionEmployee_ZhuCJ extends CommissionEmployee_ZhuCJ {
    public int baseSalary;
    public BasePlusCommissionEmployee_ZhuCJ(int t){
        super(t);
        this.type=t;
        Scanner s = new Scanner(System.in);
        try{

            System.out.print("该员工底薪：");
            int a=s.nextInt();
            while (a<0) {
                System.out.println("输入错误，请重新输入!");
                a=s.nextInt();
            }
            this.baseSalary=a;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public int countpay() {
        super.countpay();
        return this.payment+=baseSalary;
    }
}



public class Employee_ZhuCJ{
    static int nowMonth;
   public static void GetMonth() {
        int m = 0;
        Scanner month = new Scanner(System.in);
        try{
            System.out.print("请输入当前月份：");
            m = month.nextInt();
            while(m<1||m>12) {
                System.out.println("月份输入错误，请重新输入当前月份！");
                m = month.nextInt();
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
        nowMonth=m;
    }
    public static void main(String args[]) {
        GetMonth();
        EmployeeZhuCJ[] EmployeeMembers = new EmployeeZhuCJ[20];
        int type = 0;
        //循环标记
        outer:for (; type < EmployeeMembers.length; ) {
            try {
                System.out.println("请输入员工类型序号：或者输入5结束程序\n0.领固定月薪的 \n1.按销售额提成的\n2.计时取酬的 \n3:带底薪并按销售额提成的 \n4.输出已经加入系统的员工工资");
                Scanner s = new Scanner(System.in);
                int etype = s.nextInt();
                switch (etype) {
                    case 0:
                        EmployeeMembers[type] = new SalariedEmployee_ZhuCJ(type);
                        type++;
                        break;
                    case 1:
                        EmployeeMembers[type] = new CommissionEmployee_ZhuCJ(type);
                        type++;
                        break;
                    case 2:
                        EmployeeMembers[type] = new HourlyEmployee_ZhuCJ(type);
                        type++;
                        break;
                    case 3:
                        EmployeeMembers[type] = new BasePlusCommissionEmployee_ZhuCJ(type);
                        type++;
                        break;
                    case 4:
                        for (int showtype=0; showtype < type;showtype++) {
                        EmployeeMembers[showtype].showsalary();
                    }
                        break;
                    case 5:
                        break outer;
                    default:
                        System.out.println("员工类型序号输入有误，请重新输入！");
                        continue;
                }
            }catch (Exception e) {
                e.printStackTrace();
                System.out.println("输入出错（IO错误）");
            }
        }
        
    }
}
