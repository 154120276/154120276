package cn.zcj.Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ChatSocket_ZhuCJ {
	//回馈信息接口
	public interface Callback {
		void onReadSocket(ChatSocket_ZhuCJ chatSocketZhuCJ, String msg);
		void onError(ChatSocket_ZhuCJ chatSocketZhuCJ, String error);
	}
	private DataInputStream inputStream = null;
	private DataOutputStream outputStream = null;
	private Callback callback;
	public String name;



	public DataInputStream getInputStream() {
		return inputStream;
	}

	public DataOutputStream getOutputStream() {
		return outputStream;
	}
	//给与客户端反馈
	public ChatSocket_ZhuCJ(Socket socket, Callback callback, String name) {
		this.name = name;
		try {
			inputStream = new DataInputStream(socket.getInputStream());
			outputStream = new DataOutputStream(socket.getOutputStream());
		} catch (IOException e) {
			e.printStackTrace();
		}

		this.callback = callback;
	}
	// 向客户端发送数据
	public void send(String send) {
		try {
			outputStream.writeUTF(send);
			outputStream.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void start() {
		Thread thread = new Thread(() -> {
			String accept;
			while (true) {
				try {
					accept = inputStream.readUTF();

					if (callback != null) {
						callback.onReadSocket(ChatSocket_ZhuCJ.this, accept);
					}
				} catch (IOException e) {
					if (callback != null) {
						callback.onError(ChatSocket_ZhuCJ.this, e.getMessage());
					}
				}
			}
		});
		thread.start();
	}

	public void close() throws IOException {
		if (inputStream != null) {
			inputStream.close();
		}
		if (outputStream != null) {
			outputStream.close();
		}
	}

}
