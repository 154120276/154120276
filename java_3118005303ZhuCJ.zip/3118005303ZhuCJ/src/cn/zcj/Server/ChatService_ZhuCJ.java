package cn.zcj.Server;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
/*
	服务器类
 */
public class ChatService_ZhuCJ {

	public interface OnSocketAcceptListener {
		void onSocketAccept(Socket socket);
	}
	
	private final ClientManager_ZhuCJ clientManagerZhuCJ;
	private OnSocketAcceptListener onAcceptListener = null;
	private ServerSocket serverSocket = null;
	
	public ChatService_ZhuCJ(ClientManager_ZhuCJ clientManagerZhuCJ) {
		this.clientManagerZhuCJ = clientManagerZhuCJ;
	}
	
	public void setOnAcceptListener(OnSocketAcceptListener listener) {
		onAcceptListener = listener;
	}
	//IDEA自动检测臃肿书写然后可选用lambda优化书写
	public void startup() {
		Thread thread = new Thread(this::runStartup);
        thread.start();
	}
	//关闭服务器方法
	public void shutdown() {
		try {
			clientManagerZhuCJ.close();
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	//开启服务器方法
	private void runStartup() {
		try {
			serverSocket = new ServerSocket(8888);
			while (true) {
				Socket socket = serverSocket.accept();
				DataInputStream dis=new DataInputStream(socket.getInputStream());
				String name = dis.readUTF();
				if (onAcceptListener != null) {
					onAcceptListener.onSocketAccept(socket);
				}

				clientManagerZhuCJ.addClientSocket(socket,name);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
