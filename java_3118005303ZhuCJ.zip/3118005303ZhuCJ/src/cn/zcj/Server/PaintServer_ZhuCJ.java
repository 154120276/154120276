package cn.zcj.Server;

import cn.zcj.Paint.Util_ZhuCJ;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays;
import java.util.concurrent.CopyOnWriteArrayList;


/*
    在线聊天室 服务端
 */
public class PaintServer_ZhuCJ {
    private static CopyOnWriteArrayList<Channel> allChannel=new CopyOnWriteArrayList<>();
    /*public static void main(String[] args) throws IOException {
        System.out.println("Server----------");
        //1.创建ServerSocket并要指定端口号
        ServerSocket server=new ServerSocket(9090);
        //2.使用ServerSocket中的accept方法阻塞式的不断的获取请求的客户端对象Socket
        boolean flag=true;
        while(flag) {
            Socket socket = server.accept();
            System.out.println("建立了一个连接");
            Channel c=new Channel(socket);
            allChannel.add(c);//管理所有成员
            new Thread(c).start();
        }

    }*/

    public PaintServer_ZhuCJ() {
        System.out.println("Server----------");
        //1.创建ServerSocket并要指定端口号
        ServerSocket server= null;
        try {
            server = new ServerSocket(9090);
        } catch (IOException e) {
            System.out.println("启动出错");
        }
        //2.使用ServerSocket中的accept方法阻塞式的不断的获取请求的客户端对象Socket
        boolean flag=true;
        while(flag) {
            Socket socket = null;
            try {
                socket = server.accept();
            } catch (IOException e) {
                System.out.println("启动出错");
            }
            System.out.println("建立了一个连接");
            Channel c=new Channel(socket);
            allChannel.add(c);//管理所有成员
            new Thread(c).start();
        }

    }

    //一个客户一个Channel
    static class Channel implements Runnable{
        private DataOutputStream dos;
        private DataInputStream dis;
        private Socket socket;
        private boolean isRunning;
        int x1,x2,y1,y2;
        public Channel( Socket socket) {
            this.socket = socket;
            try {
                dos=new DataOutputStream(socket.getOutputStream());
                dis = new DataInputStream(socket.getInputStream());
                //开始线程循环
                isRunning=true;
            } catch (IOException e) {
                System.out.println("--------1-----------");
                release();
            }
        }

        //接收消息
        private int[] receive(){
            int[] i=new int[4];
            try {
                x1 = dis.readInt();
                y1 = dis.readInt();
                x2 = dis.readInt();
                y2 = dis.readInt();
                i[0]=x1;
                i[1]=y1;
                i[2]=x2;
                i[3]=y2;
                System.out.println(x1+" "+y1+" "+x2+" "+y2);
            } catch (IOException e) {
                //出问题就把该客户端直接关闭
                System.out.println("--------2-----------");
                release();
            }
            return i;
        }
        //发送消息
        private void send(int [] i ){
                try {
                    dos.writeInt(i[0]);
                    dos.writeInt(i[1]);
                    dos.writeInt(i[2]);
                    dos.writeInt(i[3]);
                    System.out.println(Arrays.toString(i));
                } catch (IOException e) {
                    System.out.println("--------2-----------");
                    release();
                }
        }
        /*
            群聊:获取自己的消息发给其他人
            私聊：约定数据格式:@xxx:msg
         */
        private void sendOther(int [] i) {


                for (Channel other : allChannel) {
                    if (other == this) {
                        System.out.println("自己是"+other);
                        continue;
                    }
                    System.out.println("发送给"+other+"成功");

                    other.send(i);
                }

        }
        //释放资源
        private void release(){
            //关闭线程并释放资源
            this.isRunning=false;
            Util_ZhuCJ.close(dis,dos,socket);
            System.out.println("一个客户断开了连接");
        }

        @Override
        public void run() {
            while (isRunning){
                int[] i = receive();
                System.out.println("接受成功一次");
                sendOther(i);

            }
        }
    }

}
