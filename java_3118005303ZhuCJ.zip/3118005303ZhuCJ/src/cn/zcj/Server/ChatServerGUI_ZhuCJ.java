package cn.zcj.Server;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.Socket;

/*
	服务器的GUI窗口
 */


public class ChatServerGUI_ZhuCJ extends JFrame implements ActionListener, ChatService_ZhuCJ.OnSocketAcceptListener {
	private JButton btnOpen;
	private JButton btnStop;
	private JTextArea tfLogInfo;
	private JScrollPane scrollPane;
	
	JPanel jp1;
	
	private JLabel label;
    private ChatService_ZhuCJ service = null;
	
    public ChatServerGUI_ZhuCJ(ChatService_ZhuCJ service) {
    	this.service = service;
    	this.service.setOnAcceptListener(this);
    	initView();
	}

	private void initView() {
		jp1 = new JPanel();
		btnOpen = new JButton("打开服务器");
        btnStop = new JButton("关闭服务器");
        btnStop.setEnabled(false);
        btnOpen.addActionListener(this);
        btnStop.addActionListener(this);
		jp1.add(btnOpen);
		jp1.add(btnStop);
		jp1.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		tfLogInfo = new JTextArea(20, 20);
		tfLogInfo.setEditable(false);
		scrollPane = new JScrollPane(tfLogInfo);
		
        label = new JLabel("服务器停止工作");
		setIconImage(new ImageIcon("img/server.png").getImage());
        add(jp1, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(label, BorderLayout.SOUTH);
        setTitle("服务器");
        setSize(500, 500);
        //setLocation(450, 150);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
		//窗口居中
		this.setLocationRelativeTo(null);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == btnOpen) {
            open();
        } else {
            stop();
        }
	}

	private void open() {
//		service = new SimpleChatService();
		service.startup();
        label.setText("服务器正在运行");
        btnOpen.setEnabled(false);
        btnStop.setEnabled(true);
	}

	private void stop() {
		label.setText("服务器已关闭");
        btnOpen.setEnabled(true);
        btnStop.setEnabled(false);
        service.shutdown();
	}

	@Override
	public void onSocketAccept(Socket socket) {
		tfLogInfo.append("客户端" +"IP地址:"+socket.getInetAddress() + "已连接"+"\r\n");

	}
}
