package cn.zcj.Server;

public class Main_ZhuCJ {
	

	public static void main(String[] args) {
		ClientManager_ZhuCJ clientManagerZhuCJ = new ClientManager_ZhuCJ();
		ChatService_ZhuCJ service = new ChatService_ZhuCJ(clientManagerZhuCJ);
		ChatServerGUI_ZhuCJ GUI = new ChatServerGUI_ZhuCJ(service);
		PaintServer_ZhuCJ pis=new PaintServer_ZhuCJ();
	}
}
