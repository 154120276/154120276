package cn.zcj.Server;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
//服务器容器类
//容器管理所有在线用户
public class ClientManager_ZhuCJ {
	//Java自带的线程安全容器，自己实现的容器增添改的同步操作
	private static final CopyOnWriteArrayList<ChatSocket_ZhuCJ> CHAT_SOCKET_ZHU_CJS =new CopyOnWriteArrayList<>();
    
    public void addClientSocket(Socket socket,String name) {
		//新客户端连接
		//实现接口
    	 ChatSocket_ZhuCJ chatSocketZhuCJ = new ChatSocket_ZhuCJ(socket, new ChatSocket_ZhuCJ.Callback() {
			
			@Override
			public void onReadSocket(ChatSocket_ZhuCJ cs, String msg) {
				sendAll(cs, msg);
			}
			
			@Override
			public void onError(ChatSocket_ZhuCJ cs, String error) {
				CHAT_SOCKET_ZHU_CJS.remove(cs);
			}
		},name);
		//往客户端管理器里添加客户
		CHAT_SOCKET_ZHU_CJS.add(chatSocketZhuCJ);
		chatSocketZhuCJ.start();
    }

    //向其他客户端发送数据
    public void sendAll(ChatSocket_ZhuCJ chatSocketZhuCJ, String msg) {
		boolean isPrivate = msg.startsWith("@");
		boolean isGroup = msg.startsWith("~");
		if (isPrivate) {//私聊
			//获取目标和数据
			int idx = msg.indexOf(":");
			String targeName = msg.substring(1, idx);
			msg = msg.substring(idx + 1);
			for (ChatSocket_ZhuCJ cs : CHAT_SOCKET_ZHU_CJS) {
				if (cs.name.equals(targeName)) {
					//私聊消息
					cs.send(chatSocketZhuCJ.name + "私聊对你说：" + msg);
				}
			}
			//群聊消息
		}else if(isGroup){
			int idx = msg.indexOf(":");
			int idx2= msg.indexOf("@");
			String groupname=msg.substring(1,idx2);
			String targeName2 = msg.substring(idx2+1, idx);
			msg=msg.substring(idx+1);
			int j = -1;
			int i = targeName2.indexOf("#");
			List<String> list = new ArrayList<>();
			while (i > 0) {
				list.add(targeName2.substring(j + 1, i));
				j = i;
				i = targeName2.indexOf("#", j + 1);
			}
			for (ChatSocket_ZhuCJ cs : CHAT_SOCKET_ZHU_CJS) {
				if (!cs.equals(chatSocketZhuCJ)) {
					for (String s : list) {
						if (cs.name.equals(s)) {
							System.out.println(cs.name+"能收到消息");
							//群聊消息
							cs.send(groupname + "群里传来消息：" + msg);
						}
					}
				}
			}
		}else{
				for (ChatSocket_ZhuCJ cs : CHAT_SOCKET_ZHU_CJS) {
					if (!cs.equals(chatSocketZhuCJ)) {
						cs.send(chatSocketZhuCJ.name + "   " + "对所有人说:" + msg);
					}
				}
			}
		}


	public void close() throws IOException {
		 //关闭各个连接
            for (ChatSocket_ZhuCJ socket : CHAT_SOCKET_ZHU_CJS) {
				socket.close();
			}
            CHAT_SOCKET_ZHU_CJS.clear();

	}
}
