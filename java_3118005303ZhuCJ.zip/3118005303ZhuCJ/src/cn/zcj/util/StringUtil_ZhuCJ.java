package cn.zcj.util;

public class StringUtil_ZhuCJ {
	//判断String是否为空的工具方法
	public static boolean isEmpty(String str) {
		if(str==null || str.trim().isEmpty()) {
			return true;
		}else {
			return false;
		}
	}
}
