package cn.zcj.CHAT;

public class friends_ZhuCJ {
    private String friendsname;
    private String notes;

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getFriendsname() {
        return friendsname;
    }

    public void setFriendsname(String friendsname) {
        this.friendsname = friendsname;
    }

    @Override
    public String toString() {
        return "friends{" +
                "friendsname='" + friendsname + '\'' +
                ", notes='" + notes + '\'' +
                '}';
    }
}
