package cn.zcj.CHAT;

import cn.zcj.util.JDBCDruidUtils_ZhuCJ;
import cn.zcj.util.StringUtil_ZhuCJ;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Map;

public class LogIn_ZhuCJ extends JFrame {
	private static final int WIDTH=500;
    private static final int HEIGHT=300;
	private final JTextField usernametxt;
	private final JPasswordField passwordtxt;
	//获取数据库连接池中的数据库连接
	private static final JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils_ZhuCJ.getDataSource());

	/**
	 * Launch the application.WindowsBuilder自动生成的JFrame登录窗口
	 */
/*	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				LogIn frame = new LogIn();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}*/

	/**
	 * Create the frame.  WindowsBuilder自动生成的JFrame登录窗口
	 */
	public LogIn_ZhuCJ() {
		setIconImage(new ImageIcon("img/Sign_in.gif").getImage());
		setTitle("\u6731\u957F\u6C5F\u7684\u5373\u65F6\u804A\u5929\u767B\u5F55\u754C\u9762");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 Toolkit toolkit=Toolkit.getDefaultToolkit();
	     Dimension screenSize = toolkit.getScreenSize();
		setBounds((screenSize.width-WIDTH)/2,(screenSize.height-HEIGHT)/2,500,382);
		JPanel contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel signIn = new JLabel("\u767B\u5F55\u754C\u9762",new ImageIcon("img/user.png"),JLabel.CENTER);
		signIn.setFont(new Font("宋体", Font.PLAIN, 38));
		
		JLabel Account = new JLabel("\u8D26\u53F7\uFF1A");
		Account.setIcon(new ImageIcon("img/user2.png"));
		Account.setFont(new Font("黑体", Font.PLAIN, 30));
		
		JLabel code = new JLabel("\u5BC6\u7801\uFF1A");
		code.setIcon(new ImageIcon("img/password.png"));
		code.setFont(new Font("黑体", Font.PLAIN, 30));
		
		usernametxt = new JTextField();
		usernametxt.setColumns(10);
		
		passwordtxt = new JPasswordField(10);
	
		
		JButton login = new JButton("\u767B\u5F55");
		login.addActionListener(event -> {
			//调用登录方法
			loginAction();
		});
		login.setFont(new Font("黑体", Font.PLAIN, 24));
		
		JButton Registration = new JButton("\u6CE8\u518C");
		Registration.addActionListener(event -> {
			//调用跳转方法
			forWordAction();
		});
		Registration.setFont(new Font("黑体", Font.PLAIN, 24));
		
		JButton reflash = new JButton("\u91CD\u7F6E");
		//重置的监听事件
		reflash.addActionListener(event -> {
			//将所有输入框中内容清空
			Resetinput();
		});
		reflash.setFont(new Font("黑体", Font.PLAIN, 24));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(114)
					.addComponent(signIn, GroupLayout.PREFERRED_SIZE, 263, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(109, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(reflash, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(72)
							.addComponent(Registration, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
							.addComponent(login, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE))
						.addComponent(code, Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(Account, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(usernametxt, GroupLayout.PREFERRED_SIZE, 291, GroupLayout.PREFERRED_SIZE)
								.addComponent(passwordtxt, GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE))))
					.addGap(38))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(27)
					.addComponent(signIn)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(Account, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
						.addComponent(usernametxt, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(code, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
						.addComponent(passwordtxt, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(login, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(reflash, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
							.addComponent(Registration, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(32, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		//窗口居中
		this.setLocationRelativeTo(null);
	}
	//登录方法
	protected void loginAction() {
		String username=this.usernametxt.getText();
		String password=new String(this.passwordtxt.getPassword());
		//判断是否为空
		if(StringUtil_ZhuCJ.isEmpty(username)) {
			JOptionPane.showMessageDialog(null, "账号不能为空！！！");
			return;
		}
		if(StringUtil_ZhuCJ.isEmpty(password)) {
			JOptionPane.showMessageDialog(null, "密码不能为空！！！");
			return;
		}
		//查询数据库
		String sql="select * from user where username=?";
		Map<String, Object> map;
		try {
			map = template.queryForMap(sql, username);
		} catch (DataAccessException e) {
			JOptionPane.showMessageDialog(null, "登录失败，账号不存在");
			return;
		}

			Object id = map.get("password");
			String pass = (String) id;
			Object nicheng = map.get("name");
			String USERNAME=(String)nicheng;
			if (password.equals(pass)) {
				JOptionPane.showMessageDialog(null, "登录成功");
				forMainAction(USERNAME,username);
			} else {
				JOptionPane.showMessageDialog(null, "登录失败，密码错误");
			}
	}

	//重置方法
	protected void Resetinput() {
			this.usernametxt.setText("");
			this.passwordtxt.setText("");
	}

	/*
	 * 跳转方法，打开注册界面
	 *
	 */
	protected void forWordAction() {

		//dispose();//关闭当前窗口
		EventQueue.invokeLater(() -> {
			try {
				Register_ZhuCJ frame = new Register_ZhuCJ();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/*
	 * 跳转方法，打开主界面
	 *
	 */
	protected void forMainAction(String name,String username) {

		dispose();//关闭当前窗口
		EventQueue.invokeLater(() -> {
			try {
				MainInterface_ZhuCJ frame = new MainInterface_ZhuCJ(name,username);
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}
}
