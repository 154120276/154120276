package cn.zcj.CHAT;

import cn.zcj.util.JDBCDruidUtils_ZhuCJ;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class Groupchat_ZhuCJ extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private JTextField chosetxt;
    private JTextField textField;
    private String NAME;
    private String Seletedname;
    private static final JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils_ZhuCJ.getDataSource());

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Groupchat_ZhuCJ frame = new Groupchat_ZhuCJ("朱长江");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the frame.
     */
    public Groupchat_ZhuCJ(String NAME) {
        this.NAME=NAME;
        setIconImage(new ImageIcon("img/groupchat.png").getImage());
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 503, 507);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        JTextArea txtrn = new JTextArea();
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
            }
        });
        //删除群聊
        JButton delete = new JButton("\u5220\u9664\u7FA4\u804A");
        delete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String text = textField.getText();
                String sql="delete from groupsmember where members=?";
                try {
                    template.update(sql,text);
                } catch (DataAccessException dataAccessException) {
                    JOptionPane.showMessageDialog(null, "删除失败，请勿乱填群名");
                    return;
                }
                String sql2="drop table "+text;
                template.update(sql2);
                JOptionPane.showMessageDialog(null, "删除成功");
                filltable();
            }
        });
        //创建群聊
        JButton add = new JButton("\u6DFB\u52A0\u7FA4\u804A");
        add.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String text = textField.getText();
                int idx = text.indexOf("@");
                if (idx > 0) {
                    String targeName = text.substring(0, idx);
                    System.out.println(targeName);
                    if (targeName.equals("")) {
                        JOptionPane.showMessageDialog(null, "群名不能为空");
                    }
                    String sql2 = "create table " + targeName + "(members varchar(20) UNIQUE )";
                    //创建好友表
                    template.update(sql2);
                    int idx2 = text.indexOf(":");
                    String targeName2 = text.substring(idx + 1, idx2);
                    System.out.println(targeName2);
                    //分割字符串获取要加的昵称
                    int j = -1;
                    int i = targeName2.indexOf("#");
                    List<String> list = new ArrayList<>();
                    while (i > 0) {
                        list.add(targeName2.substring(j + 1, i));
                        j = i;
                        i = targeName2.indexOf("#", j + 1);
                    }
                    for (String s : list) {
                        String sql3="select * from user where name=?";
                        Map<String, Object> map=null;
                        try {
                             map = template.queryForMap(sql3,s);
                        } catch (DataAccessException dataAccessException) {
                            JOptionPane.showMessageDialog(null, "不存在"+s+"这个用户");
                        }
                        if (map!=null) {
                            String sql4 = "insert into " + targeName + "(members) values (?)";
                            int count = template.update(sql4, s);
                        }
                    }
                    String sql = "insert into groupsmember(members) values(?)";
                    int count = 0;
                    try {
                        count = template.update(sql, targeName);
                    } catch (DataAccessException dataAccessException) {
                        JOptionPane.showMessageDialog(null, "添加失败");
                    }
                    if (count == 1) {
                        JOptionPane.showMessageDialog(null, "添加成功");
                    }
                }
            }
        });
        //修改群名
        JButton update = new JButton("\u4FEE\u6539\u7FA4\u804A\u540D");
        update.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String text = chosetxt.getText();
                String sql="alter table "+Seletedname+" rename to "+text;
                try {
                    template.update(sql);
                } catch (DataAccessException e2) {
                    System.out.println("修改错误");
                    return;
                }
                String sql2="update groupsmember set members= ? where members= ? ";
                try {
                    template.update(sql2,text,Seletedname);
                } catch (DataAccessException dataAccessException) {
                    dataAccessException.printStackTrace();
                }
                filltable();
                JOptionPane.showMessageDialog(null,"修改成功");
            }
        });

        JScrollPane scrollPane_1 = new JScrollPane();

        chosetxt = new JTextField();
        chosetxt.setColumns(10);
        //选择群聊
        JButton chose = new JButton("\u9009\u62E9\u7FA4\u804A");
        chose.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String chatname = textField.getText();
                String targename=chatname+"@";
                String sql="select * from "+chatname;
                List<Map<String, Object>> list = template.queryForList(sql);
                for (Map<String, Object> map : list) {
                    String name = (String) map.get("members");
                    targename +=name+"#";
                }
                targename+=":";
                txtrn.setText("~"+targename);
            }
        });

        textField = new JTextField();
        textField.setColumns(10);
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
                gl_contentPane.createParallelGroup(Alignment.TRAILING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
                                        .addComponent(textField, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                                        .addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addComponent(chosetxt, GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
                                                .addGap(18)
                                                .addComponent(update, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
                                                .addGap(18)
                                                .addComponent(chose, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
                                                .addGap(24))
                                        .addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
                                                .addComponent(add, GroupLayout.PREFERRED_SIZE, 219, GroupLayout.PREFERRED_SIZE)
                                                .addGap(18)
                                                .addComponent(delete, GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE))
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addContainerGap()
                                                .addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)))
                                .addContainerGap())
        );
        gl_contentPane.setVerticalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 295, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.UNRELATED)
                                .addComponent(textField, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(delete)
                                        .addComponent(add))
                                .addGap(10)
                                .addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                                .addComponent(update, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                                                .addComponent(chosetxt, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
                                        .addComponent(chose, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())
        );

        txtrn.setText("\u8BF7\u9009\u62E9\u5B8C\u70B9\u51FB\u5FEB\u6377\u7FA4\u804A\u540E\u590D\u5236\u8BE5\u6587\u672C\u57DF\u91CC\u9762\u7684\u5B57\u7136\u540E\u5728\u540E\u9762\u52A0\u4E0A\u4F60\u60F3\u8BF4\u7684\u8BDD\u5728\u5916\u9762\u8F93\u5165");
        txtrn.setEditable(false);
        scrollPane_1.setViewportView(txtrn);

        table = new JTable();
        table.addMouseListener(new MouseAdapter() {
            //获取当前行的数据显示在表单上
            @Override
            public void mousePressed(MouseEvent e) {
                int row=table.getSelectedRow();//行号
                String groupname= (String) table.getValueAt(row,0);
                chosetxt.setText(groupname);
                textField.setText(groupname);
                Seletedname=groupname;

            }
        });

        table.setModel(new DefaultTableModel(
                new Object[][] {
                },
                new String[] {
                        "\u4F60\u7684\u7FA4\u804A(\u4F60\u5728\u91CC\u9762\u7684)"
                }
        ));
        table.getColumnModel().getColumn(0).setPreferredWidth(592);
        scrollPane.setViewportView(table);
        contentPane.setLayout(gl_contentPane);
        //初始化表格
        filltable();
        //窗口居中
        this.setLocationRelativeTo(null);
    }

    private void filltable() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        //先清空
        model.setRowCount(0);
        String sql = "select members from groupsmember";
        List<Map<String, Object>> list = template.queryForList(sql);
        for (Map<String, Object> map : list) {
            Vector<String> vector=new Vector<>();
            String members = (String) map.get("members");
            String sql2 = "select * from "+members;
            List<Map<String, Object>> list2 = template.queryForList(sql2);
            for (Map<String, Object> map2 : list2) {
                String name = (String) map2.get("members");
                if (name.equals(NAME)){
                    vector.add(members);
                    model.addRow(vector);
                }
            }

        }
    }
}

