package cn.zcj.CHAT;
/*
 * 反馈信息的接口，在用户界面里实现
 */

public interface Callback_ZhuCJ {
    void onConnected(String host, int port);        //连接成功
    void onConnectFailed(String host, int port);    //连接失败
    void onDisconnected();                          //已经断开连接
    void onMessageSent( String msg);    //消息已经发出
    void onMessageReceived(String msg);//收到消息

}
