package cn.zcj.CHAT;

import cn.zcj.util.JDBCDruidUtils_ZhuCJ;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class friendsGUI_ZhuCJ extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private JTextField addtxt;
    private JTextField Notes;
    private String USERNAME;
    private String Selectedfriendsname;
    private static final JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils_ZhuCJ.getDataSource());

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                friendsGUI_ZhuCJ frame = new friendsGUI_ZhuCJ("zhuchangjiang");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public friendsGUI_ZhuCJ(String USERNAME) {
        this.USERNAME=USERNAME;
        setIconImage(new ImageIcon("img/friend.png").getImage());
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 620, 567);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        JScrollPane scrollPane = new JScrollPane();

        JButton add = new JButton("\u6DFB\u52A0\u597D\u53CB");
        //添加好友操作
        add.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String addname = addtxt.getText();
                String sql="SELECT * FROM USER WHERE NAME='"+addname+"'";
                Map<String, Object> map = null;
                try {
                    map = template.queryForMap(sql);
                } catch (DataAccessException dataAccessException) {
                    JOptionPane.showMessageDialog(null,"查无此人！请核对输入昵称！");
                    return;
                }
                String sql2="insert into "+USERNAME+"friends"+"(friendsname) values(?)";
                int count=template.update(sql2,addname);
                if (count==1){
                    filltable();
                    JOptionPane.showMessageDialog(null,"添加成功");
                }else {
                    JOptionPane.showMessageDialog(null,"未知原因,添加失败");
                }
            }
        });

        JPanel panel = new JPanel();

        addtxt = new JTextField();
        addtxt.setColumns(10);

        JLabel lblNewLabel = new JLabel("\u8F93\u5165\u6635\u79F0\u6DFB\u52A0");
        lblNewLabel.setFont(new Font("宋体", Font.PLAIN, 15));
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addComponent(scrollPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 596, Short.MAX_VALUE)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(add)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addComponent(addtxt, GroupLayout.PREFERRED_SIZE, 231, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(53, Short.MAX_VALUE))
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(panel, GroupLayout.DEFAULT_SIZE, 596, Short.MAX_VALUE))
        );
        gl_contentPane.setVerticalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 326, GroupLayout.PREFERRED_SIZE)
                                .addGap(31)
                                .addComponent(panel, GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
                                .addGap(18)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(add, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(addtxt, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblNewLabel))
                                .addGap(18))
        );
        //修改信息操作
        JButton modify = new JButton("\u4FEE\u6539");
        modify.addActionListener(e -> {
            String notes = Notes.getText();
            String sql="UPDATE "+USERNAME+"friends SET notes='"+notes+"' WHERE friendsname='"+Selectedfriendsname+"'";
            int count = template.update(sql);
            if (count==1){
                filltable();
                JOptionPane.showMessageDialog(null,"修改成功");
            }else {
                JOptionPane.showMessageDialog(null,"修改失败，请确认数据是否重复或不合法");
            }
        });
        //删除好友操作
        JButton delete = new JButton("\u5220\u9664");
        delete.addActionListener(e -> {
            String sql="delete from "+USERNAME+"friends"+" WHERE friendsname='"+Selectedfriendsname+"'";
            int count=template.update(sql);
            if (count==1){
                filltable();
                JOptionPane.showMessageDialog(null,"删除成功");
            }else {
                JOptionPane.showMessageDialog(null,"未知原因删除失败");
            }
        });

        Notes = new JTextField();
        Notes.setColumns(10);

        JLabel notesJL = new JLabel("\u5907\u6CE8\uFF1A");
        notesJL.setFont(new Font("黑体", Font.PLAIN, 20));
        GroupLayout gl_panel = new GroupLayout(panel);
        gl_panel.setHorizontalGroup(
                gl_panel.createParallelGroup(Alignment.TRAILING)
                        .addGroup(gl_panel.createSequentialGroup()
                                .addGap(20)
                                .addComponent(notesJL, GroupLayout.PREFERRED_SIZE, 71, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
                                        .addComponent(Notes, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 411, Short.MAX_VALUE)
                                        .addGroup(gl_panel.createSequentialGroup()
                                                .addComponent(modify, GroupLayout.PREFERRED_SIZE, 173, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                                                .addComponent(delete, GroupLayout.PREFERRED_SIZE, 186, GroupLayout.PREFERRED_SIZE)))
                                .addGap(80))
        );
        gl_panel.setVerticalGroup(
                gl_panel.createParallelGroup(Alignment.TRAILING)
                        .addGroup(gl_panel.createSequentialGroup()
                                .addGap(21)
                                .addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(Notes, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(notesJL, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                                .addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(modify, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(delete, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)))
        );
        panel.setLayout(gl_panel);
        //表格选择事件
        table = new JTable();
        table.addMouseListener(new MouseAdapter() {
            //获取当前行的数据显示在表单上
            @Override
            public void mousePressed(MouseEvent e) {
                int row=table.getSelectedRow();//行号
                String notes= (String) table.getValueAt(row,1);
                Selectedfriendsname= (String) table.getValueAt(row,0);
                Notes.setText(notes);
            }
        });
        table.setModel(new DefaultTableModel(
                new Object[][] {
                },
                new String[] {
                        "\u597D\u53CB\u540D\u5B57", "\u5907\u6CE8", "\u5728\u7EBF\u72B6\u6001"
                }
        ));
        table.getColumnModel().getColumn(0).setPreferredWidth(258);
        table.getColumnModel().getColumn(1).setPreferredWidth(260);
        scrollPane.setViewportView(table);
        contentPane.setLayout(gl_contentPane);

        //窗口居中
        this.setLocationRelativeTo(null);

        //创建窗口就把自己已经有的好友填充表格
        filltable();
    }

    private void filltable() {
       DefaultTableModel model = (DefaultTableModel) table.getModel();
       //先清空
       model.setRowCount(0);
       String sql = "select * from "+USERNAME+"friends";
        List<friends_ZhuCJ> list = template.query(sql,new BeanPropertyRowMapper<>(friends_ZhuCJ.class));

        for (friends_ZhuCJ friends_ZhuCJ : list) {
            Vector<String> vector=new Vector<>();
            String sql2="SELECT isconnection FROM USER WHERE name=?";
            Boolean isconnection = template.queryForObject(sql2, Boolean.class, friends_ZhuCJ.getFriendsname());
            String status="";
            if (isconnection){
                status="在线";
            }else {
                status="不在线";
            }
            vector.add(friends_ZhuCJ.getFriendsname());vector.add(friends_ZhuCJ.getNotes());vector.add(status);
            model.addRow(vector);
        }

    }
}

