package cn.zcj.CHAT;


import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import static cn.zcj.CHAT.Util_ZhuCJ.closeall;

public class ClientService_ZhuCJ {
    private Callback_ZhuCJ callbackZhuCJ;
    // 套接字对象
    private Socket socket = null;
    // 套接字输入流对象，从这里读取收到的消息
    private DataInputStream inputStream = null;
    // 套接字输出流对象，从这里发送聊天消息
    private DataOutputStream outputStream = null;
    // 当前连接状态的标记变量
    private boolean isConnected = false;
    private String username;

    public ClientService_ZhuCJ(String username) {
        this.username = username;
    }

    public void setCallbackZhuCJ(Callback_ZhuCJ callbackZhuCJ) {
        this.callbackZhuCJ = callbackZhuCJ;
    }
    //开始监控消息的方法,用lambda简化书写
    private void beginListening() {
        new Thread(() -> {
            try {
                inputStream = new DataInputStream(socket.getInputStream());
                while (true) {
                    String s = inputStream.readUTF();
                    if (callbackZhuCJ != null) {
                        callbackZhuCJ.onMessageReceived(s);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }
    //与服务器建立连接
    public void connect(String host, int port) {
        try {
            // 创建Socket，与服务器建立连接
            socket = new Socket(host, port);
            isConnected = true;
            //先将名字发送过去
            outputStream = new DataOutputStream(socket.getOutputStream());
            outputStream.writeUTF(username);
            outputStream.flush();
            // 通知外界已连接
            if (callbackZhuCJ != null) {
                callbackZhuCJ.onConnected(host, port);
            }
            // 开始侦听是否有聊天消息到来
            beginListening();
        } catch (IOException e) {
            // 连接服务器失败
            isConnected = false;
            // 通知外界连接失败
            if (callbackZhuCJ != null) {
                callbackZhuCJ.onConnectFailed(host, port);
            }
            e.printStackTrace();
        }
    }
    //关闭与服务器的连接
    public void disconnect() {
        closeall(socket,inputStream,outputStream);
        isConnected = false;
        // 通知外界连接断开
        if (callbackZhuCJ != null) {
            callbackZhuCJ.onDisconnected();
        }

    }
    //返回连接状态
    public boolean isConnected() {
        return isConnected;
    }

    public void sendMessage( String msg) {
        // 检查参数合法性
        if (msg == null || "".equals(msg)) {
            return;
        }
        //服务器对象必须已创建
        if (socket == null) {
            return;
        }

        try {
            // 将消息写入输出流，并用不常用的符号区分姓名和消息
            outputStream = new DataOutputStream(socket.getOutputStream());
            outputStream.writeUTF( msg);
            outputStream.flush();
            // 通知外界消息已发送
            if (callbackZhuCJ != null) {
                callbackZhuCJ.onMessageSent(msg);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
