package cn.zcj.CHAT;


import cn.zcj.Paint.picGUI_ZhuCJ;
import cn.zcj.util.JDBCDruidUtils_ZhuCJ;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class MainInterface_ZhuCJ extends JFrame {

    private final JTextField ChatInput;
    private final JTextField SevriceIP;
    private final JTextField Port;
    private final ClientService_ZhuCJ clientservice;
    private  String USERNAME;
    private  String username;
    //获取数据库连接池中的数据库连接
    private static final JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils_ZhuCJ.getDataSource());
    /**
     * 测试入口
     */
   /* public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MainInterface frame = new MainInterface("朱长江","zhuchangjiang");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }*/

    /**
     * 构造函数,窗口初始化.
     *
     */
    public MainInterface_ZhuCJ(String USERNAME, String username) {
        this.USERNAME=USERNAME;
        this.username=username;
        setIconImage(new ImageIcon("img/Main.png").getImage());
        setBackground(SystemColor.activeCaption);
        setTitle("\u804A\u5929\u4E3B\u754C\u9762(@ Author \u6731\u957F\u6C5F)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 980, 740);
        JPanel contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        JScrollPane scrollPane = new JScrollPane();

        JButton sendtoBtn = new JButton("\u53D1\u9001");
        //发送消息事件
        sendtoBtn.addActionListener(e -> sendMessage());

        sendtoBtn.setFont(new Font("宋体", Font.PLAIN, 20));
        sendtoBtn.setIcon(new ImageIcon(("img/sendto.png")));

        JButton reflash = new JButton("\u6E05\u7A7A\u4FE1\u606F");
        //清空消息框的信息
        reflash.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ChatInput.setText("");
            }
        });
        reflash.setFont(new Font("宋体", Font.PLAIN, 20));

        JLabel lblNewLabel = new JLabel("\u79C1\u804A\u53EA\u9700\u8981\u5728\u4F60\u7684\u4FE1\u606F\u524D\u52A0\u4E0A@+\u5BF9\u65B9\u6635\u79F0:\u5373\u53EF(\u9ED8\u8BA4\u6240\u6709\u4EBA\u7FA4\u804A)");
        lblNewLabel.setFont(new Font("黑体", Font.PLAIN, 20));

        JLabel lblNewLabel_1 = new JLabel("\u4E0D\u652F\u6301\u56FE\u7247");
        lblNewLabel_1.setFont(new Font("黑体", Font.PLAIN, 20));

        JTextArea ChatRoom = new JTextArea();
        scrollPane.setViewportView(ChatRoom);

        JLabel ChatInputRoom = new JLabel("\u804A\u5929\u8F93\u5165\u6846");
        ChatInputRoom.setIcon(new ImageIcon(("img/ChatRoom.png")));
        ChatInputRoom.setFont(new Font("黑体", Font.PLAIN, 20));

        JLabel ChatOutRoom = new JLabel("\u804A\u5929\u8F93\u51FA\u754C\u9762");
        ChatOutRoom.setIcon(new ImageIcon(("img/Chat.png")));
        ChatOutRoom.setFont(new Font("黑体", Font.PLAIN, 20));

        JLabel lblNewLabel_2 = new JLabel("\u63D0\u793A:\u56DE\u8F66\u53EF\u4EE3\u66FF\u6309\u94AE\u4F46\u6587\u672C\u4E0D\u80FD\u6362\u884C");
        lblNewLabel_2.setFont(new Font("黑体", Font.PLAIN, 12));

        JButton singleChat = new JButton("\u79C1\u804A\u5FEB\u6377\u952E");
        singleChat.addActionListener(new ActionListener() {
            //私聊快捷输入事件
            public void actionPerformed(ActionEvent e) {
                ChatRoom.append("系统消息:将昵称改为你想要私聊的人即可完成私聊功能"+"\n");
                ChatInput.setText("@昵称:");
            }
        });
        singleChat.setFont(new Font("宋体", Font.PLAIN, 20));

        ChatInput = new JTextField();
        //按回车发送消息事件
        ChatInput.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode()== KeyEvent.VK_ENTER){
                    sendMessage();
                }
            }
        });
        ChatInput.setColumns(10);

        JLabel lblNewLabel_1_1 = new JLabel("\u804A\u5929\u6846\uFF1A");
        lblNewLabel_1_1.setIcon(new ImageIcon(("img/Chat.png")));
        lblNewLabel_1_1.setFont(new Font("黑体", Font.PLAIN, 20));

        JLabel lblip = new JLabel("\u4E3B\u673AIP\u5730\u5740:");
        lblip.setFont(new Font("黑体", Font.PLAIN, 20));

        SevriceIP = new JTextField();
        SevriceIP.setForeground(Color.RED);
        SevriceIP.setFont(new Font("黑体", Font.PLAIN, 20));
        SevriceIP.setText("localhost");
        SevriceIP.setColumns(10);

        JLabel lblip_1 = new JLabel("\u7AEF\u53E3\u53F7:");
        lblip_1.setFont(new Font("黑体", Font.PLAIN, 20));

        Port = new JTextField();
        Port.setFont(new Font("黑体", Font.PLAIN, 20));
        Port.setForeground(Color.RED);
        Port.setText("8888");
        Port.setColumns(10);

        JButton connect = new JButton("\u8FDE\u63A5");
        //获取连接的事件
        connect.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!clientservice.isConnected()) {
                    //修改数据库中的标志位
                    String sql2="UPDATE USER SET isconnection=TRUE WHERE name=?";
                    int count = template.update(sql2, USERNAME);
                    if (count<=0){
                        JOptionPane.showMessageDialog(null, "修改数据库出错误");
                        return;
                    }
                    // 未连接状态下，执行连接服务器操作
                    String host = SevriceIP.getText();
                    int port = Integer.parseInt(Port.getText());
                    clientservice.connect(host, port);

                } else {
                    //修改数据库中的标志位
                    String sql2="UPDATE USER SET isconnection=FALSE WHERE name=?";
                    int count = template.update(sql2, USERNAME);
                    if (count<=0){
                        JOptionPane.showMessageDialog(null, "修改数据库出错误");
                        return;
                    }
                    // 已连接状态下，执行断开连接操作
                    clientservice.disconnect();
                }
            }
        });
        // 当窗口关闭时触发
        addWindowListener(new WindowAdapter() { // 窗口关闭后断开连接
            @Override
            public void windowClosing(WindowEvent e) {
                //修改数据库中的标志位
                String sql2="UPDATE USER SET isconnection=FALSE WHERE name=?";
                int count = template.update(sql2, USERNAME);
                if (count<=0){
                    JOptionPane.showMessageDialog(null, "修改数据库出错误");
                    return;
                }
                clientservice.disconnect();
            }
        });
        connect.setFont(new Font("宋体", Font.PLAIN, 15));
        JButton friends = new JButton("\u597D\u53CB\u754C\u9762");
        //好友功能实现
        friends.addActionListener(e -> EventQueue.invokeLater(() -> {
            try {
                System.out.println(username);
                friendsGUI_ZhuCJ frame = new friendsGUI_ZhuCJ(username);
                frame.setVisible(true);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }));
        friends.setIcon(new ImageIcon(("img/friend.png")));
        friends.setFont(new Font("黑体", Font.ITALIC, 40));
        //群聊功能实现
        JButton group = new JButton("\u7FA4\u804A\u754C\u9762");
        group.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        try {
                            Groupchat_ZhuCJ frame = new Groupchat_ZhuCJ(USERNAME);
                            frame.setVisible(true);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });
        group.setIcon(new ImageIcon("img/group.png"));
        group.setFont(new Font("黑体", Font.ITALIC, 40));
        //画板功能实现
        JButton paintroom = new JButton("\u5171\u4EAB\u753B\u677F");
        paintroom.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                picGUI_ZhuCJ CP=new picGUI_ZhuCJ();
                CP.creat();
                CP.showUI();
            }
        });
        paintroom.setIcon(new ImageIcon("img/paint.png"));
        paintroom.setFont(new Font("黑体", Font.ITALIC, 40));

        JLabel lblNewLabel_3 = new JLabel("\u611F\u8C22\u4F60\u7684\u4F7F\u7528");
        lblNewLabel_3.setFont(new Font("黑体", Font.PLAIN, 50));
        //保存历史记录功能实现
        JButton history = new JButton("\u5386\u53F2\u804A\u5929\u8BB0\u5F55\u4FDD\u5B58");
        history.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String msg=ChatRoom.getText();
                Calendar date=new GregorianCalendar();
                int year = date.get(Calendar.YEAR);
                int Month = date.get(Calendar.MONTH)+1;
                int day = date.get(Calendar.DATE);
                int HOUR= date.get(Calendar.HOUR);
                Date Date=date.getTime();

                File file=new File("history\\history"+username+year+Month+day+HOUR+".txt");
                try {
                    BufferedWriter writer=new BufferedWriter(new FileWriter(file));
                    writer.append("时间："+Date+"\t"+USERNAME+"的历史记录"+"\n"+msg);
                    writer.flush();
                    alert("成功","生成历史文档成功!路径为项目根目录下的的history文件夹里");
                } catch (IOException e3) {
                    alert("错误","生成历史文档出错！");
                }
            }
        });
        history.setFont(new Font("黑体", Font.PLAIN, 30));
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
                gl_contentPane.createParallelGroup(Alignment.TRAILING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addComponent(lblNewLabel)
                                        .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addComponent(lblNewLabel_1)
                                                                .addGap(29))
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE)
                                                                .addGap(3)))
                                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addComponent(singleChat)
                                                                .addGap(26)
                                                                .addComponent(reflash, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                                .addComponent(sendtoBtn, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE))
                                                        .addComponent(ChatInput, GroupLayout.PREFERRED_SIZE, 433, GroupLayout.PREFERRED_SIZE)
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addPreferredGap(ComponentPlacement.RELATED)
                                                                .addComponent(ChatInputRoom))))
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addComponent(ChatOutRoom, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(ComponentPlacement.RELATED)
                                                                .addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 295, Short.MAX_VALUE)
                                                                .addGap(109))
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addComponent(lblip)
                                                                .addPreferredGap(ComponentPlacement.RELATED)
                                                                .addComponent(SevriceIP, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(ComponentPlacement.RELATED)
                                                                .addComponent(lblip_1)
                                                                .addPreferredGap(ComponentPlacement.RELATED)
                                                                .addComponent(Port, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                                                                .addPreferredGap(ComponentPlacement.RELATED)
                                                                .addComponent(connect, GroupLayout.PREFERRED_SIZE, 110, Short.MAX_VALUE)))
                                                .addGap(27)))
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
                                        .addComponent(history, GroupLayout.DEFAULT_SIZE, 307, Short.MAX_VALUE)
                                        .addComponent(lblNewLabel_3, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
                                                .addComponent(friends, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 307, Short.MAX_VALUE)
                                                .addComponent(group, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 307, Short.MAX_VALUE)
                                                .addComponent(paintroom, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 307, Short.MAX_VALUE)))
                                .addContainerGap())
        );
        gl_contentPane.setVerticalGroup(
                gl_contentPane.createParallelGroup(Alignment.TRAILING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 490, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
                                        .addComponent(connect, GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                                        .addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
                                                .addComponent(lblip, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(SevriceIP, GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                                                .addComponent(lblip_1, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
                                                .addComponent(Port, GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)))
                                .addGap(13)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(ChatOutRoom, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(ChatInputRoom, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(ComponentPlacement.UNRELATED)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(ChatInput, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addGap(6)
                                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                                        .addComponent(singleChat, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(reflash, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
                                                        .addComponent(sendtoBtn)))
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addGap(10)
                                                .addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
                        .addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
                                .addGap(24)
                                .addComponent(friends, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                                .addGap(42)
                                .addComponent(group, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                                .addGap(36)
                                .addComponent(paintroom, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                                .addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.RELATED)
                                .addComponent(history, GroupLayout.PREFERRED_SIZE, 81, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap())
        );
        contentPane.setLayout(gl_contentPane);

        //窗口居中
        this.setLocationRelativeTo(null);

        clientservice = new ClientService_ZhuCJ(USERNAME);
        clientservice.setCallbackZhuCJ(new Callback_ZhuCJ() {
            //在主界面类里面实现接口，保证代码可读性
            @Override
            // 连接成功时，弹对话框提示，并将按钮文字改为“断开”
            public void onConnected(String host, int port) {
                alert("连接", "成功连接到[" + host + ":" + port + "]");
                connect.setText("断开");
            }

            @Override
            // 连接失败时，弹对话框提示，并将按钮文字设为“连接”
            public void onConnectFailed(String host, int port) {
                alert("连接", "无法连接到[" + host + ":" + port + "]");
                connect.setText("连接");
            }

            @Override
            // 断开连接时，弹对话框提示，并将按钮文字设为“连接”
            public void onDisconnected() {
                // 断开连接时，弹对话框提示，并将按钮文字设为“连接”
                alert("连接", "连接已断开");
                connect.setText("连接");
            }

            @Override
            // 发出消息时，清空消息输入框，并将消息显示在消息区
            public void onMessageSent( String msg) {
                ChatInput.setText("");
                ChatRoom.append("我(" +USERNAME+ ")说:\r\n" + msg + "\r\n");
            }

            @Override
            // 收到消息时，将消息显示在消息区
            public void onMessageReceived(String msg) {
                ChatRoom.append( msg + "\r\n");
            }
        });

    }
    //发送方法
    private void sendMessage() {
        String msg = ChatInput.getText();
        // 检查参数合法性
        if ( msg == null || "".equals(msg)) {
            return;
        }
        // 发送消息
        clientservice.sendMessage(msg);
    }

    // 显示标题为title，内容为message的对话框，简化书写
    private void alert(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
    }
}
