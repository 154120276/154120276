package cn.zcj.CHAT;

import cn.zcj.util.JDBCDruidUtils_ZhuCJ;
import cn.zcj.util.StringUtil_ZhuCJ;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.swing.*;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

/*
        注册窗口类
 */
public class Register_ZhuCJ extends JFrame {

    private JPanel contentPane;
    private JTextField usernametxt;
    private JPasswordField passwordtxt;
    private JPasswordField passwordconfigtxt;
    private JLabel JL4;
    private JTextField nametxt;
    //获取数据库连接池中的数据库连接
    private static JdbcTemplate template=new JdbcTemplate(JDBCDruidUtils_ZhuCJ.getDataSource());

    /**
     * 注册窗口  测试专用入口
     */
   /* public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Register frame = new Register();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }*/

    /**
     * Create the frame.构造函数初始化窗口
     */
    public Register_ZhuCJ() {
        setIconImage(new ImageIcon("img/Register.png").getImage());
        setResizable(false);
        setTitle("\u6731\u957F\u6C5F\u7684\u5373\u65F6\u804A\u5929\u7CFB\u7EDF\u6CE8\u518C\u754C\u9762");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 613, 478);
        contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        JLabel Register = new JLabel("\u6B22\u8FCE\u60A8\u6CE8\u518C\u6210\u4E3A\u8001\u9F20\u961F\u9996\u5E2D\u55B7\u5B50\u961F\u6210\u5458");
        Register.setFont(new Font("黑体", Font.PLAIN, 20));

        JLabel JL1 = new JLabel("\u8BF7\u8F93\u5165\u8D26\u53F7\uFF1A");
        JL1.setFont(new Font("黑体", Font.PLAIN, 18));

        JLabel JL2 = new JLabel("\u8BF7\u8F93\u5165\u5BC6\u7801\uFF1A");
        JL2.setFont(new Font("黑体", Font.PLAIN, 18));

        JLabel JL3 = new JLabel("\u8BF7\u786E\u8BA4\u5BC6\u7801\uFF1A");
        JL3.setFont(new Font("黑体", Font.PLAIN, 18));

        usernametxt = new JTextField();
        usernametxt.setColumns(10);

        passwordtxt = new JPasswordField();
        passwordtxt.setColumns(10);

        passwordconfigtxt = new JPasswordField();
        passwordconfigtxt.setColumns(10);

        JL4 = new JLabel("\u8BF7\u8F93\u5165\u7528\u6237\u540D\uFF1A");
        JL4.setFont(new Font("黑体", Font.PLAIN, 18));

        nametxt = new JTextField();
        nametxt.setColumns(10);

        JButton btnNewButton = new JButton("\u6CE8\u518C");
        //注册提交事件
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                RegisterAction(event);
            }
        });
        btnNewButton.setIcon(new ImageIcon("img/Register2.png"));
        btnNewButton.setFont(new Font("黑体", Font.PLAIN, 26));

        JButton exit = new JButton("\u9000\u51FA");
        //退出，关闭窗口
        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });
        exit.setIcon(new ImageIcon(("img/exit.png")));
        exit.setFont(new Font("黑体", Font.PLAIN, 26));
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addGap(115)
                                                .addComponent(Register, GroupLayout.PREFERRED_SIZE, 353, GroupLayout.PREFERRED_SIZE))
                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                .addGap(36)
                                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addComponent(JL4)
                                                                .addGap(18)
                                                                .addComponent(nametxt, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(gl_contentPane.createSequentialGroup()
                                                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                                                        .addComponent(JL1)
                                                                        .addComponent(JL2, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(JL3, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE))
                                                                .addGap(40)
                                                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                                                        .addComponent(passwordconfigtxt, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(passwordtxt, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE)
                                                                        .addComponent(usernametxt, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE)))))
                                        .addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
                                                .addGap(58)
                                                .addComponent(exit, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(ComponentPlacement.RELATED, 235, Short.MAX_VALUE)
                                                .addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap())
        );
        gl_contentPane.setVerticalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addComponent(Register, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
                                .addGap(42)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(JL1, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(usernametxt, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
                                .addGap(18)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(JL2, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(passwordtxt, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
                                .addGap(27)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addComponent(JL3, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(passwordconfigtxt, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
                                .addGap(18)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addComponent(JL4, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(nametxt, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
                                        .addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(exit, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE))
                                .addGap(28))
        );
        contentPane.setLayout(gl_contentPane);
        //窗口居中
        this.setLocationRelativeTo(null);
    }

    /**
     * 注册功能实现
     * @param event
     */
    private void RegisterAction(ActionEvent event) {
        String username = this.usernametxt.getText();
        String password = new String(this.passwordtxt.getPassword());
        String passwordconfig = new String(this.passwordconfigtxt.getPassword());
        String name=this.nametxt.getText();
        //对用户输出的验证
        if(StringUtil_ZhuCJ.isEmpty(password)) {
            JOptionPane.showMessageDialog(null, "密码不能为空！！！");
            return;
        }
        if(StringUtil_ZhuCJ.isEmpty(passwordconfig)) {
            JOptionPane.showMessageDialog(null, "请再次确认密码！！！");
            return;
        }
        if(!password.equals(passwordconfig)) {
            JOptionPane.showMessageDialog(null, "两次密码不一样请再次输入！");
            return;
        }
        if (StringUtil_ZhuCJ.isEmpty(username)){
            JOptionPane.showMessageDialog(null, "账号不能为空！！！");
            return;
        }else{
            String sql="select * from user where username=?";
            Map<String, Object> map = null;
            try {
                map = template.queryForMap(sql, username);
            } catch (DataAccessException e) {
                System.out.println("账号验证通过");
            }
            if (map!=null){
                JOptionPane.showMessageDialog(null, "账号已经存在！！！");
                return;
            }
        }

        if (StringUtil_ZhuCJ.isEmpty(name)){
            JOptionPane.showMessageDialog(null, "昵称不能为空！！！");
            return;
        }else{
            String sql="select * from user where name=?";
            Map<String, Object> map = null;
            try {
                map = template.queryForMap(sql, name);
            } catch (DataAccessException e) {
                System.out.println("昵称验证通过");
            }
            if (map!=null){
                JOptionPane.showMessageDialog(null, "昵称已经存在！！！");
                return;
            }
        }
        String sql1="insert into user values (id,?,?,?,false)";
        int i = template.update(sql1, username, password, name);
        String listname = username+"friends";
        String sql2 = "create table " + listname + "(friendsname varchar(20);notes varchar (20))";
        //创建好友表
        template.update(sql2);
        if (i>0 ){
            JOptionPane.showMessageDialog(null, "注册成功！！！");
            dispose();
        }else {
            JOptionPane.showMessageDialog(null, "因未知原因，很遗憾注册没能成功");
        }
    }

}