package cn.zcj.CHAT;

import java.awt.*;

public class Main_ZhuCJ {
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogIn_ZhuCJ frame = new LogIn_ZhuCJ();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
