package cn.zcj.Paint;

import java.awt.*;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

/*  javabean封装
    1.接收消息
    2.释放资源

    客户端读写分离
    接收端
 */
public class Receive_ZhuCJ implements Runnable {
    int x1,x2,y1,y2;
    private DataInputStream dis;
    private Socket socket;
    Graphics g;
    private boolean isRunning=true;

    public Receive_ZhuCJ(Graphics g, Socket socket){
        this.socket=socket;
        this.g=g;
        try {
            dis = new DataInputStream(socket.getInputStream());
            System.out.println("获取输入流成功");
        } catch (IOException e) {
            System.out.println("=======2===========");
            release();
        }
    }
    private void receive(){
        System.out.println("1");
        try {

            x1 = dis.readInt();
            y1 = dis.readInt();
            x2 = dis.readInt();
            y2 = dis.readInt();
            System.out.println(x1+" "+y1+" "+x2+" "+y2);
            g.drawLine(x1, y1, x2, y2);
        } catch (IOException e) {
            //出问题就把该客户端直接关闭
            System.out.println("--------2-----------");
            release();
        }

    }
    @Override
    public void run() {
        while (isRunning){
            System.out.println("接收端开始运行");
            receive();
            System.out.println("接受成功一次");
        }
    }


    private void release(){
        //关闭线程并释放资源
        this.isRunning=false;
        Util_ZhuCJ.close(dis,socket);
    }
}
