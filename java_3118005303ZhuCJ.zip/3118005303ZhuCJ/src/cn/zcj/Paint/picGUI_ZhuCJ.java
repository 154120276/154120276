package cn.zcj.Paint;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.net.Socket;

public class picGUI_ZhuCJ extends JFrame {

    Socket client;
    public  static void main(String args[]) {
        picGUI_ZhuCJ CP=new picGUI_ZhuCJ();
        CP.creat();
        CP.showUI();
    }
    public void creat() {
        try {
            client =new Socket("localhost",9090);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //构建甲方界面：600*600，设计鼠标监听器
    public void showUI() {
        this.setTitle("交互画板");
        this.setSize(600, 600);
        this.setDefaultCloseOperation(3);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.setIconImage(new ImageIcon("img/paint.png").getImage());
        Graphics g = this.getGraphics();
        //设置鼠标监听器（发送流）
        this.addMouseListener(new Send_ZhuCJ(g,client));
        //接受接受监听器（接受流）
        new Thread(new Receive_ZhuCJ(g,client)).start();
    }


}
