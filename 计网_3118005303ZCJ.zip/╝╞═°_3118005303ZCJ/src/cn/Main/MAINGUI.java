package cn.Main;
import cn.JDBC.JDBCDruidUtils_ZhuCJ;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import java.awt.EventQueue;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.net.*;
import java.util.List;
import java.util.Map;

public class MAINGUI extends JFrame {

    private JPanel contentPane;
    private JTextArea output;
    public JTextField port;
    private JButton query;
    private String ip;
    private int portstart;
    private int portend;
    //获取数据库连接池中的数据库连接
    private static final JdbcTemplate template = new JdbcTemplate(JDBCDruidUtils_ZhuCJ.getDataSource());

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        /*EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    MAINGUI frame = new MAINGUI(1, 8000, "127.0.0.1");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });*/

    }

    /**
     * Create the frame.
     */
    public MAINGUI(int portstart, int portend, String ip) {
        this.ip = ip;
        this.portstart = portstart;
        this.portend = portend;
        setTitle("\u626B\u63CF\u7ED3\u679C");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 737, 643);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        JScrollPane scrollPane = new JScrollPane();


        JLabel lblNewLabel = new JLabel("\u9700\u8981\u67E5\u8BE2\u4FE1\u606F\u7684\u7AEF\u53E3\u53F7\uFF1A");
        lblNewLabel.setFont(new Font("黑体", Font.PLAIN, 20));

        port = new JTextField();
        port.setColumns(10);

        query = new JButton("\u67E5\u8BE2");
        query.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    if (Integer.parseInt(port.getText()) < 1 || Integer.parseInt(port.getText()) > 65535) {
                        alert("错误", "请输入1-65535之内的数字");
                    } else {
                        JDBCquery(port.getText());
                    }
                } catch (NumberFormatException numberFormatException) {
                    alert("错误", "请输入1-65535之内的数字，别输入非数字或空白");
                }
            }
        });
        query.setFont(new Font("黑体", Font.PLAIN, 20));
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 723, GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 228, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.UNRELATED)
                                .addComponent(port, GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                                .addGap(18)
                                .addComponent(query, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE)
                                .addGap(23))
        );
        gl_contentPane.setVerticalGroup(
                gl_contentPane.createParallelGroup(Alignment.LEADING)
                        .addGroup(gl_contentPane.createSequentialGroup()
                                .addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 531, GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(ComponentPlacement.UNRELATED)
                                .addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
                                        .addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 45, Short.MAX_VALUE)
                                        .addComponent(port, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
                                        .addComponent(query, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
                                .addContainerGap())
        );
        output = new JTextArea();
        scrollPane.setViewportView(output);
        contentPane.setLayout(gl_contentPane);
        //窗口居中
        this.setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        Messageappend("开始扫描........\n");
        Messageappend("扫描的端口号范围为："+portstart+"~~"+portend+"\n");
        Messageappend("扫描的主机IP地址为："+ip+"\n");
        Messageappend("扫描结束，开放的端口号如下：\n");
        for (int i = portstart; i <= portend; i++) {
            Scan s = new Scan(i, ip);
            s.start();
        }


    }

    public void Messageappend(String msg) {
        output.append(msg);
    }


    class Scan extends Thread {
        int port;
        String Ip;

        Scan(int port, String Ip) {
            this.port = port;
            this.Ip = Ip;
        }

        public void run() {
            Socket socket;
            try {
                socket = new Socket(Ip, port);
                Messageappend("端口" + port + "为开放的，类型为TCP" + "\n");
                /* System.out.println("端口"+port+"为开放的，类型为TCP");*/
                socket.close();
            } catch (Exception e) {
                //只有本机才扫描UDP
                /*System.out.println("端口"+i+"不开放的");*/
                if(ip.equals("127.0.0.1")) {
                    try {
                        DatagramSocket server = new DatagramSocket(port);
                        server.close();
                        /*Messageappend("端口"+port+"未开放的"+"\n");*/
                        /* System.out.println("端口"+port+"不开放的");*/
                    } catch (SocketException e1) {

                        Messageappend("端口" + port + "为开放的，类型为UDP" + "\n");

                        /*  System.out.println("端口"+port+"为开放的，类型为UDP");*/
                    }
                }else{

                }
            }


        }
    }

    // 显示标题为title，内容为message的对话框，简化书写
    private void alert(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

    private void JDBCquery(String port) {
        String sql = "select * from port where port=?";
        Map<String, Object> map;
        try {
            map = template.queryForMap(sql, port);
        } catch (DataAccessException e) {
            alert("错误","数据库中未保存此端口，可能不在1-1023端口号" +
                    "和常用端口号中，数据库也无此端口号信息"+"\n                   （绝对不是我偷懒.JPG，实在是太多了）");
            return;
        }
        String sql2 = "select * from port where port=?";
        List<cn.Main.port> list = template.query(sql2, new BeanPropertyRowMapper<>(port.class), port);

        for (cn.Main.port port1 : list) {
            alert("端口号" + port1.getPort() + "的简介", "使用端口服务的名称：" + port1.getName() + "\n简介：" + port1.getIntroduction());
        }
    }
}


