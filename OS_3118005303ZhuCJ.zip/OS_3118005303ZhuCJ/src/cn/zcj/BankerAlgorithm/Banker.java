package cn.zcj.BankerAlgorithm;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Banker {
    int[] available = new int[]{15, 12, 10};//可得到的资源
    int[] state = new int[]{-1, -1, -1, -1, -1};
    int[][] allocation = new int[][]{{0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}};//每个进程目前拥有的资源数
    int[][] need = new int[5][3];//每个进程需要的资源数

    boolean checkfinish(int i){
        return need[i][0] == 0 && need[i][1] == 0 && need[i][2] == 0;
    }

    void showData()//展示数据输出每个进程的相关数据
    {
        System.out.println("系统现有资源:"+"A:"+available[0]+"  B:"+available[1]+"  C:"+available[2]);
        System.out.println("格式为：");
        System.out.println("进程号 运行状态 Allocation Need ");
        System.out.println("运行状态 0运行 -1等待 1完成 -2阻塞");
        System.out.println("     A B C A B C");
        for (int i = 0; i < 5; i++) {
            System.out.print(i + " " + state[i] + " ");
            for (int m = 0; m < 3; m++) System.out.print(allocation[i][m] + " ");
            for (int m = 0; m < 3; m++) System.out.print(need[i][m] + " ");
            System.out.println();
        }
    }

    boolean change(int inRequestNum, int[] inRequest)//分配数据
    {
        // for(int i=0;i<3;i++)System.out.println("修改前available"+available[i]);
        if (!(inRequest[0] <= need[inRequestNum][0] && inRequest[1] <= need[inRequestNum][1] && inRequest[2] <= need[inRequestNum][2])) {
            System.out.println("请求的资源数超过了所需要的最大值，分配错误");
            return false;
        }
        if (!(inRequest[0] <= available[0] && inRequest[1] <= available[1] && inRequest[2] <= available[2])) {
            System.out.println("尚无足够资源分配，必须等待");
            return false;
        }

        for (int i = 0; i < 3; i++)//试分配数据给请求的线程
        {
            available[i] = available[i] - inRequest[i];
            allocation[inRequestNum][i] = allocation[inRequestNum][i] + inRequest[i];
            need[inRequestNum][i] = need[inRequestNum][i] - inRequest[i];
        }
        System.out.println(available[0]+""+available[1]+""+available[2]);
        boolean flag = checkSafe(available[0], available[1], available[2]);//进行安全性检查并返回是否安全
         System.out.println("安全性检查后"+flag);
        if (flag) {
            return true;
        } else//不能通过安全性检查 恢复到未分配前的数据
        {
            for (int i = 0; i < 3; i++) {
                available[i] = available[i] + inRequest[i];
                allocation[inRequestNum][i] = allocation[inRequestNum][i] - inRequest[i];
                need[inRequestNum][i] = need[inRequestNum][i] + inRequest[i];
            }
            return false;
        }
    }





    boolean checkSafe(int a,int b,int c)//安全性检查
    {
        int[] work = new int[3];
        work[0] = a;
        work[1] = b;
        work[2] = c;
        int i=0;
        int count = 0;//完成进程数
        int circle=0;//循环圈数
        boolean[] finish = new boolean[5];
        while(i<5)//寻找一个能够满足的认为完成后才去执行下一进程
        {
            if(finish[i]==false && need[i][0]<=work[0] && need[i][1]<=work[1] && need[i][2]<=work[2])
            {//找到满足的修改work值，然后i=0，重新从开始的为分配的中寻找
//                System.out.println("分配成功的是"+i);
                for(int m = 0;m<3;m++) {
                    work[m] = work[m] + allocation[i][m];
                }
                finish[i] = true;
                i=0;
                count++;
//                System.out.println(i+" "+circle+" "+count);
                circle++;
            }
            else {//如果没有找到直接i++
                i++;
            }
            if (count==5){
                return true;
            }
            if(count<circle){//判断完成进程数是否小于循环圈数
                count=5;
                System.out.println("当前系统处于不安全状态，故不存在安全序列。");
                return false;//跳出循环
            }
        }
        /*for(i=0;i<5;i++)//通过finish数组判断是否都可以分配
        {
            if(finish[i]==false)
                return false;
        }*/

        return false;
    }

    public static void main(String[] args) {
        Banker bank = new Banker();
        Scanner s = new Scanner(System.in);
        List<PCB2> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            PCB2 newpcb = new PCB2(i);
            list.add(newpcb);
            bank.need[i] = newpcb.need;
        }
        bank.showData();
        int[] request =new int[3];
        String[] source = new String[]{"A","B","C"};
        int j = 0;
        while(true)//循环进行分配
        {
            System.out.println("进程"+j+"正在运行");
            bank.state[j] = 0;
            list.get(j).setState(0);
            bank.showData();
            System.out.println("请输入请求的资源数目");
            for(int i = 0;i<3;i++)
            {
                System.out.println(source[i]+"资源的数目：");
                request[i] = s.nextInt();
            }

            boolean change = bank.change(j, request);
            if (change) {
                System.out.println("进程" + j + "请求资源成功并运行了一个时间片");
                bank.state[j] = -1;
                if (bank.checkfinish(j)) {
                    System.out.println("进程" + j + "完成了运行");
                    bank.state[j] = 1;
                    list.get(j).setState(1);
                    //归还资源
                    bank.available[0]+=bank.allocation[j][0];
                    bank.available[1]+=bank.allocation[j][1];
                    bank.available[2]+=bank.allocation[j][2];
                }
            } else {
                System.out.println("进程" + j + "请求资源失败并进入到阻塞状态");
                bank.state[j] = -2;
            }

            int count = 0;
            for (PCB2 pcb1 : list) {
                if (pcb1.getState() == 1) {
                    count++;
                }
            }
            if (count == 5) {
                System.out.println("所有进程运行完毕");
                break;
            }
            j++;
            if (j>4){
                j=0;
            }
            while (list.get(j).getState() ==1){
                j++;
            }

            /*if (list.get(j).getState() != -1 ||list.get(j).getState() != -2) {
                j++;
                if (j >4) {
                    j = 0;
                }
                while (list.get(j).getState() != -1 ||list.get(j).getState() != -2) {
                    j++;
                    if (j >4) {
                        j = 0;
                    }
                }
            }*/

        }


        //如果请求也是自己生成的话程序的运行时间实在是过于太长了，因为随机性太大
       /* Banker bank = new Banker();
        Scanner s = new Scanner(System.in);
        List<PCB2> list = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            PCB2 newpcb = new PCB2(i);
            list.add(newpcb);
            bank.need[i] = newpcb.need;
        }
        bank.showData();
        int request[] =new int[3];
        String source[] = new String[]{"A","B","C"};
        int j = 0;
        while(true)//循环进行分配
        {
            System.out.println("进程"+j+"正在运行");
            *//*System.out.println("请输入请求的资源数目");*//*
        for(int i = 0;i<3;i++)
        {
            *//*System.out.println(source[i]+"资源的数目：");*//*
            request[i] = (int) (Math.random()*bank.need[j][i]);
        }

        boolean change = bank.change(j, request);
        if (change) {
            System.out.println("进程" + j + "请求资源成功并运行了一个时间片");
            bank.state[j] = -1;
            if (bank.checkfinish(j)) {
                System.out.println("进程" + j + "完成了运行");
                bank.state[j] = 1;
                list.get(j).setState(1);
                //归还资源
                bank.available[0]+=bank.allocation[j][0];
                bank.available[1]+=bank.allocation[j][1];
                bank.available[2]+=bank.allocation[j][2];
            }
        } else {
            System.out.println("进程" + j + "请求资源失败并进入到阻塞状态");
            bank.state[j] = -2;
        }

        int count = 0;
        for (PCB2 pcb1 : list) {
            if (pcb1.getState() == 1) {
                count++;
            }
        }
        if (count == 5) {
            System.out.println("所有进程运行完毕");
            break;
        }
        j++;
        if (j>=5){
            j=0;
        }
        if (list.get(j).getState() != -1) {
            while (list.get(j).getState() != -1) {
                j++;
                if (j >= 5) {
                    j = 0;

                }
            }
        }
        bank.showData();

    }*/
    }
}

