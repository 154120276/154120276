package cn.zcj.BankerAlgorithm;

//PCB进程块类
public class PCB2 {
    public int name;//名称
    public int need[]=new int[3];
    private int state=-1;//状态 0运行 -1wait 1完成 -2阻塞



    public int getState() {
        return state;
    }

    public void setState(int state) {
        if (state == 0 || state == 1 || state == -1 || state==-2) {
            this.state = state;
        }
    }

    public PCB2(int name) {
        this.name = name;
        need[0]=(int)(Math.random()*10);
        need[1]=(int)(Math.random()*10);
        need[2]=(int)(Math.random()*10);
    }
}
