package cn.zcj.PCB;

//PCB进程块类
public class PCB {
    public String name;//名称
    public int ArriveTime;//到达时间
    public int RunningTime;//已经运行时间
    public int RunTime;//需要运行的时间
    private int state=-2;//状态 0运行 -1wait 1完成 -2未到达
    public double Response_Ratio;//响应比
    public int TurnaroundTime;//周转时间


    public PCB(String name, int arriveTime) {
        this.name = name;
        ArriveTime = arriveTime;
        int i=(int)(Math.random()*10)+1;
        RunTime=i;
    }

    public int getState() {
        return state;
    }

    @Override
    public String toString() {
        return "PCB{" +
                "name='" + name + '\'' +
                ", ArriveTime=" + ArriveTime +
                ", RunningTime=" + RunningTime +
                ", RunTime=" + RunTime +
                ", state=" + state +
                ", Response_Ratio=" + Response_Ratio +
                '}';
    }

    public void setState(int state) {
        if (state == 0 || state == 1 || state == -1 || state==-2) {
            this.state = state;
        }
    }

    //设置响应比
    public void setResponse_Ratio(int now) {
        long waittingtime = now - ArriveTime;
        long l = waittingtime + RunTime;
        Response_Ratio = ((double) l / (double) (RunTime));
    }

}
