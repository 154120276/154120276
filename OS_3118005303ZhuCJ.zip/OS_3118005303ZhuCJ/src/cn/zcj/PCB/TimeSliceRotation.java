package cn.zcj.PCB;

import java.util.ArrayList;
import java.util.List;
//时间片轮转 时间片为2

public class TimeSliceRotation {
    TimeSliceRotation() {
        int counts = 0;
        List<PCB> list = new ArrayList<>();
        List<PCB> waitlist = new ArrayList<>();
        PCB pcb = new PCB("进程1", 0);
        list.add(pcb);
        for (int i = 2; i < 6; i++) {
            int time = (int) (Math.random() * 10);
            PCB pcb2 = new PCB("进程" + i, time + 1);
            list.add(pcb2);
        }
        for (PCB pcb1 : list) {
            System.out.println(pcb1);
        }
        PCB isrunning = null;
        isrunning = pcb;
        PCB last=null;
        PCB lastrunning=null;
        int timecount=0;
        for (int i =1; i <100 ; i++) {
            if (isrunning.getState()!=1) {
                isrunning.setState(0);
            }
            if (last==isrunning) {
                System.out.println("第" + i + "时间" + "等待新进程进入等待队列！");
            }else if (isrunning.RunningTime>=isrunning.RunTime){
                isrunning.TurnaroundTime=i-isrunning.ArriveTime;
                System.out.println("第" + i + "时间" + isrunning.name + "正在运行");
                System.out.println(isrunning.name + "运行完毕" + "平均周转时间:" + isrunning.TurnaroundTime);
                last=isrunning;
                int count=0;
                isrunning.setState(1);
                for (PCB pcb1 : list) {
                    if(pcb1.getState()==1){
                        count++;
                    }
                }
                 if (count==5) {
                     System.out.println("所有进程运行完毕");
                     break;
                 }
                 timecount=999;
                for (PCB pcb1 : list) {
                    System.out.println(pcb1);
                }
            }
            for (PCB pcb1 : list) {
                if (pcb1.ArriveTime<i && pcb1.getState()==-2){
                    pcb1.setState(-1);
                    if (!waitlist.contains(pcb1)){
                        waitlist.add(pcb1);
                    }
                }
            }
            if (timecount<2){
                System.out.println("第" + i + "时间" + isrunning.name + "正在运行");
                timecount++;
                if (isrunning.RunningTime<isrunning.RunTime) {
                    isrunning.RunningTime++;
                }
            }else {
                if (!waitlist.isEmpty()) {
                    lastrunning=isrunning;
                    isrunning = waitlist.get(0);
                    System.out.println(isrunning.name+"上处理机了");
                    waitlist.remove(0);
                    i--;
                }else {
                    i--;
                }
                if (lastrunning!=null) {
                    if (lastrunning.getState() != 1) {
                        waitlist.add(lastrunning);
                    }
                }
                timecount=0;
            }

        }
        double sum=0;
        for (PCB pcb1 : list) {
            sum+=pcb1.TurnaroundTime;
        }
        System.out.println("本次进程调度的平均周转时间为:"+sum/5);
    }

}

