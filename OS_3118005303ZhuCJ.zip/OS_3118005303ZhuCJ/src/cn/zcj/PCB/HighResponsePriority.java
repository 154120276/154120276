package cn.zcj.PCB;

import java.util.ArrayList;
import java.util.List;
//高响应比优先 （非抢占式）

public class HighResponsePriority {
    HighResponsePriority() {
        List<PCB> list=new ArrayList<>();
        PCB pcb=new PCB("进程1",0);
        list.add(pcb);
        for (int i = 2; i <6; i++) {
            int time=(int)(Math.random()*40);
            PCB pcb2=new PCB("进程"+i,time+1);
            list.add(pcb2);
        }
        for (PCB pcb1 : list) {
            System.out.println(pcb1);
        }
        PCB isrunning=null;
        isrunning=pcb;
        PCB lastrunning=null;
        for (int i =1; i <100 ; i++) {
            if (lastrunning!=isrunning){
                System.out.println("第"+i+"时间"+isrunning.name+"正在运行");
            }

            if (isrunning.getState()!=1) {
                isrunning.setState(0);
            }
            if (isrunning.RunningTime<isrunning.RunTime) {
                isrunning.RunningTime++;
            }
            if (isrunning.RunningTime>=isrunning.RunTime){
                if (lastrunning!=isrunning){
                    isrunning.TurnaroundTime=i-isrunning.ArriveTime;
                }
                System.out.println(isrunning.name+"运行完毕"+"平均周转时间:"+isrunning.TurnaroundTime);
                int count=0;
                isrunning.setState(1);
                for (PCB pcb1 : list) {
                    System.out.println(pcb1);
                    if(pcb1.getState()==1){
                        count++;
                    }
                }
                 if (count==5){
                     System.out.println("所有进程运行完毕");
                    break ;
                }
                double max=0;//先设为无限小
                //初始化等待队列
                for (PCB pcb1 : list) {
                    if (pcb1.ArriveTime<i && pcb1.getState()==-2){
                        pcb1.setState(-1);
                        pcb1.Response_Ratio=(double)((i-pcb1.ArriveTime)+pcb1.RunTime)/(double) pcb1.RunTime;
                    }
                }
                lastrunning=isrunning;
                for (PCB pcb1 : list) {
                    if (pcb1.getState()==-1){
                        if (max<=pcb1.Response_Ratio){
                            max=pcb1.Response_Ratio;
                            isrunning=pcb1;
                        }
                    }
                }
                if (lastrunning==isrunning){
                    System.out.println("等待新进程进入");
                }

            }

        }
        double sum=0;
        for (PCB pcb1 : list) {
            sum+=pcb1.TurnaroundTime;
        }
        System.out.println("本次进程调度的平均周转时间为:"+sum/5);
    }


}
