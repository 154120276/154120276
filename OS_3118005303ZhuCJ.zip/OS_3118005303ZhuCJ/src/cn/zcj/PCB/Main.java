package cn.zcj.PCB;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int i;
        Scanner scanner=new Scanner(System.in);
        boolean flag = true;
        while (flag) {
            System.out.println("欢迎进入进程调度算法模拟系统！");
            System.out.println("请输入选项:\n0.短作业优先\n1.高响应比优先\n2.时间片轮转\n3.退出系统");
            i=scanner.nextInt();
            switch (i) {
                case 0:
                    new shortfirst();
                    break;
                case 1:
                    new HighResponsePriority();
                    break;
                case 2:
                    new TimeSliceRotation();
                    break;
                case 3:
                    flag=false;
                    System.out.println("退出成功！感谢使用！");
                    break;
                default:
                    System.out.println("输入错误，请重新输入");
            }
        }
    }
}
