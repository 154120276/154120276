package cn.zcj.test;

import cn.zcj.dao.UserDao;
import cn.zcj.domain.User;
import org.junit.Test;

public class UserDaotest {

    @Test
    public void testlogin(){
        User user=new User();
        user.setUsername("superbaby");
        user.setPassword("123");

        UserDao dao=new UserDao();
        User login = dao.login(user);

        System.out.println(user);
    }
}
