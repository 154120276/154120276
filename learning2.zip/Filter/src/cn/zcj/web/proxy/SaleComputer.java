package cn.zcj.web.proxy;

public interface SaleComputer {

    public String sale(double money);

    public void show();
}
