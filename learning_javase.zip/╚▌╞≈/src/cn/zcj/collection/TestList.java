package cn.zcj.collection;
//test01����Collection�ӿ��еķ���
//test02���Լ�������ķ���
import java.util.*;			

public class TestList {
	public static void main(String[] args) {
		test03();
	}

 public static void test01() {
	 Collection<String> c=new ArrayList<String>();
		Set set;
	 
	 	System.out.println(c.size());
		System.out.println(c.isEmpty());
		c.add("�쳤��");
		c.add("����");
		System.out.println(c);
		System.out.println(c.size());
		System.out.println(c.contains("�쳤��"));//�����Ƿ����쳤��
		Object[] objs=c.toArray();
		System.out.println(objs);
		c.remove("����");
		System.out.println(c);
		c.clear();//�Ƴ�����Ԫ��
		System.out.println(c);
 }
 public static void test02() {
	 List<String> list01=new ArrayList<>();
	 list01.add("aa");
	 list01.add("bb");
	 list01.add("cc");
	 List<String> list02=new ArrayList<>();
	 list02.add("aa");
	 list02.add("dd");
	 list02.add("ee");
	 System.out.println("list01:"+list01);
	 list01.addAll(list02);
	 //list01.removeAll(list02);
	 //list01.retainAll(list02);
	 System.out.println("list01:"+list01);
	 System.out.println(list01.containsAll(list02));
	 
 }
 public static void test03(){
	 List<String> list=new ArrayList<>();
	 list.add("A");
	 list.add("B");
	 list.add("C");
	 list.add("D");
	 System.out.println(list);
	 list.add(2,"�쳤��");
	 System.out.println(list);
	 list.remove(2);
	 System.out.println(list);
	 list.set(2, "�쳤��");
	 System.out.println(list);
	 System.out.println(list.get(2));
	 list.add("A");
	 list.add("B");
	 list.add("C");
	 System.out.println(list.indexOf("���϶�"));
	 System.out.println(list.indexOf("B"));
	 System.out.println(list.lastIndexOf("B"));
 }
}