package cn.zcj.collection;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class TestTreeSet {
	public static void main(String[] args) {
		Set<Integer> treeset=new TreeSet<>();
		treeset.add(330);
		treeset.add(660);
		treeset.add(150);
		for (Integer key : treeset) {
			System.out.println(key);
		}
		Set<Emp2> treeset1=new TreeSet<>();
		treeset1.add(new Emp2(101,"�쳤��",10000));
		treeset1.add(new Emp2(102,"�쳤",6000));
		treeset1.add(new Emp2(103,"��",3000));
		treeset1.add(new Emp2(108,"��2",3000));
		for (Emp2 key : treeset1 ) {
			System.out.println(key);
		
	}
}
}

class Emp2 implements Comparable<Emp2>{
	int id;
	String name;
	int salary;
	
	public Emp2(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	@Override
	public String toString() {
		// TODO �Զ����ɵķ������
		return "id:"+id+"\t"+"name:"+name+"\t"+"salary:"+salary;
	}
	@Override
	public int compareTo(Emp2 o) {//����С�ڣ�����ڣ���������
		if(this.salary>o.salary) {
			return 1;
		}
		else if(this.salary<o.salary) {
			return -1;
		}
		else {
			if(this.id>o.id) {
				return 1;
			}
			else if(this.id<o.id) {
				return -1;
			}
			else {
				return 0;
			}
			
		}
	}
}
	
