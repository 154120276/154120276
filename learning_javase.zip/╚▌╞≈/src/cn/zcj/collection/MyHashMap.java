package cn.zcj.collection;

public class MyHashMap {
	Node[] table;//λͰ����
	int size;//��ŵļ�ֵ������
	public MyHashMap() {
		table=new Node[16];
	}
	@Override
	public String toString() {
		StringBuilder sb=new StringBuilder("[");
		for(int i=0;i<table.length;i++) {
			Node temp=table[i];
			while(temp!=null) {
				sb.append(temp.key+":"+temp.value+";");
				temp=temp.next;	
			}
		}
		sb.setCharAt(sb.length()-1,']');
		return sb.toString();
	}
	public static void main(String[] args) {
		MyHashMap m=new MyHashMap();
		m.put(53, "z");
		m.put(69, "c");
		m.put(85, "j");
		System.out.println(m);
		
	}
	public int myHash(int v,int length) {
		System.out.println("hashֵ��"+(v&(length-1)));//��Ч�ʵ�λ����ȡ��  
		return v&(length-1);
	}
	public void put(Object key,Object value) {
		Node newnode=new Node();
		newnode.hash=myHash(key.hashCode(), table.length);
		newnode.key=key;
		newnode.value=value;
		newnode.next=null;
		Node temp=table[newnode.hash];//�жϱ��
		Node nexttemp=null;
		if(temp==null) {
			table[newnode.hash]=newnode;
		}else {
			//�˴����鲻Ϊ�վͱ�������
			while(temp!=null) {
				if(temp.key.equals(key)) {
					temp.value=value;
					return;
				}else {
					nexttemp=temp;
					temp=temp.next;
				}
			}
			nexttemp.next=newnode;
		}
		
	}
}
