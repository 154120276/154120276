package cn.zcj.collection;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

//���ORM˼��
//ÿһ������ʹ��javabean����洢������ʹ�÷ŵ�Map����List��
public class TestStoreDate2 {
	public static void main(String[] args) {
		User user1=new User(1001,"����",20000,"2018.5.5");
		User user2=new User(1002,"����",30000,"2005.4.4");
		User user3=new User(1003,"����",3000,"2020.5.4");
			
		List<User> list=new ArrayList<User>();
		list.add(user1);
		list.add(user2);
		list.add(user3);
		for (User user : list) {
			System.out.println(user);
		}
			
		Map<Integer, User> map=new HashMap<Integer, User>();
		map.put(1, user1);
		map.put(2, user2);
		map.put(3, user3);
		
		Set<Integer> keyset=map.keySet();
		for (Integer key : keyset) {
			System.out.println(key+"----"+map.get(key));
		}
		
	}
}
	
class User{
	private int id;
	private String name;
	private double salary;
	private String hiredate;
	//һ��������javabeanҪ��set��get�������Լ�һ���޲εĹ�����
	public User(){
		
	}
	
	public User(int id, String name, double salary, String hiredate) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.hiredate = hiredate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	@Override
	public String toString() {
		// TODO �Զ����ɵķ������
		return "id:"+id+"��name:"+name+"��salary:"+salary+"����ְʱ��"+hiredate;
	}
	
}