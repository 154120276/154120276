package cn.zcj.collection;

//���Է���

public class TestGeneric {
		public static void main(String[] args) {
			Mycollection<String> mc=new Mycollection<String>();
			mc.set("�쳤��", 0);
			String b=mc.get(0);
			System.out.println(mc.get(0));
		}
}

class Mycollection<E>{
	Object[] objs=new Object[5];
	public void set(E e,int index) {
		if(0<=index&&index<=4) {
			objs[index]=e;
		}
		else
			System.out.println("����λ�Ӵ��󸲸�ʧ��");
	}
	public E get(int index){
			return (E)objs[index];
		
	}
}
