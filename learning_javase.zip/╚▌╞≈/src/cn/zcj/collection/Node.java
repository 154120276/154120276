package cn.zcj.collection;

public class Node {
	int hash;
	Object key;
	Object value;
	Node next;
	
	
}
