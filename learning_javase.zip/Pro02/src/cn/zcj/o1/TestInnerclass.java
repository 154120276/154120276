package cn.zcj.o1;

public class TestInnerclass {
public static void main(String[] args) {
	Outer.Inner inner=new Outer().new Inner();
	inner.show();

}
}
class Outer{
	private int age=15;
	public void Outer() {
	
	}
	class Inner{
		int age=25;
		public void show() {
			int age=30;
			System.out.println("�ⲿ��ĳ�Ա����age:"+Outer.this.age);
			System.out.println("�ڲ���ĳ�Ա����age:"+this.age);
			System.out.println("�ֲ�����age:"+age);
		}
	} 
}
