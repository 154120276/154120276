package cn.zcj.o1;

public class TestString {
public static void main(String[] args) {
		
		/*
		 * String s1="zcj learn Java"; String s2="Core Java"; String s3="core java";
		 * System.out.println("#################"); System.out.println(s1.charAt(1));
		 * System.out.println("#################"); System.out.println(s1.length());
		 * System.out.println(s2.equalsIgnoreCase(s3));
		 * System.out.println(s1.indexOf("learn")); System.out.println(s1.indexOf(s2));
		 * String s=s1.replace(' ','&'); System.out.println(s);
		 */
	String s="";
	String s1="How are you?";
	System.out.println(s1.startsWith("How"));
	System.out.println(s1.endsWith("you"));
	s=s1.substring(4);
	System.out.println(s);
	s=s1.substring(4,7);
	System.out.println(s);
	s=s1.toLowerCase();
	System.out.println(s);
	s=s1.toUpperCase();
	System.out.println(s);
	String s2="   How old are you?     ";
	s=s2.trim();
	System.out.println(s);
	System.out.println(s2);
	
	
	
		 }
}
