package cn.zcj.o1;

public class Testarrys {
public static void main(String[] args) {
	
int[] a= {11,15,66};
student[] stu= {
		new student(101,"�쳤��",19),
		new student(102,"�쳤",20),
		new student(103,"����",19)
};
for(int i=0;i<3;i++)
	System.out.println(stu[i].name);
for(int i=0;i<3;i++)
	System.out.println(a[i]);
for(student m:stu) {
	System.out.println(m.age);
}
}
}
