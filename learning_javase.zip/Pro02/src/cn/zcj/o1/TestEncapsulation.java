package cn.zcj.o1;

public class TestEncapsulation {
	public static void main(String[] args) {
		Human h=new Human();
		//h.age=55;
		Person4 p=new Person4();
		p.setage(14);
		p.setage(-14);
		
	}
	}
class Human{
	private int age;
	
	void sayAge(){
		System.out.println(age);	
	}
}
	
class Boy extends Human{
	void sayHellow() {
		
		//System.out.println(age);
	}
	
}

