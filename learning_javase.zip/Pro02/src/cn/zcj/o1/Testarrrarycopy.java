package cn.zcj.o1;

import java.util.Arrays;

public class Testarrrarycopy {
	public static void main(String[] args) {
		String[] s1= {"����","����","�ٶ�","������","����ѷ"};
		
		String[] s2=new String[10];
		String s="�쳤��";
		s1=Insertarrary(s1, 2, s);
		/* ���� */
		Arrays.sort(s1);
		System.out.println(Arrays.toString(s1));
		/* ���ַ����� */
		System.out.println(Arrays.binarySearch(s1, "�쳤��"));
		int[][] a= {{1,2,3},{3,4},{3,4,5,8}};
		for(int i=0;i<3;i++)
		System.out.println(Arrays.toString(a[i]));
		
	}

	public static  void deletearrary(String[] s1,int Index) {//ɾ��
		int index=Index+1;
		System.arraycopy(s1, index, s1, index-1, s1.length-index);
		s1[s1.length-1]=null;
		System.out.println(Arrays.toString(s1));
	}
	public static String[] addarrarycapacity(String[] str) {//����
		String[] str1=new String[str.length+10];
		System.arraycopy(str,0 , str1, 0, str.length);
		return str1;
	}
	
	  public static String[] Insertarrary(String[] str,int index,String s) { 
		  if(index>str.length) {
			  System.out.println("�������ķ�Χ�������鳤��");
			  return str;
		  }
		  String[] str1=new String[str.length+1];
		  String[] str2= {s};
		  if(index==str.length) {
			  System.arraycopy(str,0,str1,0,str.length);
			  System.arraycopy(str2,0,str1,str.length,1);
		  } 
		  else {
		  System.arraycopy(str,0,str1,0,index+1);
		  System.arraycopy(str2,0,str1,index,1);
		  System.arraycopy(str,index,str1,index+1,str.length-index);
		 
		  }
		  
	  return str1;
	  }
	 
	
	
	
	
	
}
