package cn.zcj.o1;

public class student {
	int id;
	String name;
	int age;
	computer comp;
	
	void play(){
		System.out.println(name+"���ڴ���Ϸ����CSGO��"+comp.bland+"����");	
	}
	void study() {
		System.out.println(name+"����ѧϰ��");
	}
	student(){
		
	} 
	 
	public student(int id, String name, int age) {
		this.id = id;
		this.name = name;
		this.age = age;
	}
	public static void main(String[] args) {
		student stu=new student();
		stu.id=1001;
		stu.name="����";
		stu.age=18;
		computer c1=new computer();
		c1.bland="����";
		stu.comp=c1;
		stu.play();
		stu.study();
		
	}
}


class computer{
	String bland;
}