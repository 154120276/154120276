package cn.zcj.o1;

public class Person4 {
	private int age;
	private String name;
	private boolean man;
	
	public void setname(String name) {
		this.name=name;	
	}
	public void setage(int age) {
		if(age>0&&age<130) {
		this.age=age;
		System.out.println(this.age);
		}
		else 
			System.out.println("��������ȷ������");
	}
	
}
