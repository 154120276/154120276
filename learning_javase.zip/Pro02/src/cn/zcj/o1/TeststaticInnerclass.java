package cn.zcj.o1;

public class TeststaticInnerclass {
	public static void main(String[] args) {
		Outer2.Inner2 Inner=new Outer2.Inner2();
	}

}

class Outer2{
	
	static class Inner2{
		
	}
}