package cn.zcj.o1;
class Point{
	double x;
	double y;
	public Point(double x,double y) {
	this.x=x;
	this.y=y;
	}
	double getDistance(Point p){
		
		return Math.sqrt((x-p.x)*(x-p.x)+(y-p.y)*(y-p.y));
	}
	
}


public class Testconstructor {
	public static void main(String[] args) {
		Point p=new Point(6.5,8.2);
		Point c=new Point(1.2,3.2);
		System.out.println(p.getDistance(c));
	}	
}
