package cn.zcj.TestException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test02 {
	public static void main(String[] args) {
		FileReader reader=null;
		try {
			 reader=new FileReader("D:/java/bb.txt");
			char ce=(char)reader.read();
			System.out.println(ce);
		} catch (FileNotFoundException e) {	
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			System.out.println("step");
			try {
				if(reader!=null)
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
