package cn.zcj.TestException;



public class Test04 {
public static void main(String[] args) {
	Person p=new Person();
	p.setAge(-10);
	
}
}
 
class IllegalAgeExecption extends RuntimeException{
	public IllegalAgeExecption() {
	}
	public IllegalAgeExecption(String zcj) {
		super(zcj);
	}
}
class Person{
	private int age;

	public int getAge()  {
		
		return age;
	}

	public void setAge(int age) {
		if(age<0) 
			throw new IllegalAgeExecption("���䲻��Ϊ����");
		this.age = age;
	}
	
}