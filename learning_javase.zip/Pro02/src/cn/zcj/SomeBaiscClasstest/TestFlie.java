package cn.zcj.SomeBaiscClasstest;

import java.io.File;
import java.io.IOException;

public class TestFlie {
	public static void main(String[] args) throws IOException {
		File f=new File("D:\\java\\a.txt");
		System.out.println(f);
		f.renameTo(new File("D:/java/bb.txt"));
		System.out.println(System.getProperty("user.dir"));
		File f2=new File("gg.txt");
		f2.createNewFile();
	}
}
