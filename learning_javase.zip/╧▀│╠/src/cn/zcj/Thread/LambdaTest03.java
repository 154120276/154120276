package cn.zcj.Thread;

//lambda�Ƶ�+�������

public class LambdaTest03 {
	
	public static void main(String[] args) {
		add ADD=(int a,int b)-> {
			System.out.println("�Ұ����ɵ��-->"+(a+b));
			return a+b;
			};
			ADD.lambda(100, 200);
			
			ADD=(a,b)-> {
				System.out.println("�Ұ����ɵ��-->"+(a+b));
				return a+b;
				};
				ADD.lambda(200, 300);
				ADD=(a,b)-> {
					return a+b;
					};
				//return����
				ADD=(a,b)->a+b;
				System.out.println(ADD.lambda(55, 36));
				
					
				
}
}

interface add{
	int lambda(int a,int b);
}
	
class Add1 implements add{


	public int lambda(int a,int b) {
	System.out.println("�Ұ����ɵ��-->"+(a+b));
	return a+b;
	}
	
}