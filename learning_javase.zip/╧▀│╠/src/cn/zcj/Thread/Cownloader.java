package cn.zcj.Thread;
//�˽�Callable������дcall
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

//���ⵥ�̳еľ����ԣ�����ʹ�ýӿ�
public class Cownloader implements Callable<Boolean>{
	private String url;
	private String name;
	public Cownloader(String url, String name) {
		super();
		this.url = url;
		this.name = name;
	}
	@Override
	public Boolean call() {
		WebDownloader wd=new WebDownloader();
		wd.Download(url, name);
		System.out.println(name);
		return true;
	}
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		Cownloader td2=new Cownloader("http://p1.pstatp.com/large/403c00037462ae2eee13", "spl.jpg");
		Cownloader td3=new Cownloader("http://5b0988e595225.cdn.sohucs.com/images/20170830/d8b57e0dce0d4fa29bd5ef014be663d5.jpeg", "lxl.jpg");
		
		//����ִ�з���
		ExecutorService ser=Executors.newFixedThreadPool(2);
		//�ύִ��
		Future<Boolean> result1=ser.submit(td2);
		Future<Boolean> result2=ser.submit(td3);
		//��ȡ���
		boolean r2=result1.get();
		boolean r3=result2.get();
		System.out.println(r2);
		System.out.println(r3);
		//�رշ���
		ser.shutdown();
		
	}

}
