package cn.zcj.syn;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author ����
 *
 */

public class Happycinema {
	public static void main(String[] args) {
		List<Integer> available=new ArrayList<Integer>();
		available.add(1);
		available.add(2);
		available.add(3);
		available.add(4);
		available.add(5);
		available.add(6);
		available.add(7);
		available.add(8);
		List<Integer> seats1=new ArrayList<Integer>();
		seats1.add(4);
		seats1.add(5);
		seats1.add(9);
		List<Integer> seats2=new ArrayList<Integer>();
		seats2.add(1);
		seats2.add(2);
		Cinema c=new Cinema(available, "�쳤��˽��ӰԺ");
		new Thread(new Customer(c, seats2),"��").start();
		new Thread(new Customer(c, seats1),"���").start();
		
	}
		
}

//�˿�
class Customer implements Runnable{
	Cinema cinema;
	List<Integer> seats;
	
	public Customer(Cinema cinema, List<Integer> seats) {
		super();
		this.cinema = cinema;
		this.seats = seats;
	}

	@Override
	public void run() {
		synchronized (cinema) {
		boolean flag=cinema.bookTickets(seats);
		if(flag) {
			System.out.println("��Ʊ�ɹ�"+Thread.currentThread().getName()+"λ��Ϊ:"+seats);
		}else {
			System.out.println("��Ʊʧ��"+Thread.currentThread().getName()+"λ�ò���");
		}
		}
	}
	
}


//ӰԺ
class Cinema{
	List<Integer> available;//���õ�λ��
	String name;
	
	public Cinema(List<Integer> available, String name) {
		super();
		this.available = available;
		this.name = name;
	}

	//����ӰƱ
	public boolean bookTickets(List<Integer> seats){
		System.out.println("��ӭ����"+this.name+"����λ����:"+available);
		List<Integer> copy=new ArrayList<Integer>();
		copy.addAll(available);
		//���
		copy.removeAll(seats);
		//�жϴ�С
		if(available.size()-copy.size()!=seats.size()) {
			return false;
		}
		available=copy;
		return true;
	}
}

	