package cn.zcj.syn;

public class Account {
	
		int money;//���
		String name;//����
		public Account(int money, String name) {
			super();
			this.money = money;
			this.name = name;
		}
	
}
