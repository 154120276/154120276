package cn.zcj.Threadstate;

import java.lang.Thread.State;

public class Allstate {
		
	public static void main(String[] args) {
		Thread t=new Thread(()->{
			for(int i=0;i<5;i++) {
				try {
					Thread.sleep(100);//
				} catch (InterruptedException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			System.out.println("0.0");
			}
		});
		State state=t.getState();
		System.out.println(state);//NEW
		
		t.start();
		state=t.getState();
		System.out.println(state);//RUNNABLE
		
		while(state!=Thread.State.TERMINATED) {
			try {
				Thread.sleep(200);//
			} catch (InterruptedException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			state=t.getState();
			System.out.println(state);//TIMED_WAITING
		}
		state=t.getState();
		System.out.println(state);//TERMINATED
	}
}
