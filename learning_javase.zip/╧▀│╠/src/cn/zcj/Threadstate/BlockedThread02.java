package cn.zcj.Threadstate;

import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * sleepģ�⵹��ʱ
 */
public class BlockedThread02 {
	public static void main(String[] args) throws InterruptedException {
		//����ʱ
		Date endtime=new Date(System.currentTimeMillis()+1000*10);
		long end=endtime.getTime();
		while(true) {
		
			System.out.println(new SimpleDateFormat("mm:ss").format(endtime));
			Thread.sleep(1000);
			endtime=new Date(endtime.getTime()-1000);
			if(end-10000>endtime.getTime()-1000) {
				break;
			}
		}
		}
	
	
	
	public static void test() throws InterruptedException {
		//����10������1sһ��
		int num=10;
		while(num>=0) {
			Thread.sleep(1000);
			System.out.println(num--);
		}
	}
}
