package cn.zcj.Advancedtopics;

public class HappenBefore {
	private static int a=0;
	private static boolean flag=false;
	public static void main(String[] args) throws InterruptedException {
		//�߳�1��ȡ����
		Thread d=new Thread(()->{
			if(flag) {
				a*=1;
				System.out.println(a);
			}
			//ָ������
			if(a==0) {
				System.out.println("Happen Before a-->"+a);
			}
		});
		//�߳�2��������
		Thread t=new Thread(()->{
			a=1;
			flag=true;
		});
		t.start();
		d.start();
		
		t.join();
		d.join();
	}
}
