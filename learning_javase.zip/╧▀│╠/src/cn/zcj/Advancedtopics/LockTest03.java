package cn.zcj.Advancedtopics;
/**
 *��������������������ʹ�ã��ֶ�ʵ��
 * @author ����
 *
 */
public class LockTest03 {
	ReLock lock=new ReLock();
	public void a() throws InterruptedException {
		lock.lock();
		System.out.println(lock.getHoldCount());
		b();
		lock.unlock();
		System.out.println(lock.getHoldCount());
	}
	//��������
    public void b() throws InterruptedException {
    	lock.lock();
    	System.out.println(lock.getHoldCount());
    	//................
    	lock.unlock();
    	System.out.println(lock.getHoldCount());
	}
	public static void main(String[] args) throws InterruptedException {
		 LockTest03 test=new LockTest03();
		 test.a();
		
		 
		 Thread.sleep(1000);
		 System.out.println(test.lock.getHoldCount());
	}
}
//��������
class ReLock{
	//�Ƿ�ռ��
	private boolean isLocked=false;
	Thread lockedBy=null;//�洢�߳�
	private int holdCount=0;
	//ʹ����
	public synchronized void lock() throws InterruptedException {
		while(isLocked&&lockedBy!=Thread.currentThread()) {
			wait();
		}
		isLocked=true;
		lockedBy=Thread.currentThread();
		holdCount++;
	}
	//�ͷ���
public synchronized void unlock() {
	if(Thread.currentThread()==lockedBy){
	  holdCount--;
	  if(holdCount==0) {
		isLocked=false;
		notify();
		lockedBy=null;
	  }
	}
	}
public int getHoldCount() {
	return holdCount;
}

}