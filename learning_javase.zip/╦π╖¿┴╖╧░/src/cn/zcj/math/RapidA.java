package cn.zcj.math;

public class RapidA {
	public static void main(String[] args) {
		int[] a= {5,8,12,9,7,8,3,6,14,11};
		qsort(a, 0, a.length-1);
		for (int i : a) {
			System.out.print(i+"\t");
		}
		int b=a[a.length-1]-a[0];
		System.out.println();
		System.out.println("����Ϊ:"+b);
	}
	
public static void qsort(int[] a,int low,int high) {
	if(low>=high)  return ;
    int i=low;
    int j=high;
    int key=a[low];
    int temp;
    while(i<j){
        while(i<j&&key<=a[j]){
            j--;
        }
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
        while(i<j&&key>=a[i]){
            i++;
        }
        temp=a[i];
        a[i]=a[j];
        a[j]=temp;
    }
    qsort(a,low,i-1);
    qsort(a,i+1,high);
}
}
