package cn.zcj.math;

public class Node {
	int value;
	Node next;
	public static void main(String[] args) {
		Node h=new Node();
		Node p=h;
		for(int k=1;k<4;k++) {
			p.value=10-k;
			Node q=new Node();
			p.next=q;
			p=q;
		}
		p=h;
		while(p!=null) {
			System.out.println(p.value);
			p=p.next;
		}
	}
}
