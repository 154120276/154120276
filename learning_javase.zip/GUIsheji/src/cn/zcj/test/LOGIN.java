package cn.zcj.test;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import java.awt.Toolkit;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LOGIN extends JFrame {
	private static final int WIDTH=500;
    private static final int HEIGHT=300;
	private JPanel contentPane;
	private JTextField usernametxt;
	private JPasswordField passwordtxt;

	/**
	 * Launch the application.����ʹ��
	 * 
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LOGIN frame = new LOGIN();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.��WindowsBuilder�Զ����ɵ�JFrame��¼����
	 */
	public LOGIN() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(LOGIN.class.getResource("/cn/zcj/test/img/Sign_in.gif")));
		setTitle("\u6731\u957F\u6C5F\u7684\u5373\u65F6\u804A\u5929\u767B\u5F55\u754C\u9762");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 Toolkit toolkit=Toolkit.getDefaultToolkit();
	     Dimension screenSize = toolkit.getScreenSize();
		setBounds((screenSize.width-WIDTH)/2,(screenSize.height-HEIGHT)/2,500,382);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel signIn = new JLabel("\u767B\u5F55\u754C\u9762",new ImageIcon(LOGIN.class.getResource("/cn/zcj/test/img/user.png")),JLabel.CENTER);
		signIn.setFont(new Font("����", Font.PLAIN, 38));
		
		JLabel Account = new JLabel("\u8D26\u53F7\uFF1A");
		Account.setIcon(new ImageIcon(LOGIN.class.getResource("/cn/zcj/test/img/user2.png")));
		Account.setFont(new Font("����", Font.PLAIN, 30));
		
		JLabel code = new JLabel("\u5BC6\u7801\uFF1A");
		code.setIcon(new ImageIcon(LOGIN.class.getResource("/cn/zcj/test/img/password.png")));
		code.setFont(new Font("����", Font.PLAIN, 30));
		
		usernametxt = new JTextField();
		usernametxt.setColumns(10);
		
		passwordtxt = new JPasswordField(10);
	
		
		JButton login = new JButton("\u767B\u5F55");
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				//���õ�¼����
				loginAction(event);
			}
		});
		login.setFont(new Font("����", Font.PLAIN, 24));
		
		JButton Registration = new JButton("\u6CE8\u518C");
		Registration.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				//������ת����
				forWordAction(event);
			}
		});
		Registration.setFont(new Font("����", Font.PLAIN, 24));
		
		JButton reflash = new JButton("\u91CD\u7F6E");
		//���õļ����¼�
		reflash.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				//��������������������
				Resetinput(event);
			}
		});
		reflash.setFont(new Font("����", Font.PLAIN, 24));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(114)
					.addComponent(signIn, GroupLayout.PREFERRED_SIZE, 263, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(109, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(reflash, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addGap(72)
							.addComponent(Registration, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
							.addComponent(login, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE))
						.addComponent(code, Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(Account, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(usernametxt, GroupLayout.PREFERRED_SIZE, 291, GroupLayout.PREFERRED_SIZE)
								.addComponent(passwordtxt, GroupLayout.DEFAULT_SIZE, 291, Short.MAX_VALUE))))
					.addGap(38))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(27)
					.addComponent(signIn)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(Account, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
						.addComponent(usernametxt, GroupLayout.PREFERRED_SIZE, 36, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(code, GroupLayout.PREFERRED_SIZE, 75, GroupLayout.PREFERRED_SIZE)
						.addComponent(passwordtxt, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(login, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(reflash, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)
							.addComponent(Registration, GroupLayout.PREFERRED_SIZE, 45, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(32, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		//���ھ���
		this.setLocationRelativeTo(null);
	}
	/*
	 * ��ת��������ע�����
	 *
	 */
	protected void forWordAction(ActionEvent event) {
		
		//dispose();//�رյ�ǰ����
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	protected void loginAction(ActionEvent event) {
		String username=this.usernametxt.getText();
		String password=new String(this.passwordtxt.getPassword());
		//�ж��Ƿ�Ϊ��
		if(StringUtil.isEmpty(username)) {
			JOptionPane.showMessageDialog(null, "�˺Ų���Ϊ�գ�����");
			return;
		}
		
		if(StringUtil.isEmpty(password)) {
			JOptionPane.showMessageDialog(null, "���벻��Ϊ�գ�����");
		}
	}

	//���÷���
	protected void Resetinput(ActionEvent event) {
			this.usernametxt.setText("");
			this.passwordtxt.setText("");
	}
	
}
