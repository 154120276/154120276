package cn.zcj.test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.Font;
import javax.swing.JScrollBar;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Window.Type;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;

public class MainInterface extends JFrame {

    private final JTextField ChatInput;
    private final JTextField SevriceIP;
    private final JTextField Port;
    private final ClientService clientservice;
    private  String USERNAME;
    //��ȡ���ݿ����ӳ��е����ݿ�����
    
    /**
     * �������
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MainInterface frame = new MainInterface("wangwu");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * ���캯��,���ڳ�ʼ��.
     *
     */
    public MainInterface(String USERNAME) {
        this.clientservice = new ClientService();
		this.USERNAME=USERNAME;
        setIconImage(new ImageIcon("img/Main.png").getImage());
        setBackground(SystemColor.activeCaption);
        setTitle("\u804A\u5929\u4E3B\u754C\u9762(@ Author \u6731\u957F\u6C5F)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 950, 740);
        JPanel contentPane = new JPanel();
        contentPane.setBackground(SystemColor.activeCaption);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        JScrollPane scrollPane = new JScrollPane();

        JButton sendtoBtn = new JButton("\u53D1\u9001");
        //������Ϣ�¼�
        sendtoBtn.addActionListener(e -> sendMessage());

        sendtoBtn.setFont(new Font("����", Font.PLAIN, 20));
        sendtoBtn.setIcon(new ImageIcon(("img/sendto.png")));

        JButton reflash = new JButton("\u6E05\u7A7A\u4FE1\u606F");
        //�����Ϣ�����Ϣ
        reflash.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ChatInput.setText("");
            }
        });
        reflash.setFont(new Font("����", Font.PLAIN, 20));

        JLabel lblNewLabel = new JLabel("\u79C1\u804A\u53EA\u9700\u8981\u5728\u4F60\u7684\u4FE1\u606F\u524D\u52A0\u4E0A@+\u5BF9\u65B9\u6635\u79F0:\u5373\u53EF(\u9ED8\u8BA4\u6240\u6709\u4EBA\u7FA4\u804A)");
        lblNewLabel.setFont(new Font("����", Font.PLAIN, 20));

        JLabel lblNewLabel_1 = new JLabel("\u4E0D\u652F\u6301\u56FE\u7247");
        lblNewLabel_1.setFont(new Font("����", Font.PLAIN, 20));

        JTextArea ChatRoom = new JTextArea();
        scrollPane.setViewportView(ChatRoom);

        JLabel ChatInputRoom = new JLabel("\u804A\u5929\u8F93\u5165\u6846");
        ChatInputRoom.setIcon(new ImageIcon(("img/ChatRoom.png")));
        ChatInputRoom.setFont(new Font("����", Font.PLAIN, 20));

        JLabel ChatOutRoom = new JLabel("\u804A\u5929\u8F93\u51FA\u754C\u9762");
        ChatOutRoom.setIcon(new ImageIcon(("img/Chat.png")));
        ChatOutRoom.setFont(new Font("����", Font.PLAIN, 20));

        JLabel lblNewLabel_2 = new JLabel("\u63D0\u793A:\u56DE\u8F66\u53EF\u4EE3\u66FF\u6309\u94AE\u4F46\u6587\u672C\u4E0D\u80FD\u6362\u884C");
        lblNewLabel_2.setFont(new Font("����", Font.PLAIN, 12));

        JButton singleChat = new JButton("\u79C1\u804A\u5FEB\u6377\u952E");
        singleChat.addActionListener(new ActionListener() {
            //˽�Ŀ�������¼�
            public void actionPerformed(ActionEvent e) {
                ChatRoom.append("ϵͳ��Ϣ:���ǳƸ�Ϊ����Ҫ˽�ĵ��˼������˽�Ĺ���"+"\n");
                ChatInput.setText("@�ǳ�:");
            }
        });
        singleChat.setFont(new Font("����", Font.PLAIN, 20));

        ChatInput = new JTextField();
        //���س�������Ϣ�¼�
        ChatInput.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode()== KeyEvent.VK_ENTER){
                    sendMessage();
                }
            }
        });
        ChatInput.setColumns(10);

        JLabel lblNewLabel_1_1 = new JLabel("\u804A\u5929\u6846\uFF1A");
        lblNewLabel_1_1.setIcon(new ImageIcon(("img/Chat.png")));
        lblNewLabel_1_1.setFont(new Font("����", Font.PLAIN, 20));

        JLabel lblip = new JLabel("\u4E3B\u673AIP\u5730\u5740:");
        lblip.setFont(new Font("����", Font.PLAIN, 20));

        SevriceIP = new JTextField();
        SevriceIP.setForeground(Color.RED);
        SevriceIP.setFont(new Font("����", Font.PLAIN, 20));
        SevriceIP.setText("localhost");
        SevriceIP.setColumns(10);

        JLabel lblip_1 = new JLabel("\u7AEF\u53E3\u53F7:");
        lblip_1.setFont(new Font("����", Font.PLAIN, 20));

        Port = new JTextField();
        Port.setFont(new Font("����", Font.PLAIN, 20));
        Port.setForeground(Color.RED);
        Port.setText("8888");
        Port.setColumns(10);

        JButton connect = new JButton("\u8FDE\u63A5");
        //��ȡ���ӵ��¼�
        connect.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
            }
        });
        // �����ڹر�ʱ����
        addWindowListener(new WindowAdapter() { // ���ڹرպ�Ͽ�����
            @Override
            public void windowClosing(WindowEvent e) {
                clientservice.disconnect();
            }
        });
        connect.setFont(new Font("����", Font.PLAIN, 15));
        
        JButton friends = new JButton("\u597D\u53CB\u754C\u9762");
        friends.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        friends.setIcon(new ImageIcon(MainInterface.class.getResource("/cn/zcj/test/img/friend.png")));
        friends.setFont(new Font("����", Font.ITALIC, 40));
        GroupLayout gl_contentPane = new GroupLayout(contentPane);
        gl_contentPane.setHorizontalGroup(
        	gl_contentPane.createParallelGroup(Alignment.TRAILING)
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        				.addComponent(lblNewLabel)
        				.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 562, GroupLayout.PREFERRED_SIZE)
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
        						.addGroup(gl_contentPane.createSequentialGroup()
        							.addComponent(lblNewLabel_1)
        							.addGap(29))
        						.addGroup(gl_contentPane.createSequentialGroup()
        							.addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 126, GroupLayout.PREFERRED_SIZE)
        							.addGap(3)))
        					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        						.addGroup(gl_contentPane.createSequentialGroup()
        							.addComponent(singleChat)
        							.addGap(26)
        							.addComponent(reflash, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
        							.addPreferredGap(ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
        							.addComponent(sendtoBtn, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
        							.addGap(10))
        						.addComponent(ChatInput, GroupLayout.PREFERRED_SIZE, 433, GroupLayout.PREFERRED_SIZE))))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(friends, GroupLayout.PREFERRED_SIZE, 307, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap())
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addComponent(ChatOutRoom, GroupLayout.PREFERRED_SIZE, 172, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 275, Short.MAX_VALUE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(ChatInputRoom))
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addComponent(lblip)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(SevriceIP, GroupLayout.PREFERRED_SIZE, 153, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(lblip_1)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(Port, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
        					.addPreferredGap(ComponentPlacement.RELATED)
        					.addComponent(connect, GroupLayout.PREFERRED_SIZE, 90, Short.MAX_VALUE)))
        			.addGap(344))
        );
        gl_contentPane.setVerticalGroup(
        	gl_contentPane.createParallelGroup(Alignment.LEADING)
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 490, GroupLayout.PREFERRED_SIZE)
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
        				.addComponent(connect, GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        				.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
        					.addComponent(lblip, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
        					.addComponent(SevriceIP, GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        					.addComponent(lblip_1, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
        					.addComponent(Port, GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)))
        			.addGap(13)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
        				.addComponent(ChatOutRoom, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE)
        				.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)
        				.addComponent(ChatInputRoom, GroupLayout.PREFERRED_SIZE, 26, GroupLayout.PREFERRED_SIZE))
        			.addPreferredGap(ComponentPlacement.UNRELATED)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
        				.addComponent(ChatInput, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
        				.addComponent(lblNewLabel_1_1, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addGap(6)
        					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
        						.addComponent(singleChat, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        						.addComponent(sendtoBtn)
        						.addComponent(reflash, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)))
        				.addGroup(gl_contentPane.createSequentialGroup()
        					.addGap(10)
        					.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)))
        			.addPreferredGap(ComponentPlacement.RELATED)
        			.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
        		.addGroup(gl_contentPane.createSequentialGroup()
        			.addGap(24)
        			.addComponent(friends, GroupLayout.PREFERRED_SIZE, 120, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(553, Short.MAX_VALUE))
        );
        contentPane.setLayout(gl_contentPane);

        //���ھ���
        this.setLocationRelativeTo(null);

    }
    //���ͷ���
    private void sendMessage() {
        String msg = ChatInput.getText();
        // �������Ϸ���
        if ( msg == null || "".equals(msg)) {
            return;
        }
        // ������Ϣ
       
    }

    // ��ʾ����Ϊtitle������Ϊmessage�ĶԻ��򣬼���д
    private void alert(String title, String message) {
        JOptionPane.showMessageDialog(this, message, title, JOptionPane.INFORMATION_MESSAGE);
    }
}
