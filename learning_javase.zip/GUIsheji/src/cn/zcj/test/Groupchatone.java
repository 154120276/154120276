package cn.zcj.test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Font;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTextArea;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Groupchatone extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField chosetxt;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Groupchatone frame = new Groupchatone();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Groupchatone() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Groupchatone.class.getResource("/cn/zcj/test/img/groupchat.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 503, 507);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
			}
		});
		
		JButton delete = new JButton("\u5220\u9664\u7FA4\u804A");
		delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton add = new JButton("\u6DFB\u52A0\u7FA4\u804A");
		add.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton update = new JButton("\u4FEE\u6539\u7FA4\u804A\u540D");
		update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JScrollPane scrollPane_1 = new JScrollPane();
		
		chosetxt = new JTextField();
		chosetxt.setColumns(10);
		
		JButton chose = new JButton("\u9009\u62E9\u7FA4\u804A");
		chose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		textField = new JTextField();
		textField.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(textField, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
						.addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(chosetxt, GroupLayout.DEFAULT_SIZE, 221, Short.MAX_VALUE)
							.addGap(18)
							.addComponent(update, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(chose, GroupLayout.PREFERRED_SIZE, 94, GroupLayout.PREFERRED_SIZE)
							.addGap(24))
						.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
							.addComponent(add, GroupLayout.PREFERRED_SIZE, 219, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(delete, GroupLayout.DEFAULT_SIZE, 232, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap()
							.addComponent(scrollPane_1, GroupLayout.DEFAULT_SIZE, 469, Short.MAX_VALUE)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 295, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, 21, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(delete)
						.addComponent(add))
					.addGap(10)
					.addComponent(scrollPane_1, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(update, GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
							.addComponent(chosetxt, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
						.addComponent(chose, GroupLayout.PREFERRED_SIZE, 32, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		
		JTextArea txtrn = new JTextArea();
		txtrn.setText("\u8BF7\u9009\u62E9\u5B8C\u70B9\u51FB\u5FEB\u6377\u7FA4\u804A\u540E\u590D\u5236\u8BE5\u6587\u672C\u57DF\u91CC\u9762\u7684\u5B57\u7136\u540E\u5728\u540E\u9762\u52A0\u4E0A\u4F60\u60F3\u8BF4\u7684\u8BDD\u5728\u5916\u9762\u8F93\u5165");
		txtrn.setEditable(false);
		scrollPane_1.setViewportView(txtrn);
		
		table = new JTable();
	
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u4F60\u7684\u7FA4\u804A(\u4F60\u5728\u91CC\u9762\u7684)"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(592);
		scrollPane.setViewportView(table);
		contentPane.setLayout(gl_contentPane);
	}
}
