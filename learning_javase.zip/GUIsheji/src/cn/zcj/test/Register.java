package cn.zcj.test;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Register extends JFrame {

	private JPanel contentPane;
	private JTextField username;
	private JPasswordField password;
	private JPasswordField passwordconfig;
	private JLabel JL4;
	private JTextField name;

	/**
	 * ע�ᴰ��
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Register frame = new Register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Register() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Register.class.getResource("/cn/zcj/test/img/Register.png")));
		setResizable(false);
		setTitle("\u6731\u957F\u6C5F\u7684\u5373\u65F6\u804A\u5929\u7CFB\u7EDF\u6CE8\u518C\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 613, 478);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.activeCaption);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel Register = new JLabel("\u6B22\u8FCE\u60A8\u6CE8\u518C\u6210\u4E3A\u8001\u9F20\u961F\u9996\u5E2D\u55B7\u5B50\u961F\u6210\u5458");
		Register.setFont(new Font("����", Font.PLAIN, 20));
		
		JLabel JL1 = new JLabel("\u8BF7\u8F93\u5165\u8D26\u53F7\uFF1A");
		JL1.setFont(new Font("����", Font.PLAIN, 18));
		
		JLabel JL2 = new JLabel("\u8BF7\u8F93\u5165\u5BC6\u7801\uFF1A");
		JL2.setFont(new Font("����", Font.PLAIN, 18));
		
		JLabel JL3 = new JLabel("\u8BF7\u786E\u8BA4\u5BC6\u7801\uFF1A");
		JL3.setFont(new Font("����", Font.PLAIN, 18));
		
		username = new JTextField();
		username.setColumns(10);
		
		password = new JPasswordField();
		password.setColumns(10);
		
		passwordconfig = new JPasswordField();
		passwordconfig.setColumns(10);
		
		JL4 = new JLabel("\u8BF7\u8F93\u5165\u7528\u6237\u540D\uFF1A");
		JL4.setFont(new Font("����", Font.PLAIN, 18));
		
		name = new JTextField();
		name.setColumns(10);
		
		JButton btnNewButton = new JButton("\u6CE8\u518C");
		//ע���ύ�¼�
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("ע��ɹ�");
			}
		});
		btnNewButton.setIcon(new ImageIcon(Register.class.getResource("/cn/zcj/test/img/Register2.png")));
		btnNewButton.setFont(new Font("����", Font.PLAIN, 26));
		
		JButton exit = new JButton("\u9000\u51FA");
		//�˳����رմ���
		exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		exit.setIcon(new ImageIcon(Register.class.getResource("/cn/zcj/test/img/exit.png")));
		exit.setFont(new Font("����", Font.PLAIN, 26));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(115)
							.addComponent(Register, GroupLayout.PREFERRED_SIZE, 353, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(36)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(JL4)
									.addGap(18)
									.addComponent(name, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(JL1)
										.addComponent(JL2, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
										.addComponent(JL3, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE))
									.addGap(40)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(passwordconfig, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE)
										.addComponent(password, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE)
										.addComponent(username, GroupLayout.PREFERRED_SIZE, 316, GroupLayout.PREFERRED_SIZE)))))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGap(58)
							.addComponent(exit, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 235, Short.MAX_VALUE)
							.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(Register, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(JL1, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
						.addComponent(username, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(JL2, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
						.addComponent(password, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
					.addGap(27)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(JL3, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
						.addComponent(passwordconfig, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(JL4, GroupLayout.PREFERRED_SIZE, 50, GroupLayout.PREFERRED_SIZE)
						.addComponent(name, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE)
						.addComponent(exit, GroupLayout.PREFERRED_SIZE, 43, GroupLayout.PREFERRED_SIZE))
					.addGap(28))
		);
		contentPane.setLayout(gl_contentPane);
		//���ھ���
				this.setLocationRelativeTo(null);
	}
	
}
