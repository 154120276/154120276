package cn.zcj.io;
/*
 	�ֽ����鿽��
 * 
 */

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TestIO09 {
	public static void main(String[] args) throws IOException {
		byte[] dest=fileToByteArray("cat.jpg");
		ByteAarryTofile(dest,"copycat.jpg");
	}
	
	
	public static byte[] fileToByteArray(String filepath) {
		File src=new File(filepath);
		ByteArrayOutputStream os=null;
	
		InputStream is=null;
		try {
			 os=new ByteArrayOutputStream();
			 is=new FileInputStream(src);
		
			byte[] flush=new byte[1024*10];
			int len=-1;
			while((len=is.read(flush))!=-1) {
				
				os.write(flush,0,len);
			}
			os.flush();
			return os.toByteArray();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
	public static void ByteAarryTofile(byte[] src,String filepath) {
		File dest=new File(filepath);
		OutputStream os=null;
		InputStream is=null;
		try {
			is=new ByteArrayInputStream(src);
			os=new FileOutputStream(dest);//true���ں���д�����´�����false��ֱ�Ӱ�֮ǰ���ļ�����
			//��������ȡ��
			byte[] flush=new byte[1024*100];//һ�㶼��1K1024�Ķ�
			int len=-1;//���ص��ǳ���
			while((len=is.read(flush))!=-1) {
				os.write(flush,0,len);
				
			}
			os.flush();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {//�ȴ򿪵ĺ�ر�
				if(null!=os)
					os.close();
				
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
		}
		
		
	}
	}

