package TestFile;

import java.io.File;

/*
 * �ݹ��ӡ�����Ӽ��ļ�
 */
public class DirDemo02 {
	public static void main(String[] args) {
		//�г��¼����� list
		File src=new File("D:\\java\\IO");
		dirprint(src,0);
		count(src);
		System.out.println("�ļ��ܴ�С��"+len);
	}
	public static void dirprint(File src,int highth) {
		System.out.println(src.getName()+"��"+highth+"��");
		if(null==src||!src.exists())
			return;
		else if(src.isDirectory()){
			for(File s:src.listFiles()) {
			dirprint(s,highth+1);
			}
		}
	}
		
	private	static long len=0;
	//ͳ���ļ��д�С
	public static void count(File src) {
		if(null!=src&&src.exists()) {
			if(src.isFile()) {
				len+=src.length();
			}
			else {
				for (File s : src.listFiles()) {
					count(s);
				}
			}
		}
	}
}
