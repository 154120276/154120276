package TestFile;

import java.io.File;

public class DirCount {
	private long len;
	private String path;
	private File src;
	private int Filesize;
	private int Dirsize;
	
	
	public DirCount(String path) {
		super();
		this.path = path;
		this.src = new File(path);
		count(src);
	}
	

	public int getFilesize() {
		return Filesize;
	}
	public int getDirsize() {
		return Dirsize-1;
	}

	public long getLen() {
		return len;
	}

	private void count(File src) {
		if(null!=src&&src.exists()) {
			if(src.isFile()) {
				len+=src.length();
				this.Filesize++;
			}
			else {
				this.Dirsize++;
				for(File s : src.listFiles()) {
					count(s);
				}
			}
		}
	}
	public static void main(String[] args) {
		//�г��¼����� list
		DirCount src=new DirCount("D:\\java\\game");
		System.out.println("�ļ���С��"+src.getLen());
		System.out.println("�ļ�������"+src.getFilesize());
		System.out.println("�ļ��и���:"+src.getDirsize());
		
}
}