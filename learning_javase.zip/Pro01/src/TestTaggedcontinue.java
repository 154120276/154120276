

public class TestTaggedcontinue {
	public static void main(String[] args) {
		zheli:for(int i=100;i<151;i++) {
			for(int j=2;j<i;j++) {
				if(i%j==0) {
				continue zheli;
				}
			}
			System.out.print(i+",");	
		}
	}
}
