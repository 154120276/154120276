import java.util.Scanner;
public class TestFactorial {
		public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("������:");
		long n=scanner.nextLong();
		System.out.println(Factorial(n));
		}
static long Factorial(long n){
	
	if(n==1)return 1;
	else {
		return n*Factorial(n-1);
		
	}
}

}
