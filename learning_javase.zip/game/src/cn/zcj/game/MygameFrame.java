package cn.zcj.game;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;


public class MygameFrame extends JFrame	 {
/*��ʼ������*/
	Image bg=GameUtil.getImage("images/bg.jpg");	
	Image plane=GameUtil.getImage("images/plane.png");
	plane Plane=new plane(plane,250,250);
	
	public void paint(Graphics g) {
		g.drawImage(bg, 0, 0, null);
		Plane.drawSelf(g);
		
	}
	class PaintThread extends Thread{
		public void run() {
			while(true) { 
				repaint();
				try {
					Thread.sleep(40);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
			}
		}
		
		
	}
	
	class KeyMonitor extends KeyAdapter{

		
		public void keyPressed(KeyEvent e) {
			Plane.AddDirection(e);
		
		}

		
		public void keyReleased(KeyEvent e) {
			Plane.minusDirection(e);
		}
		
		
	}
	
	
	
	public void launchFrame() {
		this.setTitle("�쳤������Ʒ");
		this.setVisible(true);
		this.setSize(500,500);
		this.setLocation(300,300);
		this.addWindowListener(new WindowAdapter() {
			
			public void windowClosing(WindowEvent e) {
				System.exit(0);		
				}
		});
		new PaintThread().start();
		addKeyListener(new KeyMonitor());
	}
	public static void main(String[] args) {
	MygameFrame f=new MygameFrame();
	f.launchFrame();
	}
	
}
