package cn.zcj.dao;

import cn.zcj.domain.Asacount;
import cn.zcj.domain.User;

import java.util.List;
import java.util.Map;

/**
 * 用户操作的DAO
 */
public interface UserDao {
     List<User> findAll();
     Asacount findUserByUsernameandPassword(String username, String password);
    void add(User user);

     void delete(int id);

    User findByid(int id);

    void update(User user);

    int findTotalCount(Map<String, String[]> condition);

    List<User> findByPage(int start, int rows, Map<String, String[]> condition);
}
