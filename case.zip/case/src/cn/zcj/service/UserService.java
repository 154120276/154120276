package cn.zcj.service;

import cn.zcj.domain.Asacount;
import cn.zcj.domain.PageBean;
import cn.zcj.domain.User;

import java.util.List;
import java.util.Map;

/**
 * 查询所有用户信息
 * 用户管理的业务接口
 */
public interface UserService {
    public List<User> findAll();
    public Asacount login(Asacount asacount);
    //保存User对象方法
    public void addUser(User user);


    public void deleteUser(String id);

    public User findUserByid(String id);

    void updateUser(User user);

    void delSelected(String[] uids);
/*
分页查询
 */
    PageBean<User> findUserByPage(String currentpage, String rows, Map<String, String[]> condition);
}
