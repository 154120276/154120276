package cn.zcj.service.impl;

import cn.zcj.dao.UserDao;
import cn.zcj.dao.impl.UserDaoImpl;
import cn.zcj.domain.Asacount;
import cn.zcj.domain.PageBean;
import cn.zcj.domain.User;
import cn.zcj.service.UserService;

import java.util.List;
import java.util.Map;

public class UserServiceImpl implements UserService {
    private UserDao dao=new UserDaoImpl();

    @Override
    public List<User> findAll() {
        //调用DAO
         return dao.findAll();
    }

    @Override
    public Asacount login(Asacount user) {
        return dao.findUserByUsernameandPassword(user.getUsername(),user.getPassword());
    }

    @Override
    public void addUser(User user) {
        dao.add(user);
    }

    @Override
    public void deleteUser(String id) {
        dao.delete(Integer.parseInt(id));
    }

    @Override
    public User findUserByid(String id) {
        return dao.findByid(Integer.parseInt(id));
    }

    @Override
    public void updateUser(User user) {
        dao.update(user);
    }

    @Override
    public void delSelected(String[] uids) {
        //1.遍历
        for (String uid : uids) {
            //删除
            dao.delete(Integer.parseInt(uid));
        }
    }

    @Override
    public PageBean<User> findUserByPage(String _currentpage, String _rows, Map<String, String[]> condition) {
        int currentpage=Integer.parseInt(_currentpage);
        int rows=Integer.parseInt(_rows);


        PageBean<User> pb=new PageBean<User>();
        //设置参数
        pb.setRows(rows);
        pb.setCurrentPage(currentpage);

        //调用DAO
        int totalCount=dao.findTotalCount(condition);
        pb.setTotalCount(totalCount);
        //计算开始记录索引
        int start=(currentpage-1) * rows;
        System.out.println(currentpage+"+"+start);
        List<User> list=dao.findByPage(start,rows,condition);
        System.out.println(list);
        pb.setList(list);

        //计算总页码
        int totalPage= (totalCount % rows) ==0 ? (totalCount/rows) : (totalCount/rows+1);
        pb.setTotalPage(totalPage);

        return pb;
    }


}
