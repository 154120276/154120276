package cn.zcj.web.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
/*
    登录验证过滤器

 */

@WebFilter("/*")
public class LoginFilter implements Filter {
    public void destroy() {
    }

    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain) throws ServletException, IOException {
        //0.强制转换
        HttpServletRequest request=(HttpServletRequest) req;
        //1.获取请求资源路径
        String URI = request.getRequestURI();
        if (URI.contains("/login.jsp") || URI.contains("/loginServlet") || URI.contains("/css/")  || URI.contains("/js/") || URI.contains("/fonts/") || URI.contains("/checkCodeServlet")){
            chain.doFilter(req, resp);
        }else {
            //不包含验证是否登录
            //3.从session中获取user
            Object user = request.getSession().getAttribute("user");
            if (user!=null){
                chain.doFilter(req,resp);
            }else {
                request.setAttribute("login_msg","您尚未登录，请登录");
                request.getRequestDispatcher("/login.jsp").forward(req,resp);
            }
        }


        //chain.doFilter(req, resp);
    }

    public void init(FilterConfig config) throws ServletException {

    }

}
