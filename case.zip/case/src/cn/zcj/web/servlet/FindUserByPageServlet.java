package cn.zcj.web.servlet;

import cn.zcj.domain.PageBean;
import cn.zcj.domain.User;
import cn.zcj.service.UserService;
import cn.zcj.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Map;

@WebServlet("/findUserByPageServlet")
public class FindUserByPageServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取参数
        request.setCharacterEncoding("utf-8");
        String currentpage = request.getParameter("currentPage");//当前页码
        String rows = request.getParameter("rows");//每页条数
        if (currentpage==null || "".equals(currentpage)){
            currentpage="1";
        }
        if (rows==null || "".equals(rows)){
            rows="5";
        }
        //获取条件查询参数
        Map<String, String[]> condition = request.getParameterMap();
        //2.调用Service
        UserService service=new UserServiceImpl();
        PageBean<User> pb=service.findUserByPage(currentpage,rows,condition);
        //3.将PageBean存入request
        request.setAttribute("pb",pb);
        request.setAttribute("condition",condition);
        request.getRequestDispatcher("/list.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
